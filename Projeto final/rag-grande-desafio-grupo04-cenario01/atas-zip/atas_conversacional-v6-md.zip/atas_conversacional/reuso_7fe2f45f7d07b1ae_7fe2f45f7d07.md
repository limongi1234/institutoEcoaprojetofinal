# reuso_7fe2f45f7d07b1ae_7fe2f45f7d07

Fonte: [PDF original](https://pncp.gov.br/pncp-api/v1/orgaos/00394429000100/compras/2023/001707/atas/11/arquivos/1)

SHA-256 do PDF: `7fe2f45f7d07b1aecb726fd8999f18cee522d014eff6682cc72e906491af28af`

Texto extraído automaticamente, organizado por página.

## Página 1

MINISTÉRIO DA DEFESA
COMANDO DA AERONÁUTICA
TERMO DE HOMOLOGAÇÃOUASG 120645  - GRUPAMENTO DE APOIO DO GALEÃO
PREGÃO 62/2023
Às 11:25 horas do dia 03 de January do ano de 2024, após constatada a regularidade dos atos procedimentais, a autoridade competente,
HUMBERTO RUBIN NETO, HOMOLOGA a adjudicação referente ao Processo nº 67107006883202349, Pregão nº 62/2023.
Fundamentação legal: Lei 14.133/2021 Característica: SRP - Registro de Preço
Critério de julgamento: Menor Preço / Maior Desconto Modo de disputa: Aberto/Fechado
Compra emergencial: Não
Objeto da compra: Registro de precos para a contratacao de empresa especializada, visando a execucao futura de possiveis Servicos
Comuns de Engenharia para Manutencao e Conservacao de Bens Imoveis e correlatos com o objetivo de atender
as necessidades do Grupamento de Apoio do Galeao e suas Unidades Apoiadas.
Entrega de propostas: De 18/10/2023 às 08:00 até 01/11/2023 às 09:00
Abertura da sessão pública: Dia 01/11/2023 às 09:00 (horário de Brasília)
Mensagens do chat da compra
Responsável Data/Hora Mensagem
Sistema 01/11/2023 às 09:00:20 A sessão pública está aberta. Até 20 itens poderão estar em disputa simultaneamente e o período de
abertura para disputa será entre 08:00 e 18:00. Mantenham-se conectados.
Sistema 01/11/2023 às 09:15:47 Senhores licitantes, peço atenção à exequibilidade de suas propostas.
Sistema 01/11/2023 às 16:27:50 A etapa de julgamento de propostas foi iniciada. Para acompanhá-la acesse a opção "Seleção de
fornecedores" na linha do tempo.
Sistema 01/11/2023 às 16:35:16
Terminada a fase de lances daremos início à fase de julgamento das propostas. Solicito que as
licitantes melhores classificadas encaminhem no prazo de 2 (duas) horas sua proposta de preços
adequada a fase de lances fazendo constar: Planilha Sintética, Planilha Analítica e Composição do
BDI.
Sistema 01/11/2023 às 16:46:09 Senhores licitantes, para que fiquem organizadas as solicitações de prorrogação de prazo peço que
as façam via chat aqui no comprasnet, bem como por meio do e-mail que consta no edital.
Sistema 03/11/2023 às 08:10:32 Bom dia senhores licitantes, daremos continuidade ao certame com as prorrogações solicitadas.
Sistema 03/11/2023 às 12:00:37 Boa tarde senhores licitantes, informo que a sessão será suspensa neste momento para análise da
documentação enviada e reaberta na segunda feira, dia 06/11/23 às 09:00h.
Sistema 06/11/2023 às 09:05:23 Bom dia senhores licitantes daremos continuidade ao certame com a análise das documentações
enviadas.
Sistema 07/11/2023 às 09:32:22 Bom dia senhores licitantes daremos continuidade ao certame com a análise das documentações
enviadas.
Sistema 08/11/2023 às 09:22:51 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 09/11/2023 às 09:04:35 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 10/11/2023 às 09:51:50 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 13/11/2023 às 09:11:31 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 14/11/2023 às 09:00:31 Bom dia senhores licitantes, daremos continuidade ao certame.
1 de 12603/01/2024 11:25

## Página 2

UASG 120645 PREGÃO 62/2023
Responsável Data/Hora Mensagem
Sistema 16/11/2023 às 09:01:45 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 17/11/2023 às 09:06:11 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 21/11/2023 às 09:03:15 Bom dia senhores licitantes, daremos continuidade ao certame
Sistema 23/11/2023 às 09:41:47 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 24/11/2023 às 09:16:15 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 27/11/2023 às 09:09:10 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 28/11/2023 às 09:05:35 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 29/11/2023 às 09:31:12 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 30/11/2023 às 09:20:13 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 30/11/2023 às 16:06:57 Boa tarde senhores licitantes, informo que não serão feitas novas convocações no dia de hoje,
retomaremos a sessão amanhã, 01/12/2023, às 09:00h.
Sistema 01/12/2023 às 09:00:46 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 01/12/2023 às 14:32:18 Boa tarde senhores licitantes, informo que a sessão será suspensa neste momento e reaberta no dia
04/12/2023 às 09:00h.
Sistema 04/12/2023 às 09:04:22 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 05/12/2023 às 09:27:10 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 06/12/2023 às 09:08:39 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 07/12/2023 às 09:01:51 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 11/12/2023 às 09:02:27 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 12/12/2023 às 09:07:20 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 13/12/2023 às 09:18:39 Bom dia senhores licitantes, informo que não serão feitas convocações no dia de hoje e
retomaremos a sessão amanhã, 14/12/23 às 09:00h.
Sistema 14/12/2023 às 09:05:29 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 14/12/2023 às 11:25:50 Senhores fornecedores, informo que as solicitações de prorrogação referentes aos grupos 2, 8, 13 e
16 serão concedidas por igual período.
Sistema 15/12/2023 às 09:08:00 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 15/12/2023 às 17:34:21 Boa tarde senhores licitantes, informo que retomaremos a sessão no dia 18/12/23 às 09:00h
Sistema 18/12/2023 às 09:13:56 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 19/12/2023 às 09:41:55 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 20/12/2023 às 09:10:03 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 21/12/2023 às 09:14:22 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 22/12/2023 às 09:07:26 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 26/12/2023 às 10:10:30 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 27/12/2023 às 11:13:16 Bom dia, daremos continuidade ao certame.
Sistema 29/12/2023 às 09:14:17 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 02/01/2024 às 09:23:55 Bom dia senhores licitantes, daremos continuidade ao certame.
Sistema 03/01/2024 às 09:58:40 Bom dia senhores licitantes, daremos continuidade ao certame.
2 de 12603/01/2024 11:25

## Página 3

UASG 120645 PREGÃO 62/2023
Eventos da compra
Data/Hora Descrição
01/11/2023 às 09:00:20 Abertura da sessão pública
01/11/2023 às 16:27:46 Início da etapa de julgamento de propostas
3 de 12603/01/2024 11:25

## Página 4

UASG 120645 PREGÃO 62/2023
Grupo 13
Adjudicado e Homologado
R$ 6.536.984,7500
Situação:
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 4.535.650,0300
Propostas do Grupo G13
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 6.536.984,7500  -
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 5.097.235,0700  -
Valor proposta: R$ 6.077.292,6800 Valor negociado: Não informado
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 6.435.217,5000  -
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 4.829.506,4200  -
Valor proposta: R$ 5.618.602,6500 Valor negociado: Não informado
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 4.895.458,5400  -
Valor proposta: R$ 4.895.458,5400 Valor negociado: Não informado
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 6.536.984,7500  -
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 3.526.883,0000 Proposta
desclassificada
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 3.918.381,5700 Proposta
desclassificada
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 3.910.821,7800 Proposta
desclassificada
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
Grupo 13
Valor estimado:
Sem benefícios ME/EPP (Art. 4º, lei
14.133/2021)
Tratamento Diferenciado ME/EPP:
4 de 12603/01/2024 11:25

## Página 5

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 4.003.629,9500 Proposta
desclassificada
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 4.740.108,5000  -
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 5.196.732,0900  -
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 6.536.984,7500  -
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 4.909.288,4200  -
Valor proposta: R$ 4.909.288,4200 Valor negociado: Não informado
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 4.920.288,5700 Proposta
desclassificada
Valor proposta: R$ 4.920.288,5700 Valor negociado: Não informado
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 4.902.357,9900  -
Valor proposta: R$ 4.902.357,9900 Valor negociado: Não informado
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 4.702.534,6900  -
Valor proposta: R$ 4.702.534,6900 Valor negociado: Não informado
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 4.246.457,3900 Proposta
desclassificada
Valor proposta: R$ 5.611.474,3700 Valor negociado: Não informado
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 6.536.984,7500  -
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 5.399.501,0000  -
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 6.536.984,7500  -
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 4.575.879,0200  -
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
5 de 12603/01/2024 11:25

## Página 6

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 4.902.497,7600  -
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 6.536.984,7500  -
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 2.961.869,1000 Proposta
desclassificada
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 4.535.650,0300 Proposta adjudicada
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 4.510.478,1000 Proposta
desclassificada
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 6.536.984,7500  -
Valor proposta: R$ 6.536.984,7500 Valor negociado: Não informado
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 2.452.298,2100 Proposta
desclassificada
Valor proposta: R$ 6.256.689,7000 Valor negociado: Não informado
Mensagens do chat do Grupo G13
Responsável Data/Hora Mensagem
Sistema 01/11/2023 14:05:04 O item G13 foi aberto. Solicitamos o envio de lances.
Sistema 01/11/2023 14:26:04
A etapa fechada foi iniciada para o item G13. Fornecedor que apresentou lance entre R$
3.414.303,9700 e R$ 3.526.883,0000 poderá enviar um lance único e fechado até às 14:31:04 do dia
01/11/2023.
Sistema 01/11/2023 14:31:05 A etapa fechada do item G13 foi encerrada. Os seguintes lances foram registrados pelos
fornecedores convocados: R$ 2.961.869,1000 e R$ 2.452.298,2100.
Sistema 01/11/2023 14:31:05 O item G13 está encerrado.
Sistema para o
participante
16.843.624/0001-00
01/11/2023 16:42:59
Sr. Fornecedor ZWI ENGENHARIA LTDA, CNPJ 16.843.624/0001-00, você foi convocado para
enviar anexos para o item G13. Prazo para encerrar o envio: 18:42:00 do dia 01/11/2023.
Justificativa: Solicito envio de anexos conforme solicitado via chat: Planilha sintética, planilha
analítica e composição do BDI..
pelo participante
16.843.624/0001-00 01/11/2023 16:45:15 Solicitamos prorrogação do prazo para envio dos doc solicitados.
Sistema para o
participante
16.843.624/0001-00
01/11/2023 16:55:54 Informo que a prorrogação será concedida por igual período, porém se iniciando às 08:00h do dia
03/11/23.
6 de 12603/01/2024 11:25

## Página 7

UASG 120645 PREGÃO 62/2023
Responsável Data/Hora Mensagem
Sistema para o
participante
16.843.624/0001-00
01/11/2023 18:42:00 O item G13 teve a convocação para envio de anexos encerrada às 18:42:00 de 01/11/2023. Nenhum
anexo foi enviado pelo fornecedor ZWI ENGENHARIA LTDA, CNPJ 16.843.624/0001-00.
Sistema para o
participante
16.843.624/0001-00
03/11/2023 08:17:35
Sr. Fornecedor ZWI ENGENHARIA LTDA, CNPJ 16.843.624/0001-00, você foi convocado para
enviar anexos para o item G13. Prazo para encerrar o envio: 10:17:00 do dia 03/11/2023.
Justificativa: Prorrogação será concedida por igual período..
pelo participante
16.843.624/0001-00 03/11/2023 09:38:39 O item G13 teve a convocação para envio de anexos encerrada às 09:38:39 de 03/11/2023. 1 anexo
foi enviado pelo fornecedor ZWI ENGENHARIA LTDA, CNPJ 16.843.624/0001-00.
Sistema para o
participante
06.222.208/0001-31
13/11/2023 09:37:18
Sr. Fornecedor VAN EDIL COMERCIO DE ALIMENTOS E SERVICOS DE MAQUINAS E
DECORACOES LTDA, CNPJ 06.222.208/0001-31, você foi convocado para enviar anexos para o
item G13. Prazo para encerrar o envio: 11:37:00 do dia 13/11/2023. Justificativa: Solicito envio de
anexos conforme solicitado via chat: Planilha sintética, planilha analítica e composição do BDI.
Sistema para o
participante
06.222.208/0001-31
13/11/2023 11:37:00
O item G13 teve a convocação para envio de anexos encerrada às 11:37:00 de 13/11/2023. Nenhum
anexo foi enviado pelo fornecedor VAN EDIL COMERCIO DE ALIMENTOS E SERVICOS DE
MAQUINAS E DECORACOES LTDA, CNPJ 06.222.208/0001-31.
Sistema para o
participante
33.890.430/0001-85
13/11/2023 13:06:27
Sr. Fornecedor D A G G TAVARES PROJETOS ESTRUTURAIS LTDA, CNPJ 33.890.430/0001-85,
você foi convocado para enviar anexos para o item G13. Prazo para encerrar o envio: 15:06:00 do
dia 13/11/2023. Justificativa: Solicito envio de anexos conforme solicitado via chat: Planilha
sintética, planilha analítica e composição do BDI.
Sistema para o
participante
33.890.430/0001-85
13/11/2023 15:06:00
O item G13 teve a convocação para envio de anexos encerrada às 15:06:00 de 13/11/2023. Nenhum
anexo foi enviado pelo fornecedor D A G G TAVARES PROJETOS ESTRUTURAIS LTDA, CNPJ
33.890.430/0001-85.
Sistema 16/11/2023 09:31:43
A etapa fechada foi reiniciada para o item G13. Fornecedor que apresentou um dos seguintes
lances: R$ 3.911.400,3000, R$ 3.918.381,5700 e R$ 4.003.629,9500, poderá enviar um lance único e
fechado até às 09:36:42 do dia 16/11/2023.
Sistema 16/11/2023 09:36:43 A etapa fechada do item G13 foi encerrada. Os seguintes lances foram registrados pelos
fornecedores convocados: R$ 3.910.821,7800.
Sistema 16/11/2023 09:36:43 O item G13 está encerrado.
Sistema para o
participante
33.493.603/0001-21
21/11/2023 10:19:11
Sr. Fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21, você foi convocado para
enviar anexos para o item G13. Prazo para encerrar o envio: 12:19:00 do dia 21/11/2023.
Justificativa: Solicito envio de anexos conforme solicitado via chat: Planilha sintética, planilha
analítica e composição do BDI.
pelo participante
33.493.603/0001-21 21/11/2023 12:07:03 O item G13 teve a convocação para envio de anexos encerrada às 12:07:03 de 21/11/2023. 1 anexo
foi enviado pelo fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21.
Sistema para o
participante
33.493.603/0001-21
27/11/2023 14:06:32
Boa tarde, tendo em vista a análise técnica serão solicitadas as seguintes diligências: o Não foi
observado o documento de comprovação das alíquotas de PIS e COFINS da licitante. Solicito o
envio do cálculo de PIS e COFINS.
Sistema para o
participante
33.493.603/0001-21
27/11/2023 14:07:01
o Foi observado que a Licitante para o cálculo do BDI considerou a alíquota do ISS aplicado no
BDI de 4,67%, superior a alíquota praticada no estado do Rio de janeiro ISS 3,0%. Solicito revisão
da planilha.
Sistema para o
participante
33.493.603/0001-21
27/11/2023 14:08:25 Foi observado que nas composições auxiliares 88239, 88243, 88252, 88261, 88262, 88269, 88278 e
88316
Sistema para o
participante
33.493.603/0001-21
27/11/2023 14:08:57 Não há o detalhamento das composições auxiliares, portanto solicito que as mesmas sejam
enviadas para que haja a análise técnica.
Sistema para o
participante
33.493.603/0001-21
27/11/2023 14:09:57
Além disso também foi observado que nas composições auxiliares 88278 há valores diferentes para
a mesma composição, sendo necessário que a licitante faça o ajuste de modo a igualar o valor da
composição auxiliar em todos os itens que a utiliza.
Sistema para o
participante
33.493.603/0001-21
27/11/2023 14:10:33 Foi observado que o insumo 00040547 apresenta 2 (dois) valores diferentes R$ 19,82 e R$ 21,27.
Solicito o reenvio da planilha com os valores ajustados para o menor preço ofertado.
7 de 12603/01/2024 11:25

## Página 8

UASG 120645 PREGÃO 62/2023
Responsável Data/Hora Mensagem
Sistema para o
participante
33.493.603/0001-21
27/11/2023 14:10:57 Foi observado que o insumo 00039427 apresenta 2 (dois) valores diferentes R$ 3,05 e R$ 3,61.
Solicito o reenvio da planilha com os valores ajustados para o menor preço ofertado.
Sistema para o
participante
33.493.603/0001-21
27/11/2023 14:11:31
Sr. Fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21, você foi convocado para
enviar anexos para o item G13. Prazo para encerrar o envio: 16:11:00 do dia 27/11/2023.
Justificativa: Solicito o envio das planilhas ajustadas conforme orientações via chat.
pelo participante
33.493.603/0001-21 27/11/2023 14:22:00 solicitamos o prazo dilação 24 h para organização das diligências
Sistema para o
participante
33.493.603/0001-21
27/11/2023 15:01:12 Boa tarde, informo que será concedida prorrogação por igual período, totalizando 4 (quatro) horas.
pelo participante
33.493.603/0001-21 27/11/2023 15:21:11
Referente a este questionamento tem como ser mais especifico : ¨"Não há o detalhamento das
composições auxiliares, portanto solicito que as mesmas sejam enviadas para que haja a análise
técnica."
Sistema para o
participante
33.493.603/0001-21
27/11/2023 15:31:28 Boa tarde, o licitante encaminhou em sua planilha analítica a composição do item, e as
composições auxiliares composições auxiliares de serviços
Sistema para o
participante
33.493.603/0001-21
27/11/2023 15:31:41 Desconsiderar a mensagem anterior.
Sistema para o
participante
33.493.603/0001-21
27/11/2023 15:33:23
Boa tarde, o licitante encaminhou em sua planilha analítica a composição do item, a qual é
composta pelos insumos e composições auxiliares, se faz necessária o envio da planilha analítica da
composição auxiliar de mão de obra, a fim de que seja possível a área técnica observar o custo da
mão de obra, e dos outros custos relativos ao serviço.
pelo participante
33.493.603/0001-21 27/11/2023 15:39:01 Prezado pregoeiro, não consta no edital a planilha analítica da composição auxiliar de mão de
obra, é possivel nos encaminhar a mesma
Sistema para o
participante
33.493.603/0001-21
27/11/2023 15:49:05 Essas composições são SINAPI, como por exemplo as que devem ser expandidas pela licitante no
G13 são as seguintes: 88278, 88239, 88262, 88316, 88269, 88252, 88243 e 88261
pelo participante
33.493.603/0001-21 27/11/2023 15:54:37 O senhor esta querendo que expanda os valores da mão de obra, sendo assim esta querendo que
descrimine o valo da mão de obra , impostos e custos
Sistema para o
participante
33.493.603/0001-21
27/11/2023 15:58:51 Exatamente isso, a área técnica solicitou essa diligência para avaliação de exequibilidade.
pelo participante
33.493.603/0001-21 27/11/2023 16:03:38
Para essa comprovação de exequibilidade podemos enviar o convenção coletiva do sinticato da
consrução civil do RJ onde demostra que o valor da MO descriminada na planilha esta acima do
piso do sindicato da construção civil do RJ
Sistema para o
participante
33.493.603/0001-21
27/11/2023 16:08:36 Está sendo solicitada a composição auxiliar analítica.
Sistema para o
participante
33.493.603/0001-21
27/11/2023 16:08:46 Conforme esclarecido via chat.
Sistema para o
participante
33.493.603/0001-21
27/11/2023 16:11:00 O item G13 teve a convocação para envio de anexos encerrada às 16:11:00 de 27/11/2023. Nenhum
anexo foi enviado pelo fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21.
Sistema para o
participante
33.493.603/0001-21
27/11/2023 16:14:03
Sr. Fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21, você foi convocado para
enviar anexos para o item G13. Prazo para encerrar o envio: 18:14:00 do dia 27/11/2023.
Justificativa: Prorrogação concedida por igual período.
pelo participante
33.493.603/0001-21 27/11/2023 17:15:33 O item G13 teve a convocação para envio de anexos encerrada às 17:15:33 de 27/11/2023. 1 anexo
foi enviado pelo fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21.
Sistema para o 14/12/2023 09:49:19 Bom dia, ao analisar as documentações enviadas para dirimir as diligêncicias permaneceram três
8 de 12603/01/2024 11:25

## Página 9

UASG 120645 PREGÃO 62/2023
Responsável Data/Hora Mensagem
participante
33.493.603/0001-21 14/12/2023 09:49:19 óbices, os quais seguem abaixo:
Sistema para o
participante
33.493.603/0001-21
14/12/2023 09:49:28 Não foi observado o envio da planilha de composição de BDI
Sistema para o
participante
33.493.603/0001-21
14/12/2023 09:49:51 Foi observado que houve majoração de valores na composição auxiliar 88278 do item 678 e nos
insumos 00040547 do item 678 e 0039427 do item 683.
Sistema para o
participante
33.493.603/0001-21
14/12/2023 09:50:29
Não foi observado o orçamento analítico das composições auxiliares referente a mão de obra, uma
vez que a licitante diminuiu o valor de referência da mão de obra. Solicitar a composição analítica
da mão de obra para as seguintes composições auxiliares: 88239, 88243, 88252, 88261, 88262,
88269, 88278 e 88316.
Sistema para o
participante
33.493.603/0001-21
14/12/2023 09:50:32
Ressalto que a composição auxiliar enviada apresenta apenas o detalhamento das leis sociais, porém
ainda se faz necessária a exposição de custos relativos à mão-de-obra como gastos com transporte,
uniformes, etc.
Sistema para o
participante
33.493.603/0001-21
14/12/2023 09:51:12
Sr. Fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21, você foi convocado para
enviar anexos para o item G13. Prazo para encerrar o envio: 11:51:00 do dia 14/12/2023.
Justificativa: Solicito o envio das planilhas ajustadas conforme diligência solicitada via chat..
pelo participante
33.493.603/0001-21 14/12/2023 10:01:19 Bom dia Sr. Pregoeiro! Venho por meio deste solicitar a dilação do prazo de 2h para realizar as
correções exigidas na atual convocação.
Sistema para o
participante
33.493.603/0001-21
14/12/2023 11:51:00 O item G13 teve a convocação para envio de anexos encerrada às 11:51:00 de 14/12/2023. Nenhum
anexo foi enviado pelo fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21.
pelo participante
33.493.603/0001-21 14/12/2023 11:55:42 Sr. Pregoeiro! Solicito a reabertura do prazo para envio dos anexos solicitados na atual convocação.
Sistema para o
participante
33.493.603/0001-21
14/12/2023 11:57:08
Sr. Fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21, você foi convocado para
enviar anexos para o item G13. Prazo para encerrar o envio: 13:57:00 do dia 14/12/2023.
Justificativa: Prorrogação conforme solicitado..
pelo participante
33.493.603/0001-21 14/12/2023 13:21:38 Boa tarde Sr. Pregoeiro! Devido a convocação simultânea de grupos solicito a prorrogação de mais
2h para melhor organização.
pelo participante
33.493.603/0001-21 14/12/2023 13:51:52 O item G13 teve a convocação para envio de anexos encerrada às 13:51:52 de 14/12/2023. 1 anexo
foi enviado pelo fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21.
Sistema para o
participante
28.244.608/0001-80
18/12/2023 11:54:19
Sr. Fornecedor DSM SERVICOS E COMERCIO LTDA, CNPJ 28.244.608/0001-80, você foi
convocado para enviar anexos para o item G13. Prazo para encerrar o envio: 13:54:00 do dia
18/12/2023. Justificativa: Solicito envio de anexos conforme solicitado via chat: Planilha sintética,
planilha analítica e composição do BDI.
Sistema para o
participante
28.244.608/0001-80
18/12/2023 13:54:00
O item G13 teve a convocação para envio de anexos encerrada às 13:54:00 de 18/12/2023. Nenhum
anexo foi enviado pelo fornecedor DSM SERVICOS E COMERCIO LTDA, CNPJ
28.244.608/0001-80.
Sistema para o
participante
27.595.842/0001-90
18/12/2023 14:32:31
Sr. Fornecedor ETEPAR CONSTRUCOES LTDA, CNPJ 27.595.842/0001-90, você foi convocado
para enviar anexos para o item G13. Prazo para encerrar o envio: 16:32:00 do dia 18/12/2023.
Justificativa: Solicito envio de anexos conforme solicitado via chat: Planilha sintética, planilha
analítica e composição do BDI.
Sistema para o
participante
27.595.842/0001-90
18/12/2023 16:32:00 O item G13 teve a convocação para envio de anexos encerrada às 16:32:00 de 18/12/2023. Nenhum
anexo foi enviado pelo fornecedor ETEPAR CONSTRUCOES LTDA, CNPJ 27.595.842/0001-90.
Sistema 20/12/2023 09:18:38
A etapa fechada foi reiniciada para o item G13. Fornecedor que apresentou um dos seguintes
lances: R$ 4.246.457,3900, R$ 4.510.478,1000 e R$ 4.535.650,0300, poderá enviar um lance único e
fechado até às 09:23:37 do dia 20/12/2023.
Sistema 20/12/2023 09:23:38 A etapa fechada do item G13 foi encerrada. Nenhum fornecedor convocado registrou lance.
Sistema 20/12/2023 09:23:38 A etapa fechada foi reiniciada para o item G13. Fornecedor que apresentou um dos seguintes
lances: R$ 4.575.879,0200, R$ 4.702.534,6900 e R$ 4.740.108,5000, poderá enviar um lance único e
9 de 12603/01/2024 11:25

## Página 10

UASG 120645 PREGÃO 62/2023
Responsável Data/Hora Mensagem
Sistema 20/12/2023 09:23:38 fechado até às 09:28:38 do dia 20/12/2023.
Sistema 20/12/2023 09:28:39 A etapa fechada do item G13 foi encerrada. Nenhum fornecedor convocado registrou lance.
Sistema 20/12/2023 09:28:39
A etapa fechada foi reiniciada para o item G13. Fornecedor que apresentou um dos seguintes
lances: R$ 4.829.506,4200, R$ 4.895.458,5400 e R$ 4.902.357,9900, poderá enviar um lance único e
fechado até às 09:33:39 do dia 20/12/2023.
Sistema 20/12/2023 09:33:40 A etapa fechada do item G13 foi encerrada. Nenhum fornecedor convocado registrou lance.
Sistema 20/12/2023 09:33:40
A etapa fechada foi reiniciada para o item G13. Fornecedor que apresentou um dos seguintes
lances: R$ 4.902.497,7600, R$ 4.909.288,4200 e R$ 5.097.235,0700, poderá enviar um lance único e
fechado até às 09:38:40 do dia 20/12/2023.
Sistema 20/12/2023 09:38:41 A etapa fechada do item G13 foi encerrada. Nenhum fornecedor convocado registrou lance.
Sistema 20/12/2023 09:38:41
A etapa fechada foi reiniciada para o item G13. Fornecedor que apresentou um dos seguintes
lances: R$ 5.196.732,0900, R$ 5.399.501,0000 e R$ 6.435.217,5000, poderá enviar um lance único e
fechado até às 09:43:41 do dia 20/12/2023.
Sistema 20/12/2023 09:43:42 A etapa fechada do item G13 foi encerrada. Nenhum fornecedor convocado registrou lance.
Sistema 20/12/2023 09:43:42 A etapa fechada foi reiniciada para o item G13. Fornecedor que apresentou lance no valor de R$
6.536.984,7500 poderá enviar um lance único e fechado até às 09:48:42 do dia 20/12/2023.
Sistema 20/12/2023 09:48:43 A etapa fechada do item G13 foi encerrada. Nenhum fornecedor convocado registrou lance.
Sistema 20/12/2023 09:48:43 O item G13 está encerrado.
Sistema para o
participante
04.953.896/0001-84
20/12/2023 09:52:00
Sr. Fornecedor METSOM CONSTRUCOES LTDA, CNPJ 04.953.896/0001-84, você foi convocado
para enviar anexos para o item G13. Prazo para encerrar o envio: 11:51:00 do dia 20/12/2023.
Justificativa: Solicito envio de anexos conforme solicitado via chat: Planilha sintética, planilha
analítica e composição do BDI.
Sistema para o
participante
04.953.896/0001-84
20/12/2023 11:51:00 O item G13 teve a convocação para envio de anexos encerrada às 11:51:00 de 20/12/2023. Nenhum
anexo foi enviado pelo fornecedor METSOM CONSTRUCOES LTDA, CNPJ 04.953.896/0001-84.
Sistema para o
participante
43.050.611/0001-57
21/12/2023 09:19:04
Sr. Fornecedor VERTICO ARQUITETURA E CONSTRUCAO LTDA., CNPJ 43.050.611/0001-57,
você foi convocado para enviar anexos para o item G13. Prazo para encerrar o envio: 11:19:00 do
dia 21/12/2023. Justificativa: Solicito envio de anexos conforme solicitado via chat: Planilha
sintética, planilha analítica e composição do BDI.
Sistema para o
participante
43.050.611/0001-57
21/12/2023 11:19:00
O item G13 teve a convocação para envio de anexos encerrada às 11:19:00 de 21/12/2023. Nenhum
anexo foi enviado pelo fornecedor VERTICO ARQUITETURA E CONSTRUCAO LTDA., CNPJ
43.050.611/0001-57.
Sistema para o
participante
26.160.104/0001-57
21/12/2023 11:30:54
Sr. Fornecedor VERAS ENGENHARIA LTDA, CNPJ 26.160.104/0001-57, você foi convocado para
enviar anexos para o item G13. Prazo para encerrar o envio: 13:30:00 do dia 21/12/2023.
Justificativa: Solicito envio de anexos conforme solicitado via chat: Planilha sintética, planilha
analítica e composição do BDI.
pelo participante
26.160.104/0001-57 21/12/2023 11:51:55 O item G13 teve a convocação para envio de anexos encerrada às 11:51:55 de 21/12/2023. 1 anexo
foi enviado pelo fornecedor VERAS ENGENHARIA LTDA, CNPJ 26.160.104/0001-57.
Sistema 26/12/2023 10:32:42 O item G13 está na etapa de julgamento de proposta no período de intenção de recursos, com
acréscimo de 10 minutos a partir de agora - até 26/12/2023 10:42:42.
Sistema para o
participante
26.160.104/0001-57
26/12/2023 11:31:00
Sr. Fornecedor VERAS ENGENHARIA LTDA, CNPJ 26.160.104/0001-57, você foi convocado para
enviar anexos para o item G13. Prazo para encerrar o envio: 13:30:00 do dia 26/12/2023.
Justificativa: Solicito o envio da documentação de habilitação..
pelo participante
26.160.104/0001-57 26/12/2023 11:49:31 O item G13 teve a convocação para envio de anexos encerrada às 11:49:31 de 26/12/2023. 1 anexo
foi enviado pelo fornecedor VERAS ENGENHARIA LTDA, CNPJ 26.160.104/0001-57.
Sistema 26/12/2023 13:05:30 O item G13 está na etapa de habilitação de fornecedores no período de intenção de recursos, com
acréscimo de 10 minutos a partir de agora - até 26/12/2023 13:15:30.
Sistema 26/12/2023 13:15:39 A fase de recurso do item G13 está aberta até 29/12/2023.
Sistema 30/12/2023 00:00:00 A fase de recurso do item G13 foi finalizada no prazo previsto. Não houve registro de recursos.
10 de 12603/01/2024 11:25

## Página 11

UASG 120645 PREGÃO 62/2023
Eventos do Grupo G13
Data/Hora Descrição
01/11/2023 16:42:59
Fornecedor ZWI ENGENHARIA LTDA, CNPJ 16.843.624/0001-00 convocado para o envio de anexo. Prazo de
encerramento: 01/11/2023 18:42:00. Motivo: Solicito envio de anexos conforme solicitado via chat: Planilha sintética,
planilha analítica e composição do BDI..
03/11/2023 08:17:35 Fornecedor ZWI ENGENHARIA LTDA, CNPJ 16.843.624/0001-00 convocado para o envio de anexo. Prazo de
encerramento: 03/11/2023 10:17:00. Motivo: Prorrogação será concedida por igual período..
03/11/2023 09:38:39 Fornecedor ZWI ENGENHARIA LTDA, CNPJ 16.843.624/0001-00 finalizou o envio de anexo.
13/11/2023 09:37:19
Fornecedor VAN EDIL COMERCIO DE ALIMENTOS E SERVICOS DE MAQUINAS E DECORACOES LTDA, CNPJ
06.222.208/0001-31 convocado para o envio de anexo. Prazo de encerramento: 13/11/2023 11:37:00. Motivo: Solicito envio
de anexos conforme solicitado via chat: Planilha sintética, planilha analítica e composição do BDI.
13/11/2023 13:06:27
Fornecedor D A G G TAVARES PROJETOS ESTRUTURAIS LTDA, CNPJ 33.890.430/0001-85 convocado para o envio de
anexo. Prazo de encerramento: 13/11/2023 15:06:00. Motivo: Solicito envio de anexos conforme solicitado via chat: Planilha
sintética, planilha analítica e composição do BDI.
21/11/2023 10:19:11
Fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21 convocado para o envio de anexo. Prazo de
encerramento: 21/11/2023 12:19:00. Motivo: Solicito envio de anexos conforme solicitado via chat: Planilha sintética,
planilha analítica e composição do BDI.
21/11/2023 12:07:03 Fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21 finalizou o envio de anexo.
27/11/2023 14:11:31 Fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21 convocado para o envio de anexo. Prazo de
encerramento: 27/11/2023 16:11:00. Motivo: Solicito o envio das planilhas ajustadas conforme orientações via chat.
27/11/2023 16:14:03 Fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21 convocado para o envio de anexo. Prazo de
encerramento: 27/11/2023 18:14:00. Motivo: Prorrogação concedida por igual período.
27/11/2023 17:15:33 Fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21 finalizou o envio de anexo.
14/12/2023 09:51:12 Fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21 convocado para o envio de anexo. Prazo de
encerramento: 14/12/2023 11:51:00. Motivo: Solicito o envio das planilhas ajustadas conforme diligência solicitada via chat..
14/12/2023 11:57:08 Fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21 convocado para o envio de anexo. Prazo de
encerramento: 14/12/2023 13:57:00. Motivo: Prorrogação conforme solicitado..
14/12/2023 13:51:52 Fornecedor DX2 ENGENHARIA LTDA, CNPJ 33.493.603/0001-21 finalizou o envio de anexo.
18/12/2023 11:54:19
Fornecedor DSM SERVICOS E COMERCIO LTDA, CNPJ 28.244.608/0001-80 convocado para o envio de anexo. Prazo de
encerramento: 18/12/2023 13:54:00. Motivo: Solicito envio de anexos conforme solicitado via chat: Planilha sintética,
planilha analítica e composição do BDI.
18/12/2023 14:32:31
Fornecedor ETEPAR CONSTRUCOES LTDA, CNPJ 27.595.842/0001-90 convocado para o envio de anexo. Prazo de
encerramento: 18/12/2023 16:32:00. Motivo: Solicito envio de anexos conforme solicitado via chat: Planilha sintética,
planilha analítica e composição do BDI.
20/12/2023 09:52:00
Fornecedor METSOM CONSTRUCOES LTDA, CNPJ 04.953.896/0001-84 convocado para o envio de anexo. Prazo de
encerramento: 20/12/2023 11:51:00. Motivo: Solicito envio de anexos conforme solicitado via chat: Planilha sintética,
planilha analítica e composição do BDI.
21/12/2023 09:19:04
Fornecedor VERTICO ARQUITETURA E CONSTRUCAO LTDA., CNPJ 43.050.611/0001-57 convocado para o envio de
anexo. Prazo de encerramento: 21/12/2023 11:19:00. Motivo: Solicito envio de anexos conforme solicitado via chat: Planilha
sintética, planilha analítica e composição do BDI.
21/12/2023 11:30:54
Fornecedor VERAS ENGENHARIA LTDA, CNPJ 26.160.104/0001-57 convocado para o envio de anexo. Prazo de
encerramento: 21/12/2023 13:30:00. Motivo: Solicito envio de anexos conforme solicitado via chat: Planilha sintética,
planilha analítica e composição do BDI.
21/12/2023 11:51:55 Fornecedor VERAS ENGENHARIA LTDA, CNPJ 26.160.104/0001-57 finalizou o envio de anexo.
26/12/2023 11:31:00 Fornecedor VERAS ENGENHARIA LTDA, CNPJ 26.160.104/0001-57 convocado para o envio de anexo. Prazo de
encerramento: 26/12/2023 13:30:00. Motivo: Solicito o envio da documentação de habilitação..
26/12/2023 11:49:31 Fornecedor VERAS ENGENHARIA LTDA, CNPJ 26.160.104/0001-57 finalizou o envio de anexo.
03/01/2024 11:24:47 Fornecedor VERAS ENGENHARIA LTDA, CNPJ 26.160.104/0001-57 teve a proposta adjudicada, melhor lance: R$
11 de 12603/01/2024 11:25

## Página 12

UASG 120645 PREGÃO 62/2023
Data/Hora Descrição
03/01/2024 11:24:47 4.535.650,0300.
03/01/2024 11:25:17 Item homologado.
FORRO DE FIBRA MINERAL, PARA AMBIENTES COMERCIAIS, INCLUSIVE ESTRUTURA DE FIXACAO. AF_05/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 93,2900
Propostas do Item 678
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 93,2900 Proposta adjudicada
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 84,9800 Proposta
desclassificada
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 78,1100 Proposta
desclassificada
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 105,0700  -
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 100,8700  -
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 101,1000  -
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 99,8800  -
Valor proposta: R$ 138,8800 Valor negociado: Não informado Quantidade ofertada: 1610
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 140,0000  -
Item 678 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²1610
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 140,1000
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
12 de 12603/01/2024 11:25

## Página 13

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 140,0000  -
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 100,0000  -
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 78,0800 Proposta
desclassificada
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 40,0000 Proposta
desclassificada
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 98,0700  -
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 86,0100 Proposta
desclassificada
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 50,0000 Proposta
desclassificada
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 100,1600  -
Valor proposta: R$ 118,0700 Valor negociado: Não informado Quantidade ofertada: 1610
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 96,6700 Proposta
desclassificada
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 42,1000 Proposta
desclassificada
Valor proposta: R$ 138,0000 Valor negociado: Não informado Quantidade ofertada: 1610
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 140,1000  -
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 140,1000  -
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 101,2200  -
13 de 12603/01/2024 11:25

## Página 14

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 101,2200  -
Valor proposta: R$ 101,2200 Valor negociado: Não informado Quantidade ofertada: 1610
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 103,6700  -
Valor proposta: R$ 103,6700 Valor negociado: Não informado Quantidade ofertada: 1610
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 140,1000  -
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 140,1000  -
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 101,4100  -
Valor proposta: R$ 101,4100 Valor negociado: Não informado Quantidade ofertada: 1610
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 105,2200  -
Valor proposta: R$ 105,2200 Valor negociado: Não informado Quantidade ofertada: 1610
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 140,1000  -
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 138,6900 Proposta
desclassificada
Valor proposta: R$ 138,6900 Valor negociado: Não informado Quantidade ofertada: 1610
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 140,1000  -
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 140,1000  -
Valor proposta: R$ 140,1000 Valor negociado: Não informado Quantidade ofertada: 1610
Lances do Item  678
Data/hora Participante Lance
01/11/2023 14:05:07 33.493.603/0001-21 R$ 101,2100
01/11/2023 14:05:15 33.890.430/0001-85 R$ 101,0000
01/11/2023 14:05:20 11.862.800/0001-38 R$ 105,0700
01/11/2023 14:05:44 73.509.440/0001-42 R$ 101,1000
01/11/2023 14:06:05 29.652.879/0001-38 R$ 100,1600
14 de 12603/01/2024 11:25

## Página 15

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:06:12 08.878.462/0001-18 R$ 98,0700
01/11/2023 14:06:32 33.890.430/0001-85 R$ 98,0600
01/11/2023 14:06:39 04.953.896/0001-84 R$ 86,0100
01/11/2023 14:06:49 32.227.070/0001-73 R$ 140,0000
01/11/2023 14:06:55 43.050.611/0001-57 R$ 96,6700
01/11/2023 14:07:02 26.160.104/0001-57 R$ 93,2900
01/11/2023 14:07:07 73.315.905/0001-24 R$ 100,8700
01/11/2023 14:07:16 33.493.603/0001-21 R$ 86,0000
01/11/2023 14:07:37 27.595.842/0001-90 R$ 85,0000
01/11/2023 14:08:17 33.493.603/0001-21 R$ 84,9900
01/11/2023 14:09:58 33.890.430/0001-85 R$ 83,0000
01/11/2023 14:10:06 16.843.624/0001-00 R$ 84,0000
01/11/2023 14:11:03 33.890.430/0001-85 R$ 69,0000
01/11/2023 14:11:14 10.681.640/0001-68 R$ 99,8800
01/11/2023 14:11:29 28.244.608/0001-80 R$ 78,0800
01/11/2023 14:11:46 26.601.871/0001-54 R$ 100,0000
01/11/2023 14:12:51 27.595.842/0001-90 R$ 78,1100
01/11/2023 14:13:15 16.843.624/0001-00 R$ 70,0000
01/11/2023 14:18:07 33.890.430/0001-85 R$ 60,0000
01/11/2023 14:19:05 33.890.430/0001-85 R$ 58,0000
01/11/2023 14:20:08 06.222.208/0001-31 R$ 70,7100
01/11/2023 14:20:16 06.222.208/0001-31 R$ 67,4100
01/11/2023 14:20:24 06.222.208/0001-31 R$ 67,2400
01/11/2023 14:20:28 06.222.208/0001-31 R$ 67,2300
01/11/2023 14:20:51 06.222.208/0001-31 R$ 64,5300
01/11/2023 14:20:55 06.222.208/0001-31 R$ 64,5100
01/11/2023 14:23:39 33.890.430/0001-85 R$ 45,0000
01/11/2023 14:23:57 33.890.430/0001-85 R$ 40,0000
01/11/2023 14:26:11 16.843.624/0001-00 R$ 42,1000
01/11/2023 14:30:09 06.222.208/0001-31 R$ 50,0000
16/11/2023 09:34:22 33.493.603/0001-21 R$ 84,9800
15 de 12603/01/2024 11:25

## Página 16

UASG 120645 PREGÃO 62/2023
FORRO EM MADEIRA PINUS, PARA AMBIENTES RESIDENCIAIS, INCLUSIVE ESTRUTURA DE FIXACAO. AF_05/2017
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 162,9700
Propostas do Item 679
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 162,9700 Proposta adjudicada
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 147,3200 Proposta
desclassificada
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 188,8800  -
Valor proposta: R$ 211,8800 Valor negociado: Não informado Quantidade ofertada: 1500
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 218,0000  -
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 153,2100  -
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 90,0000 Proposta
desclassificada
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 120,0000 Proposta
desclassificada
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 100,0000  -
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 164,0000  -
Item 679 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²1500
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 218,8700
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
16 de 12603/01/2024 11:25

## Página 17

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 164,0000  -
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 170,4900  -
Valor proposta: R$ 193,8500 Valor negociado: Não informado Quantidade ofertada: 1500
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 156,2800 Proposta
desclassificada
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 151,0200 Proposta
desclassificada
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 80,0000 Proposta
desclassificada
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 147,4100 Proposta
desclassificada
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 164,1500  -
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 106,5000 Proposta
desclassificada
Valor proposta: R$ 210,0000 Valor negociado: Não informado Quantidade ofertada: 1500
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 159,7800  -
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 218,8700  -
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 164,3700  -
Valor proposta: R$ 164,3700 Valor negociado: Não informado Quantidade ofertada: 1500
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 218,8700  -
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 173,9800  -
17 de 12603/01/2024 11:25

## Página 18

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 173,9800  -
Valor proposta: R$ 173,9800 Valor negociado: Não informado Quantidade ofertada: 1500
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 218,8700  -
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 218,8700  -
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 218,8700  -
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 218,8700  -
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 155,3900  -
Valor proposta: R$ 155,3900 Valor negociado: Não informado Quantidade ofertada: 1500
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 216,6800 Proposta
desclassificada
Valor proposta: R$ 216,6800 Valor negociado: Não informado Quantidade ofertada: 1500
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 174,1800  -
Valor proposta: R$ 174,1800 Valor negociado: Não informado Quantidade ofertada: 1500
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 218,8700  -
Valor proposta: R$ 218,8700 Valor negociado: Não informado Quantidade ofertada: 1500
Lances do Item  679
Data/hora Participante Lance
01/11/2023 14:05:09 33.493.603/0001-21 R$ 155,3800
01/11/2023 14:05:32 11.862.800/0001-38 R$ 164,1500
01/11/2023 14:05:54 73.509.440/0001-42 R$ 164,0000
01/11/2023 14:06:19 29.652.879/0001-38 R$ 170,4900
01/11/2023 14:06:21 08.878.462/0001-18 R$ 153,2100
01/11/2023 14:06:30 43.050.611/0001-57 R$ 151,0200
01/11/2023 14:06:37 33.890.430/0001-85 R$ 151,0000
01/11/2023 14:06:46 04.953.896/0001-84 R$ 156,2800
18 de 12603/01/2024 11:25

## Página 19

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:06:52 32.227.070/0001-73 R$ 218,0000
01/11/2023 14:07:10 26.160.104/0001-57 R$ 162,9700
01/11/2023 14:07:17 33.493.603/0001-21 R$ 150,9900
01/11/2023 14:07:22 73.315.905/0001-24 R$ 159,7800
01/11/2023 14:07:45 27.595.842/0001-90 R$ 149,0000
01/11/2023 14:08:19 33.493.603/0001-21 R$ 148,9900
01/11/2023 14:10:01 33.890.430/0001-85 R$ 148,0000
01/11/2023 14:10:02 16.843.624/0001-00 R$ 149,0000
01/11/2023 14:10:11 33.493.603/0001-21 R$ 147,9900
01/11/2023 14:11:25 10.681.640/0001-68 R$ 188,8800
01/11/2023 14:11:33 28.244.608/0001-80 R$ 147,3200
01/11/2023 14:11:48 26.601.871/0001-54 R$ 200,0000
01/11/2023 14:11:59 33.493.603/0001-21 R$ 147,3100
01/11/2023 14:12:43 33.890.430/0001-85 R$ 147,0000
01/11/2023 14:12:51 33.493.603/0001-21 R$ 146,9900
01/11/2023 14:12:58 27.595.842/0001-90 R$ 147,4100
01/11/2023 14:15:07 33.890.430/0001-85 R$ 145,0000
01/11/2023 14:15:09 33.493.603/0001-21 R$ 144,9900
01/11/2023 14:17:39 33.890.430/0001-85 R$ 143,0000
01/11/2023 14:17:43 33.493.603/0001-21 R$ 142,9900
01/11/2023 14:18:13 33.890.430/0001-85 R$ 120,0000
01/11/2023 14:19:09 33.890.430/0001-85 R$ 110,0000
01/11/2023 14:19:21 33.493.603/0001-21 R$ 120,0000
01/11/2023 14:20:09 06.222.208/0001-31 R$ 122,8300
01/11/2023 14:20:17 06.222.208/0001-31 R$ 118,2700
01/11/2023 14:20:19 26.601.871/0001-54 R$ 100,0000
01/11/2023 14:20:25 06.222.208/0001-31 R$ 118,0400
01/11/2023 14:20:51 06.222.208/0001-31 R$ 112,0900
01/11/2023 14:20:55 06.222.208/0001-31 R$ 112,0600
01/11/2023 14:24:03 33.890.430/0001-85 R$ 90,0000
01/11/2023 14:26:14 16.843.624/0001-00 R$ 106,5000
01/11/2023 14:30:10 06.222.208/0001-31 R$ 80,0000
19 de 12603/01/2024 11:25

## Página 20

UASG 120645 PREGÃO 62/2023
FORRO EM MADEIRA PINUS, PARA AMBIENTES COMERCIAIS, INCLUSIVE ESTRUTURA DE FIXACAO. AF_05/2017
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 204,5100
Propostas do Item 680
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 204,5100 Proposta adjudicada
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 176,7200 Proposta
desclassificada
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 215,0400  -
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 199,9900  -
Valor proposta: R$ 288,8800 Valor negociado: Não informado Quantidade ofertada: 2200
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 220,0000  -
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 177,0000 Proposta
desclassificada
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 220,9200  -
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 217,7300  -
Valor proposta: R$ 253,2300 Valor negociado: Não informado Quantidade ofertada: 2200
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 140,0000 Proposta
desclassificada
Item 680 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²2200
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 294,5700
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
20 de 12603/01/2024 11:25

## Página 21

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 140,0000 Proposta
desclassificada
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 86,5000 Proposta
desclassificada
Valor proposta: R$ 290,0000 Valor negociado: Não informado Quantidade ofertada: 2200
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 191,6600 Proposta
desclassificada
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 290,0000  -
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 150,0000  -
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 206,2000  -
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 203,2500 Proposta
desclassificada
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 90,0000 Proposta
desclassificada
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 176,9500 Proposta
desclassificada
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 294,5700  -
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 294,5700  -
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 294,5700  -
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 220,7100  -
21 de 12603/01/2024 11:25

## Página 22

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 220,7100  -
Valor proposta: R$ 220,7100 Valor negociado: Não informado Quantidade ofertada: 2200
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 209,1400  -
Valor proposta: R$ 209,1400 Valor negociado: Não informado Quantidade ofertada: 2200
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 294,5700  -
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 221,0500  -
Valor proposta: R$ 221,0500 Valor negociado: Não informado Quantidade ofertada: 2200
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 291,6200 Proposta
desclassificada
Valor proposta: R$ 291,6200 Valor negociado: Não informado Quantidade ofertada: 2200
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 221,2200  -
Valor proposta: R$ 221,2200 Valor negociado: Não informado Quantidade ofertada: 2200
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 294,5700  -
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 294,5700  -
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 294,5700  -
Valor proposta: R$ 294,5700 Valor negociado: Não informado Quantidade ofertada: 2200
Lances do Item  680
Data/hora Participante Lance
01/11/2023 14:05:11 33.493.603/0001-21 R$ 209,1300
01/11/2023 14:05:44 11.862.800/0001-38 R$ 220,9200
01/11/2023 14:06:04 73.509.440/0001-42 R$ 220,0000
01/11/2023 14:06:27 08.878.462/0001-18 R$ 206,2000
01/11/2023 14:06:28 29.652.879/0001-38 R$ 217,7300
01/11/2023 14:06:32 43.050.611/0001-57 R$ 203,2500
01/11/2023 14:06:41 33.890.430/0001-85 R$ 202,9999
01/11/2023 14:06:55 04.953.896/0001-84 R$ 191,6600
22 de 12603/01/2024 11:25

## Página 23

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:06:59 32.227.070/0001-73 R$ 290,0000
01/11/2023 14:07:19 33.493.603/0001-21 R$ 191,6500
01/11/2023 14:07:30 26.160.104/0001-57 R$ 204,5100
01/11/2023 14:07:30 73.315.905/0001-24 R$ 215,0400
01/11/2023 14:07:53 27.595.842/0001-90 R$ 190,0000
01/11/2023 14:08:50 33.890.430/0001-85 R$ 189,0000
01/11/2023 14:09:57 16.843.624/0001-00 R$ 190,0000
01/11/2023 14:10:06 33.890.430/0001-85 R$ 160,0000
01/11/2023 14:10:54 33.890.430/0001-85 R$ 100,0000
01/11/2023 14:11:09 33.890.430/0001-85 R$ 90,0000
01/11/2023 14:11:35 28.244.608/0001-80 R$ 176,9500
01/11/2023 14:11:35 10.681.640/0001-68 R$ 199,9900
01/11/2023 14:11:52 26.601.871/0001-54 R$ 200,0000
01/11/2023 14:13:14 27.595.842/0001-90 R$ 177,0000
01/11/2023 14:13:24 16.843.624/0001-00 R$ 91,0000
01/11/2023 14:19:36 33.493.603/0001-21 R$ 176,7400
01/11/2023 14:20:07 06.222.208/0001-31 R$ 160,6800
01/11/2023 14:20:16 06.222.208/0001-31 R$ 154,3200
01/11/2023 14:20:24 06.222.208/0001-31 R$ 154,0000
01/11/2023 14:20:25 26.601.871/0001-54 R$ 150,0000
01/11/2023 14:20:28 06.222.208/0001-31 R$ 153,9800
01/11/2023 14:20:33 06.222.208/0001-31 R$ 153,9700
01/11/2023 14:20:50 06.222.208/0001-31 R$ 151,7800
01/11/2023 14:20:55 06.222.208/0001-31 R$ 151,7600
01/11/2023 14:26:17 16.843.624/0001-00 R$ 86,5000
01/11/2023 14:30:18 06.222.208/0001-31 R$ 140,0000
16/11/2023 09:34:41 33.493.603/0001-21 R$ 176,7200
23 de 12603/01/2024 11:25

## Página 24

UASG 120645 PREGÃO 62/2023
ACABAMENTOS PARA FORRO (RODA-FORRO EM MADEIRA PINUS). AF_05/2017
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 50,4600
Propostas do Item 681
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 50,4600 Proposta adjudicada
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 44,1600 Proposta
desclassificada
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 43,2700 Proposta
desclassificada
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 49,9900  -
Valor proposta: R$ 68,8800 Valor negociado: Não informado Quantidade ofertada: 1300
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 30,0000 Proposta
desclassificada
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 43,3100 Proposta
desclassificada
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 54,5000  -
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 47,0800 Proposta
desclassificada
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 72,0000  -
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
Item 681 do Grupo G13 - SERVIÇO ENGENHARIA
Critério de julgamento:
Situação:
M1300
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 73,6200
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
24 de 12603/01/2024 11:25

## Página 25

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 53,7400  -
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 51,5300  -
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 70,0000  -
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 50,8000 Proposta
desclassificada
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 55,2100  -
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 53,9000  -
Valor proposta: R$ 62,9400 Valor negociado: Não informado Quantidade ofertada: 1300
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 29,5000 Proposta
desclassificada
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 19,8800 Proposta
desclassificada
Valor proposta: R$ 71,0000 Valor negociado: Não informado Quantidade ofertada: 1300
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 73,6200  -
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 54,5500  -
Valor proposta: R$ 54,5500 Valor negociado: Não informado Quantidade ofertada: 1300
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 52,2700  -
Valor proposta: R$ 52,2700 Valor negociado: Não informado Quantidade ofertada: 1300
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 73,6200  -
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
25 de 12603/01/2024 11:25

## Página 26

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 55,2900  -
Valor proposta: R$ 55,2900 Valor negociado: Não informado Quantidade ofertada: 1300
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 73,6200  -
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 54,6500  -
Valor proposta: R$ 54,6500 Valor negociado: Não informado Quantidade ofertada: 1300
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 73,6200  -
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 73,6200  -
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 73,6200  -
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 73,6200  -
Valor proposta: R$ 73,6200 Valor negociado: Não informado Quantidade ofertada: 1300
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 72,8800 Proposta
desclassificada
Valor proposta: R$ 72,8800 Valor negociado: Não informado Quantidade ofertada: 1300
Lances do Item  681
Data/hora Participante Lance
01/11/2023 14:05:12 33.493.603/0001-21 R$ 52,2600
01/11/2023 14:05:56 11.862.800/0001-38 R$ 55,2100
01/11/2023 14:06:21 73.509.440/0001-42 R$ 54,5000
01/11/2023 14:06:34 08.878.462/0001-18 R$ 51,5300
01/11/2023 14:06:36 29.652.879/0001-38 R$ 53,9000
01/11/2023 14:06:57 43.050.611/0001-57 R$ 50,8000
01/11/2023 14:07:02 32.227.070/0001-73 R$ 72,0000
01/11/2023 14:07:03 04.953.896/0001-84 R$ 47,0800
01/11/2023 14:07:20 33.493.603/0001-21 R$ 47,0700
01/11/2023 14:07:35 26.160.104/0001-57 R$ 50,4600
01/11/2023 14:07:42 73.315.905/0001-24 R$ 53,7400
26 de 12603/01/2024 11:25

## Página 27

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:08:10 27.595.842/0001-90 R$ 47,0600
01/11/2023 14:09:53 16.843.624/0001-00 R$ 48,0000
01/11/2023 14:10:13 33.493.603/0001-21 R$ 47,0500
01/11/2023 14:11:38 28.244.608/0001-80 R$ 43,2700
01/11/2023 14:11:55 26.601.871/0001-54 R$ 70,0000
01/11/2023 14:12:02 10.681.640/0001-68 R$ 49,9900
01/11/2023 14:13:27 27.595.842/0001-90 R$ 43,3100
01/11/2023 14:13:31 16.843.624/0001-00 R$ 44,0000
01/11/2023 14:17:42 33.890.430/0001-85 R$ 40,0000
01/11/2023 14:18:19 33.890.430/0001-85 R$ 38,0000
01/11/2023 14:18:48 33.890.430/0001-85 R$ 30,0000
01/11/2023 14:19:46 33.493.603/0001-21 R$ 44,1700
01/11/2023 14:20:10 06.222.208/0001-31 R$ 40,1600
01/11/2023 14:20:18 06.222.208/0001-31 R$ 38,5700
01/11/2023 14:20:52 06.222.208/0001-31 R$ 38,0100
01/11/2023 14:26:25 16.843.624/0001-00 R$ 19,8800
01/11/2023 14:30:09 06.222.208/0001-31 R$ 29,5000
16/11/2023 09:34:47 33.493.603/0001-21 R$ 44,1600
FORRO EM PLACAS DE GESSO, PARA AMBIENTES RESIDENCIAIS. AF_05/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 50,0500
Propostas do Item 682
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 50,0500 Proposta adjudicada
Item 682 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²1750
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 62,1900
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
27 de 12603/01/2024 11:25

## Página 28

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 50,0500 Proposta adjudicada
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 39,9800 Proposta
desclassificada
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 42,9100 Proposta
desclassificada
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 46,6400  -
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 43,5300  -
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 32,5000 Proposta
desclassificada
Valor proposta: R$ 60,0000 Valor negociado: Não informado Quantidade ofertada: 1750
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 47,0700 Proposta
desclassificada
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 62,0000  -
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 48,9400 Proposta
desclassificada
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 30,0000 Proposta
desclassificada
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 47,1000 Proposta
desclassificada
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 44,7800  -
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 31,0000 Proposta
desclassificada
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
28 de 12603/01/2024 11:25

## Página 29

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 50,0000  -
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 49,9900  -
Valor proposta: R$ 58,8800 Valor negociado: Não informado Quantidade ofertada: 1750
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 51,2600  -
Valor proposta: R$ 56,9400 Valor negociado: Não informado Quantidade ofertada: 1750
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 43,0000  -
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 61,5600 Proposta
desclassificada
Valor proposta: R$ 61,5600 Valor negociado: Não informado Quantidade ofertada: 1750
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 46,7000  -
Valor proposta: R$ 46,7000 Valor negociado: Não informado Quantidade ofertada: 1750
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 52,7000  -
Valor proposta: R$ 52,7000 Valor negociado: Não informado Quantidade ofertada: 1750
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 62,1900  -
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 62,1900  -
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 52,7200  -
Valor proposta: R$ 52,7200 Valor negociado: Não informado Quantidade ofertada: 1750
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 62,1900  -
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 62,1900  -
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
29 de 12603/01/2024 11:25

## Página 30

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 62,1900  -
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 62,1900  -
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 62,1900  -
Valor proposta: R$ 62,1900 Valor negociado: Não informado Quantidade ofertada: 1750
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 43,5300  -
Valor proposta: R$ 43,5300 Valor negociado: Não informado Quantidade ofertada: 1750
Lances do Item  682
Data/hora Participante Lance
01/11/2023 14:05:14 33.493.603/0001-21 R$ 43,5200
01/11/2023 14:06:07 11.862.800/0001-38 R$ 46,6400
01/11/2023 14:06:33 43.050.611/0001-57 R$ 42,9100
01/11/2023 14:06:40 08.878.462/0001-18 R$ 43,5300
01/11/2023 14:06:54 33.890.430/0001-85 R$ 42,5000
01/11/2023 14:06:57 29.652.879/0001-38 R$ 51,2600
01/11/2023 14:07:01 73.509.440/0001-42 R$ 43,0000
01/11/2023 14:07:07 32.227.070/0001-73 R$ 62,0000
01/11/2023 14:07:20 04.953.896/0001-84 R$ 48,9400
01/11/2023 14:07:22 33.493.603/0001-21 R$ 42,4900
01/11/2023 14:07:40 26.160.104/0001-57 R$ 50,0500
01/11/2023 14:07:51 73.315.905/0001-24 R$ 44,7800
01/11/2023 14:09:48 16.843.624/0001-00 R$ 43,0000
01/11/2023 14:11:41 28.244.608/0001-80 R$ 47,0700
01/11/2023 14:11:59 26.601.871/0001-54 R$ 50,0000
01/11/2023 14:12:06 10.681.640/0001-68 R$ 49,9900
01/11/2023 14:13:36 27.595.842/0001-90 R$ 47,1000
01/11/2023 14:19:32 33.890.430/0001-85 R$ 40,0000
01/11/2023 14:19:35 33.493.603/0001-21 R$ 39,9900
01/11/2023 14:20:10 06.222.208/0001-31 R$ 34,3000
01/11/2023 14:20:19 06.222.208/0001-31 R$ 32,9700
30 de 12603/01/2024 11:25

## Página 31

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:20:52 06.222.208/0001-31 R$ 32,5000
01/11/2023 14:24:09 33.890.430/0001-85 R$ 31,0000
01/11/2023 14:26:28 16.843.624/0001-00 R$ 32,5000
01/11/2023 14:30:09 06.222.208/0001-31 R$ 30,0000
16/11/2023 09:34:52 33.493.603/0001-21 R$ 39,9800
FORRO EM DRYWALL, PARA AMBIENTES RESIDENCIAIS, INCLUSIVE ESTRUTURA DE FIXACAO. AF_05/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 68,7500
Propostas do Item 683
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 68,7500 Proposta adjudicada
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 58,1000 Proposta
desclassificada
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 45,0000 Proposta
desclassificada
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 60,4300 Proposta
desclassificada
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 69,7400  -
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 66,8300 Proposta
desclassificada
Item 683 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²9167
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 96,8600
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
31 de 12603/01/2024 11:25

## Página 32

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 66,8300 Proposta
desclassificada
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 68,7000  -
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 96,0000  -
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 58,0000 Proposta
desclassificada
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 78,8800  -
Valor proposta: R$ 88,8800 Valor negociado: Não informado Quantidade ofertada: 9167
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 90,0000  -
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 72,6400  -
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 60,3900 Proposta
desclassificada
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 67,8000  -
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 64,9700 Proposta
desclassificada
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 34,6500 Proposta
desclassificada
Valor proposta: R$ 94,0000 Valor negociado: Não informado Quantidade ofertada: 9167
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 72,8500  -
Valor proposta: R$ 84,1000 Valor negociado: Não informado Quantidade ofertada: 9167
32 de 12603/01/2024 11:25

## Página 33

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 95,8900 Proposta
desclassificada
Valor proposta: R$ 95,8900 Valor negociado: Não informado Quantidade ofertada: 9167
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 73,9900  -
Valor proposta: R$ 73,9900 Valor negociado: Não informado Quantidade ofertada: 9167
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 74,0800  -
Valor proposta: R$ 74,0800 Valor negociado: Não informado Quantidade ofertada: 9167
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 68,7700  -
Valor proposta: R$ 68,7700 Valor negociado: Não informado Quantidade ofertada: 9167
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 96,8600  -
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 96,8600  -
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 96,8600  -
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 96,8600  -
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 96,8600  -
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 96,8600  -
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 72,7400  -
Valor proposta: R$ 72,7400 Valor negociado: Não informado Quantidade ofertada: 9167
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 96,8600  -
Valor proposta: R$ 96,8600 Valor negociado: Não informado Quantidade ofertada: 9167
Lances do Item  683
Data/hora Participante Lance
33 de 12603/01/2024 11:25

## Página 34

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:05:15 33.493.603/0001-21 R$ 68,7600
01/11/2023 14:06:18 11.862.800/0001-38 R$ 72,6400
01/11/2023 14:06:35 43.050.611/0001-57 R$ 66,8300
01/11/2023 14:06:47 08.878.462/0001-18 R$ 67,8000
01/11/2023 14:07:08 33.890.430/0001-85 R$ 66,5989
01/11/2023 14:07:11 32.227.070/0001-73 R$ 96,0000
01/11/2023 14:07:14 73.509.440/0001-42 R$ 68,7000
01/11/2023 14:07:25 33.493.603/0001-21 R$ 66,5889
01/11/2023 14:07:30 04.953.896/0001-84 R$ 64,9700
01/11/2023 14:07:46 26.160.104/0001-57 R$ 68,7500
01/11/2023 14:07:59 73.315.905/0001-24 R$ 69,7400
01/11/2023 14:08:13 29.652.879/0001-38 R$ 72,8500
01/11/2023 14:08:22 33.493.603/0001-21 R$ 64,9600
01/11/2023 14:09:44 16.843.624/0001-00 R$ 65,0000
01/11/2023 14:11:43 28.244.608/0001-80 R$ 60,3900
01/11/2023 14:12:02 26.601.871/0001-54 R$ 90,0000
01/11/2023 14:12:05 33.493.603/0001-21 R$ 60,3800
01/11/2023 14:12:10 10.681.640/0001-68 R$ 78,8800
01/11/2023 14:12:49 33.890.430/0001-85 R$ 58,0000
01/11/2023 14:13:38 16.843.624/0001-00 R$ 59,0000
01/11/2023 14:13:52 27.595.842/0001-90 R$ 60,4300
01/11/2023 14:19:57 33.493.603/0001-21 R$ 58,1200
01/11/2023 14:20:09 06.222.208/0001-31 R$ 51,9400
01/11/2023 14:20:18 06.222.208/0001-31 R$ 49,8000
01/11/2023 14:20:22 06.222.208/0001-31 R$ 49,6900
01/11/2023 14:20:48 16.843.624/0001-00 R$ 50,0000
01/11/2023 14:20:49 06.222.208/0001-31 R$ 48,9500
01/11/2023 14:26:32 16.843.624/0001-00 R$ 34,6500
01/11/2023 14:30:09 06.222.208/0001-31 R$ 45,0000
16/11/2023 09:34:58 33.493.603/0001-21 R$ 58,1000
34 de 12603/01/2024 11:25

## Página 35

UASG 120645 PREGÃO 62/2023
PAREDE COM PLACAS DE GESSO ACARTONADO (DRYWALL), PARA USO INTERNO, COM DUAS FACES SIMPLES E
ESTRUTURA METALICA COM GUIAS SIMPLES, SEM VAOS. AF_06/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 84,8200
Propostas do Item 684
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 84,8200 Proposta adjudicada
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 74,9800 Proposta
desclassificada
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 72,2300 Proposta
desclassificada
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 90,8700  -
Valor proposta: R$ 106,5100 Valor negociado: Não informado Quantidade ofertada: 3335
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 87,0000  -
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 72,2000 Proposta
desclassificada
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 51,9000 Proposta
desclassificada
Valor proposta: R$ 120,0000 Valor negociado: Não informado Quantidade ofertada: 3335
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 60,0000 Proposta
desclassificada
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 87,4900  -
Item 684 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²3335
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 124,9800
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
35 de 12603/01/2024 11:25

## Página 36

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 87,4900  -
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 86,2400 Proposta
desclassificada
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 89,9900  -
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 99,9900  -
Valor proposta: R$ 122,8800 Valor negociado: Não informado Quantidade ofertada: 3335
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 120,0000  -
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 120,0000  -
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 78,8100 Proposta
desclassificada
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 60,0000 Proposta
desclassificada
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 93,7300  -
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 124,9800  -
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 91,9400  -
Valor proposta: R$ 91,9400 Valor negociado: Não informado Quantidade ofertada: 3335
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 124,9800  -
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 92,0700  -
36 de 12603/01/2024 11:25

## Página 37

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 92,0700  -
Valor proposta: R$ 92,0700 Valor negociado: Não informado Quantidade ofertada: 3335
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 124,9800  -
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 124,9800  -
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 88,7300  -
Valor proposta: R$ 88,7300 Valor negociado: Não informado Quantidade ofertada: 3335
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 124,9800  -
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 124,9800  -
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 123,7300 Proposta
desclassificada
Valor proposta: R$ 123,7300 Valor negociado: Não informado Quantidade ofertada: 3335
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 124,9800  -
Valor proposta: R$ 124,9800 Valor negociado: Não informado Quantidade ofertada: 3335
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 93,8600  -
Valor proposta: R$ 93,8600 Valor negociado: Não informado Quantidade ofertada: 3335
Lances do Item  684
Data/hora Participante Lance
01/11/2023 14:05:17 33.493.603/0001-21 R$ 88,7200
01/11/2023 14:06:32 11.862.800/0001-38 R$ 93,7300
01/11/2023 14:06:46 33.890.430/0001-85 R$ 88,0000
01/11/2023 14:06:53 08.878.462/0001-18 R$ 87,4900
01/11/2023 14:06:59 43.050.611/0001-57 R$ 86,2400
01/11/2023 14:07:14 32.227.070/0001-73 R$ 120,0000
01/11/2023 14:07:25 33.890.430/0001-85 R$ 86,2000
01/11/2023 14:07:27 73.509.440/0001-42 R$ 87,0000
37 de 12603/01/2024 11:25

## Página 38

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:07:27 33.493.603/0001-21 R$ 86,2300
01/11/2023 14:07:43 04.953.896/0001-84 R$ 78,8100
01/11/2023 14:07:51 26.160.104/0001-57 R$ 84,8200
01/11/2023 14:08:08 73.315.905/0001-24 R$ 89,9900
01/11/2023 14:08:15 29.652.879/0001-38 R$ 90,8700
01/11/2023 14:08:24 33.493.603/0001-21 R$ 78,8000
01/11/2023 14:09:39 16.843.624/0001-00 R$ 79,0000
01/11/2023 14:11:45 28.244.608/0001-80 R$ 72,2000
01/11/2023 14:12:05 26.601.871/0001-54 R$ 120,0000
01/11/2023 14:12:16 10.681.640/0001-68 R$ 99,9900
01/11/2023 14:13:44 16.843.624/0001-00 R$ 73,0000
01/11/2023 14:14:07 27.595.842/0001-90 R$ 72,2300
01/11/2023 14:15:14 33.890.430/0001-85 R$ 70,0000
01/11/2023 14:18:25 33.890.430/0001-85 R$ 60,0000
01/11/2023 14:20:05 33.493.603/0001-21 R$ 74,9900
01/11/2023 14:20:16 06.222.208/0001-31 R$ 105,0000
01/11/2023 14:20:23 06.222.208/0001-31 R$ 104,0100
01/11/2023 14:20:27 06.222.208/0001-31 R$ 103,9500
01/11/2023 14:20:34 06.222.208/0001-31 R$ 103,9400
01/11/2023 14:20:51 06.222.208/0001-31 R$ 97,0700
01/11/2023 14:20:55 06.222.208/0001-31 R$ 97,0300
01/11/2023 14:26:35 16.843.624/0001-00 R$ 51,9000
01/11/2023 14:30:09 06.222.208/0001-31 R$ 60,0000
16/11/2023 09:35:03 33.493.603/0001-21 R$ 74,9800
38 de 12603/01/2024 11:25

## Página 39

UASG 120645 PREGÃO 62/2023
PAREDE COM PLACAS DE GESSO ACARTONADO (DRYWALL), PARA USO INTERNO, COM DUAS FACES SIMPLES E
ESTRUTURA METALICA COM GUIAS SIMPLES, COM VAOS AF_06/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 96,3100
Propostas do Item 685
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 96,3100 Proposta adjudicada
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 138,0000  -
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 103,1100  -
Valor proposta: R$ 120,7900 Valor negociado: Não informado Quantidade ofertada: 2415
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 60,0000 Proposta
desclassificada
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 106,2500  -
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 85,0000 Proposta
desclassificada
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 102,0000  -
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 51,9000 Proposta
desclassificada
Valor proposta: R$ 138,0000 Valor negociado: Não informado Quantidade ofertada: 2415
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 99,1700  -
Item 685 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²2415
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 141,6700
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
39 de 12603/01/2024 11:25

## Página 40

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 99,1700  -
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 56,9000 Proposta
desclassificada
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 120,0000  -
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 89,5100 Proposta
desclassificada
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 82,0300 Proposta
desclassificada
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 98,0000  -
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 97,7500 Proposta
desclassificada
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 98,8800  -
Valor proposta: R$ 138,8800 Valor negociado: Não informado Quantidade ofertada: 2415
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 82,0900 Proposta
desclassificada
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 141,6700  -
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 141,6700  -
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 141,6700  -
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 104,3500  -
40 de 12603/01/2024 11:25

## Página 41

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 104,3500  -
Valor proposta: R$ 104,3500 Valor negociado: Não informado Quantidade ofertada: 2415
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 106,3900  -
Valor proposta: R$ 106,3900 Valor negociado: Não informado Quantidade ofertada: 2415
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 141,6700  -
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 141,6700  -
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 141,6700  -
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 104,4900  -
Valor proposta: R$ 104,4900 Valor negociado: Não informado Quantidade ofertada: 2415
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 100,5800  -
Valor proposta: R$ 100,5800 Valor negociado: Não informado Quantidade ofertada: 2415
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 141,6700  -
Valor proposta: R$ 141,6700 Valor negociado: Não informado Quantidade ofertada: 2415
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 140,2500 Proposta
desclassificada
Valor proposta: R$ 140,2500 Valor negociado: Não informado Quantidade ofertada: 2415
Lances do Item  685
Data/hora Participante Lance
01/11/2023 14:05:19 33.493.603/0001-21 R$ 100,5700
01/11/2023 14:06:37 43.050.611/0001-57 R$ 97,7500
01/11/2023 14:06:48 11.862.800/0001-38 R$ 106,2500
01/11/2023 14:06:49 33.890.430/0001-85 R$ 98,6000
01/11/2023 14:06:55 33.890.430/0001-85 R$ 97,0000
01/11/2023 14:06:59 08.878.462/0001-18 R$ 99,1700
01/11/2023 14:07:18 32.227.070/0001-73 R$ 138,0000
01/11/2023 14:07:29 33.493.603/0001-21 R$ 96,9900
41 de 12603/01/2024 11:25

## Página 42

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:07:38 73.509.440/0001-42 R$ 98,0000
01/11/2023 14:07:52 04.953.896/0001-84 R$ 89,5100
01/11/2023 14:08:00 26.160.104/0001-57 R$ 96,3100
01/11/2023 14:08:16 29.652.879/0001-38 R$ 103,1100
01/11/2023 14:08:18 73.315.905/0001-24 R$ 102,0000
01/11/2023 14:09:34 16.843.624/0001-00 R$ 90,0000
01/11/2023 14:10:14 33.493.603/0001-21 R$ 89,5000
01/11/2023 14:10:15 33.890.430/0001-85 R$ 60,0000
01/11/2023 14:11:48 28.244.608/0001-80 R$ 82,0300
01/11/2023 14:12:10 26.601.871/0001-54 R$ 140,0000
01/11/2023 14:12:23 10.681.640/0001-68 R$ 98,8800
01/11/2023 14:13:51 16.843.624/0001-00 R$ 61,0000
01/11/2023 14:14:14 27.595.842/0001-90 R$ 82,0900
01/11/2023 14:20:08 06.222.208/0001-31 R$ 68,2400
01/11/2023 14:20:12 33.493.603/0001-21 R$ 85,0000
01/11/2023 14:20:17 06.222.208/0001-31 R$ 64,7500
01/11/2023 14:20:24 06.222.208/0001-31 R$ 64,5700
01/11/2023 14:20:28 06.222.208/0001-31 R$ 64,5600
01/11/2023 14:20:35 26.601.871/0001-54 R$ 120,0000
01/11/2023 14:20:49 06.222.208/0001-31 R$ 63,3600
01/11/2023 14:20:57 06.222.208/0001-31 R$ 63,3500
01/11/2023 14:26:37 16.843.624/0001-00 R$ 51,9000
01/11/2023 14:30:12 06.222.208/0001-31 R$ 56,9000
42 de 12603/01/2024 11:25

## Página 43

UASG 120645 PREGÃO 62/2023
PAREDE COM PLACAS DE GESSO ACARTONADO (DRYWALL), PARA USO INTERNO, COM DUAS FACES SIMPLES E
ESTRUTURA METALICA COM GUIAS DUPLAS, SEM VAOS. AF_06/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 113,3200
Propostas do Item 686
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 113,3200 Proposta adjudicada
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 100,5000 Proposta
desclassificada
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 78,0000 Proposta
desclassificada
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 96,1500 Proposta
desclassificada
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 120,7200  -
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 120,0000  -
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 54,5500 Proposta
desclassificada
Valor proposta: R$ 152,0000 Valor negociado: Não informado Quantidade ofertada: 1437
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 117,3600  -
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 80,0000 Proposta
desclassificada
Item 686 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²1437
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 167,6600
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
43 de 12603/01/2024 11:25

## Página 44

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 80,0000 Proposta
desclassificada
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 115,6900 Proposta
desclassificada
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 120,0000  -
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 121,5000  -
Valor proposta: R$ 142,5900 Valor negociado: Não informado Quantidade ofertada: 1437
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 160,0000  -
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 125,7400  -
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 99,9900  -
Valor proposta: R$ 148,8800 Valor negociado: Não informado Quantidade ofertada: 1437
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 96,1400 Proposta
desclassificada
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 105,0700 Proposta
desclassificada
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 167,6600  -
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 120,7100  -
Valor proposta: R$ 120,7100 Valor negociado: Não informado Quantidade ofertada: 1437
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 122,8600  -
Valor proposta: R$ 122,8600 Valor negociado: Não informado Quantidade ofertada: 1437
44 de 12603/01/2024 11:25

## Página 45

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 123,0400  -
Valor proposta: R$ 123,0400 Valor negociado: Não informado Quantidade ofertada: 1437
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 167,6600  -
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 167,6600  -
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 167,6600  -
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 165,9800 Proposta
desclassificada
Valor proposta: R$ 165,9800 Valor negociado: Não informado Quantidade ofertada: 1437
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 125,9100  -
Valor proposta: R$ 125,9100 Valor negociado: Não informado Quantidade ofertada: 1437
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 167,6600  -
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 167,6600  -
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 167,6600  -
Valor proposta: R$ 167,6600 Valor negociado: Não informado Quantidade ofertada: 1437
Lances do Item  686
Data/hora Participante Lance
01/11/2023 14:05:22 33.493.603/0001-21 R$ 120,7000
01/11/2023 14:07:01 43.050.611/0001-57 R$ 115,6900
01/11/2023 14:07:02 11.862.800/0001-38 R$ 125,7400
01/11/2023 14:07:07 08.878.462/0001-18 R$ 117,3600
01/11/2023 14:07:22 32.227.070/0001-73 R$ 160,0000
01/11/2023 14:07:50 73.509.440/0001-42 R$ 120,0000
01/11/2023 14:08:05 04.953.896/0001-84 R$ 105,0700
01/11/2023 14:08:09 26.160.104/0001-57 R$ 113,3200
45 de 12603/01/2024 11:25

## Página 46

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:08:18 29.652.879/0001-38 R$ 121,5000
01/11/2023 14:08:26 33.493.603/0001-21 R$ 115,6800
01/11/2023 14:08:28 73.315.905/0001-24 R$ 120,7200
01/11/2023 14:09:30 16.843.624/0001-00 R$ 106,0000
01/11/2023 14:10:17 33.493.603/0001-21 R$ 105,0600
01/11/2023 14:11:22 33.890.430/0001-85 R$ 80,0000
01/11/2023 14:11:52 28.244.608/0001-80 R$ 96,1400
01/11/2023 14:12:16 26.601.871/0001-54 R$ 150,0000
01/11/2023 14:12:44 10.681.640/0001-68 R$ 99,9900
01/11/2023 14:13:59 16.843.624/0001-00 R$ 81,0000
01/11/2023 14:14:23 27.595.842/0001-90 R$ 96,1500
01/11/2023 14:20:07 06.222.208/0001-31 R$ 89,9900
01/11/2023 14:20:16 06.222.208/0001-31 R$ 86,3000
01/11/2023 14:20:21 33.493.603/0001-21 R$ 100,6000
01/11/2023 14:20:22 06.222.208/0001-31 R$ 86,1100
01/11/2023 14:20:28 06.222.208/0001-31 R$ 86,1000
01/11/2023 14:20:39 26.601.871/0001-54 R$ 120,0000
01/11/2023 14:20:49 06.222.208/0001-31 R$ 84,8300
01/11/2023 14:20:57 06.222.208/0001-31 R$ 84,8200
01/11/2023 14:26:46 16.843.624/0001-00 R$ 54,5500
01/11/2023 14:30:11 06.222.208/0001-31 R$ 78,0000
16/11/2023 09:35:35 33.493.603/0001-21 R$ 100,5000
46 de 12603/01/2024 11:25

## Página 47

UASG 120645 PREGÃO 62/2023
PAREDE COM PLACAS DE GESSO ACARTONADO (DRYWALL), PARA USO INTERNO, COM DUAS FACES SIMPLES E
ESTRUTURA METALICA COM GUIAS DUPLAS, COM VAOS. AF_06/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 135,3500
Propostas do Item 687
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 135,3500 Proposta adjudicada
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 75,2000 Proposta
desclassificada
Valor proposta: R$ 192,0000 Valor negociado: Não informado Quantidade ofertada: 1110
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 144,0100  -
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 114,9700 Proposta
desclassificada
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 150,0100  -
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 122,8800  -
Valor proposta: R$ 188,8800 Valor negociado: Não informado Quantidade ofertada: 1110
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 120,0000 Proposta
desclassificada
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 100,0000  -
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 146,0000  -
Item 687 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²1110
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 200,0200
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
47 de 12603/01/2024 11:25

## Página 48

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 146,0000  -
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 114,9300 Proposta
desclassificada
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 125,5800 Proposta
desclassificada
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 200,0000  -
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 85,0000 Proposta
desclassificada
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 100,0000 Proposta
desclassificada
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 145,0900  -
Valor proposta: R$ 170,1700 Valor negociado: Não informado Quantidade ofertada: 1110
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 138,0100 Proposta
desclassificada
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 140,0100  -
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 150,2200  -
Valor proposta: R$ 150,2200 Valor negociado: Não informado Quantidade ofertada: 1110
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 200,0200  -
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 200,0200  -
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 200,0200  -
48 de 12603/01/2024 11:25

## Página 49

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 200,0200  -
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 200,0200  -
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 200,0200  -
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 200,0200  -
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 150,0100  -
Valor proposta: R$ 150,0100 Valor negociado: Não informado Quantidade ofertada: 1110
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 198,0100 Proposta
desclassificada
Valor proposta: R$ 198,0100 Valor negociado: Não informado Quantidade ofertada: 1110
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 146,9200  -
Valor proposta: R$ 146,9200 Valor negociado: Não informado Quantidade ofertada: 1110
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 146,7100  -
Valor proposta: R$ 146,7100 Valor negociado: Não informado Quantidade ofertada: 1110
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 200,0200  -
Valor proposta: R$ 200,0200 Valor negociado: Não informado Quantidade ofertada: 1110
Lances do Item  687
Data/hora Participante Lance
01/11/2023 14:05:23 33.493.603/0001-21 R$ 146,7000
01/11/2023 14:06:38 43.050.611/0001-57 R$ 138,0100
01/11/2023 14:07:13 08.878.462/0001-18 R$ 140,0100
01/11/2023 14:07:13 11.862.800/0001-38 R$ 150,0100
01/11/2023 14:07:26 32.227.070/0001-73 R$ 200,0000
01/11/2023 14:08:03 73.509.440/0001-42 R$ 146,0000
01/11/2023 14:08:13 04.953.896/0001-84 R$ 125,5800
01/11/2023 14:08:15 26.160.104/0001-57 R$ 135,3500
49 de 12603/01/2024 11:25

## Página 50

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:08:19 29.652.879/0001-38 R$ 145,0900
01/11/2023 14:08:27 33.493.603/0001-21 R$ 138,0000
01/11/2023 14:08:38 73.315.905/0001-24 R$ 144,0100
01/11/2023 14:09:26 16.843.624/0001-00 R$ 126,0000
01/11/2023 14:11:15 33.493.603/0001-21 R$ 125,5700
01/11/2023 14:11:54 28.244.608/0001-80 R$ 114,9300
01/11/2023 14:12:21 26.601.871/0001-54 R$ 200,0000
01/11/2023 14:13:36 10.681.640/0001-68 R$ 122,8800
01/11/2023 14:14:04 16.843.624/0001-00 R$ 115,0000
01/11/2023 14:14:36 27.595.842/0001-90 R$ 114,9700
01/11/2023 14:17:51 33.890.430/0001-85 R$ 100,0000
01/11/2023 14:18:33 16.843.624/0001-00 R$ 101,0000
01/11/2023 14:20:07 06.222.208/0001-31 R$ 100,3900
01/11/2023 14:20:15 06.222.208/0001-31 R$ 95,6500
01/11/2023 14:20:21 06.222.208/0001-31 R$ 95,4100
01/11/2023 14:20:32 33.493.603/0001-21 R$ 120,0000
01/11/2023 14:20:49 26.601.871/0001-54 R$ 100,0000
01/11/2023 14:20:50 06.222.208/0001-31 R$ 93,7800
01/11/2023 14:20:55 06.222.208/0001-31 R$ 93,7700
01/11/2023 14:27:02 16.843.624/0001-00 R$ 75,2000
01/11/2023 14:30:11 06.222.208/0001-31 R$ 85,0000
50 de 12603/01/2024 11:25

## Página 51

UASG 120645 PREGÃO 62/2023
PAREDE COM PLACAS DE GESSO ACARTONADO (DRYWALL), PARA USO INTERNO, COM UMA FACE SIMPLES E OUTRA
FACE DUPLA E ESTRUTURA METALICA COM GUIAS SIMPLES, SEM VAOS. AF_06/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 108,0200
Propostas do Item 688
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 108,0200 Proposta adjudicada
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 96,0000 Proposta
desclassificada
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 91,4300 Proposta
desclassificada
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 150,0000  -
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 120,1200  -
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 91,4500 Proposta
desclassificada
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 100,0300 Proposta
desclassificada
Valor proposta: R$ 108,7000 Valor negociado: Não informado Quantidade ofertada: 620
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 160,0000  -
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 112,1200  -
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
Item 688 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²620
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 160,1700
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
51 de 12603/01/2024 11:25

## Página 52

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 122,8800  -
Valor proposta: R$ 148,8800 Valor negociado: Não informado Quantidade ofertada: 620
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 110,5200 Proposta
desclassificada
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 62,0500 Proposta
desclassificada
Valor proposta: R$ 152,0000 Valor negociado: Não informado Quantidade ofertada: 620
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 80,0000 Proposta
desclassificada
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 112,0000  -
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 115,3200  -
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 115,8200  -
Valor proposta: R$ 136,1200 Valor negociado: Não informado Quantidade ofertada: 620
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 160,1700  -
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 160,1700  -
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 120,2900  -
Valor proposta: R$ 120,2900 Valor negociado: Não informado Quantidade ofertada: 620
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 160,1700  -
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 160,1700  -
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 117,3100  -
52 de 12603/01/2024 11:25

## Página 53

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 117,3100  -
Valor proposta: R$ 117,3100 Valor negociado: Não informado Quantidade ofertada: 620
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 160,1700  -
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 117,1400  -
Valor proposta: R$ 117,1400 Valor negociado: Não informado Quantidade ofertada: 620
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 160,1700 Proposta
desclassificada
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 160,1700  -
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 115,3200  -
Valor proposta: R$ 115,3200 Valor negociado: Não informado Quantidade ofertada: 620
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 158,5600 Proposta
desclassificada
Valor proposta: R$ 158,5600 Valor negociado: Não informado Quantidade ofertada: 620
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 160,1700  -
Valor proposta: R$ 160,1700 Valor negociado: Não informado Quantidade ofertada: 620
Lances do Item  688
Data/hora Participante Lance
01/11/2023 14:05:25 33.493.603/0001-21 R$ 108,6900
01/11/2023 14:07:02 43.050.611/0001-57 R$ 110,5200
01/11/2023 14:07:19 08.878.462/0001-18 R$ 112,1200
01/11/2023 14:07:23 11.862.800/0001-38 R$ 120,1200
01/11/2023 14:07:29 32.227.070/0001-73 R$ 160,0000
01/11/2023 14:08:14 73.509.440/0001-42 R$ 112,0000
01/11/2023 14:08:20 29.652.879/0001-38 R$ 115,8200
01/11/2023 14:08:26 26.160.104/0001-57 R$ 108,0200
01/11/2023 14:08:50 73.315.905/0001-24 R$ 115,3200
01/11/2023 14:09:21 16.843.624/0001-00 R$ 109,0000
53 de 12603/01/2024 11:25

## Página 54

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:10:23 04.953.896/0001-84 R$ 100,0300
01/11/2023 14:11:16 33.493.603/0001-21 R$ 100,0200
01/11/2023 14:11:56 28.244.608/0001-80 R$ 91,4300
01/11/2023 14:12:24 26.601.871/0001-54 R$ 160,0000
01/11/2023 14:13:40 10.681.640/0001-68 R$ 122,8800
01/11/2023 14:14:10 16.843.624/0001-00 R$ 92,0000
01/11/2023 14:14:47 27.595.842/0001-90 R$ 91,4500
01/11/2023 14:20:08 06.222.208/0001-31 R$ 90,7200
01/11/2023 14:20:17 06.222.208/0001-31 R$ 87,4200
01/11/2023 14:20:24 06.222.208/0001-31 R$ 87,2500
01/11/2023 14:20:39 33.493.603/0001-21 R$ 96,1000
01/11/2023 14:20:48 06.222.208/0001-31 R$ 86,1100
01/11/2023 14:20:53 26.601.871/0001-54 R$ 150,0000
01/11/2023 14:20:57 06.222.208/0001-31 R$ 86,1000
01/11/2023 14:27:20 16.843.624/0001-00 R$ 62,0500
01/11/2023 14:30:10 06.222.208/0001-31 R$ 80,0000
16/11/2023 09:35:46 33.493.603/0001-21 R$ 96,0000
PAREDE COM PLACAS DE GESSO ACARTONADO (DRYWALL), PARA USO INTERNO, COM UMA FACE SIMPLES E OUTRA
FACE DUPLA E ESTRUTURA METALICA COM GUIAS SIMPLES, COM VAOS. AF_06/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 120,0400
Propostas do Item 689
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 120,0400 Proposta adjudicada
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
Item 689 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²517
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 177,5300
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
54 de 12603/01/2024 11:25

## Página 55

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 106,5100 Proposta
desclassificada
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 128,6900  -
Valor proposta: R$ 151,0500 Valor negociado: Não informado Quantidade ofertada: 517
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 111,3500 Proposta
desclassificada
Valor proposta: R$ 120,8900 Valor negociado: Não informado Quantidade ofertada: 517
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 57,9700 Proposta
desclassificada
Valor proposta: R$ 172,0000 Valor negociado: Não informado Quantidade ofertada: 517
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 122,5000 Proposta
desclassificada
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 124,2700  -
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 101,9000 Proposta
desclassificada
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 69,0000 Proposta
desclassificada
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 127,8200  -
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 122,8800  -
Valor proposta: R$ 158,8800 Valor negociado: Não informado Quantidade ofertada: 517
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 175,0000  -
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 122,0000  -
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 170,0000  -
55 de 12603/01/2024 11:25

## Página 56

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 170,0000  -
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 101,8700 Proposta
desclassificada
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 133,1400  -
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 70,0000 Proposta
desclassificada
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 177,5300  -
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 177,5300  -
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 177,5300  -
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 177,5300  -
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 175,7500 Proposta
desclassificada
Valor proposta: R$ 175,7500 Valor negociado: Não informado Quantidade ofertada: 517
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 177,5300  -
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 177,5300  -
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 126,0400  -
Valor proposta: R$ 126,0400 Valor negociado: Não informado Quantidade ofertada: 517
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 177,5300  -
56 de 12603/01/2024 11:25

## Página 57

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 177,5300  -
Valor proposta: R$ 177,5300 Valor negociado: Não informado Quantidade ofertada: 517
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 130,1800  -
Valor proposta: R$ 130,1800 Valor negociado: Não informado Quantidade ofertada: 517
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 133,3300  -
Valor proposta: R$ 133,3300 Valor negociado: Não informado Quantidade ofertada: 517
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 130,3700  -
Valor proposta: R$ 130,3700 Valor negociado: Não informado Quantidade ofertada: 517
Lances do Item  689
Data/hora Participante Lance
01/11/2023 14:05:27 33.493.603/0001-21 R$ 120,8800
01/11/2023 14:05:42 33.890.430/0001-85 R$ 120,0000
01/11/2023 14:07:04 43.050.611/0001-57 R$ 122,5000
01/11/2023 14:07:32 08.878.462/0001-18 R$ 124,2700
01/11/2023 14:07:33 11.862.800/0001-38 R$ 133,1400
01/11/2023 14:07:35 32.227.070/0001-73 R$ 175,0000
01/11/2023 14:08:22 29.652.879/0001-38 R$ 128,6900
01/11/2023 14:08:26 73.509.440/0001-42 R$ 122,0000
01/11/2023 14:08:30 33.493.603/0001-21 R$ 119,9900
01/11/2023 14:08:36 26.160.104/0001-57 R$ 120,0400
01/11/2023 14:09:02 73.315.905/0001-24 R$ 127,8200
01/11/2023 14:09:17 16.843.624/0001-00 R$ 120,0000
01/11/2023 14:09:19 33.890.430/0001-85 R$ 118,0000
01/11/2023 14:10:24 33.890.430/0001-85 R$ 70,0000
01/11/2023 14:10:31 04.953.896/0001-84 R$ 111,3500
01/11/2023 14:12:00 28.244.608/0001-80 R$ 101,8700
01/11/2023 14:12:27 26.601.871/0001-54 R$ 170,0000
01/11/2023 14:13:46 10.681.640/0001-68 R$ 122,8800
01/11/2023 14:14:17 16.843.624/0001-00 R$ 71,0000
01/11/2023 14:14:58 27.595.842/0001-90 R$ 101,9000
01/11/2023 14:20:07 06.222.208/0001-31 R$ 83,5200
57 de 12603/01/2024 11:25

## Página 58

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:20:16 06.222.208/0001-31 R$ 79,0500
01/11/2023 14:20:25 06.222.208/0001-31 R$ 78,8200
01/11/2023 14:20:49 06.222.208/0001-31 R$ 77,2800
01/11/2023 14:20:56 06.222.208/0001-31 R$ 77,2700
01/11/2023 14:21:32 33.493.603/0001-21 R$ 106,5200
01/11/2023 14:27:30 16.843.624/0001-00 R$ 57,9700
01/11/2023 14:30:11 06.222.208/0001-31 R$ 69,0000
16/11/2023 09:35:51 33.493.603/0001-21 R$ 106,5100
PAREDE COM PLACAS DE GESSO ACARTONADO (DRYWALL), PARA USO INTERNO COM UMA FACE SIMPLES E OUTRA
FACE DUPLA E ESTRUTURA METALICA COM GUIAS DUPLAS, SEM VAOS. AF_06/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 136,5100
Propostas do Item 690
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 136,5100 Proposta adjudicada
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 121,7100 Proposta
desclassificada
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 100,0000 Proposta
desclassificada
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 135,0000 Proposta
desclassificada
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
Item 690 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²375
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 202,8500
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
58 de 12603/01/2024 11:25

## Página 59

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 126,3000 Proposta
desclassificada
Valor proposta: R$ 137,3100 Valor negociado: Não informado Quantidade ofertada: 375
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 115,3800 Proposta
desclassificada
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 142,0000  -
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 139,9700 Proposta
desclassificada
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 137,0000  -
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 146,0500  -
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 148,8800  -
Valor proposta: R$ 188,8800 Valor negociado: Não informado Quantidade ofertada: 375
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 85,5600 Proposta
desclassificada
Valor proposta: R$ 198,0000 Valor negociado: Não informado Quantidade ofertada: 375
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 146,4700  -
Valor proposta: R$ 172,1900 Valor negociado: Não informado Quantidade ofertada: 375
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 200,0000  -
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 152,1300  -
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 200,0000  -
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 115,3700 Proposta
desclassificada
59 de 12603/01/2024 11:25

## Página 60

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 115,3700 Proposta
desclassificada
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 148,2800  -
Valor proposta: R$ 148,2800 Valor negociado: Não informado Quantidade ofertada: 375
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 202,8500  -
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 202,8500  -
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 202,8500  -
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 202,8500  -
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 202,8500  -
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 152,3400  -
Valor proposta: R$ 152,3400 Valor negociado: Não informado Quantidade ofertada: 375
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 200,8200 Proposta
desclassificada
Valor proposta: R$ 200,8200 Valor negociado: Não informado Quantidade ofertada: 375
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 144,0200  -
Valor proposta: R$ 144,0200 Valor negociado: Não informado Quantidade ofertada: 375
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 202,8500  -
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 148,0700  -
Valor proposta: R$ 148,0700 Valor negociado: Não informado Quantidade ofertada: 375
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 202,8500  -
Valor proposta: R$ 202,8500 Valor negociado: Não informado Quantidade ofertada: 375
60 de 12603/01/2024 11:25

## Página 61

UASG 120645 PREGÃO 62/2023
Lances do Item  690
Data/hora Participante Lance
01/11/2023 14:05:29 33.493.603/0001-21 R$ 137,3000
01/11/2023 14:07:01 33.890.430/0001-85 R$ 135,0000
01/11/2023 14:07:06 43.050.611/0001-57 R$ 139,9700
01/11/2023 14:07:38 32.227.070/0001-73 R$ 200,0000
01/11/2023 14:07:42 08.878.462/0001-18 R$ 142,0000
01/11/2023 14:07:42 11.862.800/0001-38 R$ 152,1300
01/11/2023 14:08:24 29.652.879/0001-38 R$ 146,4700
01/11/2023 14:08:33 33.493.603/0001-21 R$ 134,9900
01/11/2023 14:08:44 26.160.104/0001-57 R$ 136,5100
01/11/2023 14:09:06 73.509.440/0001-42 R$ 137,0000
01/11/2023 14:09:11 73.315.905/0001-24 R$ 146,0500
01/11/2023 14:09:12 16.843.624/0001-00 R$ 135,0000
01/11/2023 14:10:37 04.953.896/0001-84 R$ 126,3000
01/11/2023 14:11:20 33.493.603/0001-21 R$ 126,2900
01/11/2023 14:12:03 28.244.608/0001-80 R$ 115,3800
01/11/2023 14:12:32 26.601.871/0001-54 R$ 200,0000
01/11/2023 14:14:03 10.681.640/0001-68 R$ 148,8800
01/11/2023 14:14:23 16.843.624/0001-00 R$ 116,0000
01/11/2023 14:15:09 27.595.842/0001-90 R$ 115,3700
01/11/2023 14:20:07 06.222.208/0001-31 R$ 113,7600
01/11/2023 14:20:17 06.222.208/0001-31 R$ 109,5200
01/11/2023 14:20:22 06.222.208/0001-31 R$ 109,3100
01/11/2023 14:20:28 06.222.208/0001-31 R$ 109,2900
01/11/2023 14:20:50 06.222.208/0001-31 R$ 107,8300
01/11/2023 14:20:56 06.222.208/0001-31 R$ 107,8200
01/11/2023 14:21:46 33.493.603/0001-21 R$ 121,7100
01/11/2023 14:27:44 16.843.624/0001-00 R$ 85,5600
01/11/2023 14:30:09 06.222.208/0001-31 R$ 100,0000
61 de 12603/01/2024 11:25

## Página 62

UASG 120645 PREGÃO 62/2023
PAREDE COM PLACAS DE GESSO ACARTONADO (DRYWALL), PARA USO INTERNO, COM UMA FACE SIMPLES E OUTRA
FACE DUPLA E ESTRUTURA METALICA COM GUIAS DUPLAS, COM VAOS. AF_06/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 159,1000
Propostas do Item 691
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 159,1000 Proposta adjudicada
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 162,7400 Proposta
desclassificada
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 165,1000  -
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 133,0000 Proposta
desclassificada
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 170,6400  -
Valor proposta: R$ 200,4100 Valor negociado: Não informado Quantidade ofertada: 405
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 120,0000 Proposta
desclassificada
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 134,7900 Proposta
desclassificada
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 169,8200  -
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
Item 691 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²405
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 235,8600
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
62 de 12603/01/2024 11:25

## Página 63

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 230,0000  -
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 96,1500 Proposta
desclassificada
Valor proposta: R$ 228,0000 Valor negociado: Não informado Quantidade ofertada: 405
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 200,0000  -
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 176,8900  -
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 134,7500 Proposta
desclassificada
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 161,0000  -
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 141,5200 Proposta
desclassificada
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 147,4100 Proposta
desclassificada
Valor proposta: R$ 160,1100 Valor negociado: Não informado Quantidade ofertada: 405
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 171,6000  -
Valor proposta: R$ 171,6000 Valor negociado: Não informado Quantidade ofertada: 405
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 235,8600  -
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 235,8600  -
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 235,8600  -
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 235,8600  -
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
63 de 12603/01/2024 11:25

## Página 64

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 172,7700  -
Valor proposta: R$ 172,7700 Valor negociado: Não informado Quantidade ofertada: 405
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 235,8600  -
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 172,5300  -
Valor proposta: R$ 172,5300 Valor negociado: Não informado Quantidade ofertada: 405
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 235,8600  -
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 235,8600  -
Valor proposta: R$ 235,8600 Valor negociado: Não informado Quantidade ofertada: 405
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 177,1300  -
Valor proposta: R$ 177,1300 Valor negociado: Não informado Quantidade ofertada: 405
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 233,5000 Proposta
desclassificada
Valor proposta: R$ 233,5000 Valor negociado: Não informado Quantidade ofertada: 405
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 222,8800  -
Valor proposta: R$ 222,8800 Valor negociado: Não informado Quantidade ofertada: 405
Lances do Item  691
Data/hora Participante Lance
01/11/2023 14:05:32 33.493.603/0001-21 R$ 160,1000
01/11/2023 14:06:40 43.050.611/0001-57 R$ 162,7400
01/11/2023 14:07:42 32.227.070/0001-73 R$ 230,0000
01/11/2023 14:07:50 08.878.462/0001-18 R$ 165,1000
01/11/2023 14:07:56 11.862.800/0001-38 R$ 176,8900
01/11/2023 14:08:25 29.652.879/0001-38 R$ 170,6400
01/11/2023 14:08:53 26.160.104/0001-57 R$ 159,1000
01/11/2023 14:09:06 16.843.624/0001-00 R$ 160,0000
01/11/2023 14:09:18 73.509.440/0001-42 R$ 161,0000
01/11/2023 14:09:23 73.315.905/0001-24 R$ 169,8200
64 de 12603/01/2024 11:25

## Página 65

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:10:44 04.953.896/0001-84 R$ 147,4100
01/11/2023 14:11:26 33.493.603/0001-21 R$ 147,4000
01/11/2023 14:12:05 28.244.608/0001-80 R$ 134,7500
01/11/2023 14:12:48 26.601.871/0001-54 R$ 235,0000
01/11/2023 14:14:28 16.843.624/0001-00 R$ 135,0000
01/11/2023 14:15:19 27.595.842/0001-90 R$ 134,7900
01/11/2023 14:18:33 33.890.430/0001-85 R$ 133,0000
01/11/2023 14:20:07 06.222.208/0001-31 R$ 135,5000
01/11/2023 14:20:15 06.222.208/0001-31 R$ 130,7300
01/11/2023 14:20:22 06.222.208/0001-31 R$ 130,4900
01/11/2023 14:20:28 06.222.208/0001-31 R$ 130,4700
01/11/2023 14:20:49 06.222.208/0001-31 R$ 128,8300
01/11/2023 14:20:56 06.222.208/0001-31 R$ 128,8200
01/11/2023 14:21:01 26.601.871/0001-54 R$ 200,0000
01/11/2023 14:21:59 33.493.603/0001-21 R$ 141,5200
01/11/2023 14:27:55 16.843.624/0001-00 R$ 96,1500
01/11/2023 14:30:10 06.222.208/0001-31 R$ 120,0000
PAREDE COM PLACAS DE GESSO ACARTONADO (DRYWALL), PARA USO INTERNO, COM DUAS FACES DUPLAS E
ESTRUTURA METALICA COM GUIAS SIMPLES, SEM VAOS. AF_06/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 131,1800
Propostas do Item 692
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 131,1800 Proposta adjudicada
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
Item 692 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²250
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 195,3500
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
65 de 12603/01/2024 11:25

## Página 66

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 110,6700 Proposta
desclassificada
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 195,0000  -
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 146,5100  -
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 134,7900 Proposta
desclassificada
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 140,7900  -
Valor proposta: R$ 165,7100 Valor negociado: Não informado Quantidade ofertada: 250
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 110,6800 Proposta
desclassificada
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 130,0000 Proposta
desclassificada
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 117,2100 Proposta
desclassificada
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 131,0000  -
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 98,0000 Proposta
desclassificada
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 140,6500  -
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 121,2900 Proposta
desclassificada
Valor proposta: R$ 131,9500 Valor negociado: Não informado Quantidade ofertada: 250
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 136,7500  -
66 de 12603/01/2024 11:25

## Página 67

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 136,7500  -
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 150,0000  -
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 83,0500 Proposta
desclassificada
Valor proposta: R$ 188,0000 Valor negociado: Não informado Quantidade ofertada: 250
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 149,9900  -
Valor proposta: R$ 188,8800 Valor negociado: Não informado Quantidade ofertada: 250
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 195,3500  -
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 142,5700  -
Valor proposta: R$ 142,5700 Valor negociado: Não informado Quantidade ofertada: 250
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 142,3600  -
Valor proposta: R$ 142,3600 Valor negociado: Não informado Quantidade ofertada: 250
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 193,3900 Proposta
desclassificada
Valor proposta: R$ 193,3900 Valor negociado: Não informado Quantidade ofertada: 250
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 195,3500  -
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 195,3500  -
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 195,3500  -
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 195,3500  -
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 146,7100  -
Valor proposta: R$ 146,7100 Valor negociado: Não informado Quantidade ofertada: 250
67 de 12603/01/2024 11:25

## Página 68

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 195,3500  -
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 140,6500  -
Valor proposta: R$ 140,6500 Valor negociado: Não informado Quantidade ofertada: 250
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 195,3500  -
Valor proposta: R$ 195,3500 Valor negociado: Não informado Quantidade ofertada: 250
Lances do Item  692
Data/hora Participante Lance
01/11/2023 14:05:32 33.493.603/0001-21 R$ 131,9400
01/11/2023 14:06:42 43.050.611/0001-57 R$ 134,7900
01/11/2023 14:07:04 33.890.430/0001-85 R$ 130,0000
01/11/2023 14:07:46 32.227.070/0001-73 R$ 195,0000
01/11/2023 14:07:57 08.878.462/0001-18 R$ 136,7500
01/11/2023 14:08:07 11.862.800/0001-38 R$ 146,5100
01/11/2023 14:08:35 33.493.603/0001-21 R$ 129,9900
01/11/2023 14:09:02 16.843.624/0001-00 R$ 130,0000
01/11/2023 14:09:03 26.160.104/0001-57 R$ 131,1800
01/11/2023 14:09:19 29.652.879/0001-38 R$ 140,7900
01/11/2023 14:09:27 73.509.440/0001-42 R$ 131,0000
01/11/2023 14:09:30 73.315.905/0001-24 R$ 140,6500
01/11/2023 14:10:51 04.953.896/0001-84 R$ 121,2900
01/11/2023 14:11:28 33.493.603/0001-21 R$ 121,2800
01/11/2023 14:12:07 28.244.608/0001-80 R$ 110,6700
01/11/2023 14:12:58 26.601.871/0001-54 R$ 150,0000
01/11/2023 14:14:12 10.681.640/0001-68 R$ 149,9900
01/11/2023 14:14:34 16.843.624/0001-00 R$ 111,0000
01/11/2023 14:15:32 27.595.842/0001-90 R$ 110,6800
01/11/2023 14:20:16 06.222.208/0001-31 R$ 165,4100
01/11/2023 14:20:21 06.222.208/0001-31 R$ 163,9200
01/11/2023 14:20:27 06.222.208/0001-31 R$ 163,8400
01/11/2023 14:20:30 06.222.208/0001-31 R$ 163,8300
68 de 12603/01/2024 11:25

## Página 69

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:20:33 06.222.208/0001-31 R$ 163,8200
01/11/2023 14:20:48 06.222.208/0001-31 R$ 153,5300
01/11/2023 14:20:54 06.222.208/0001-31 R$ 153,4800
01/11/2023 14:22:11 33.493.603/0001-21 R$ 117,2100
01/11/2023 14:28:12 16.843.624/0001-00 R$ 83,0500
01/11/2023 14:30:09 06.222.208/0001-31 R$ 98,0000
PAREDE COM PLACAS DE GESSO ACARTONADO (DRYWALL), PARA USO INTERNO, COM DUAS FACES DUPLAS E
ESTRUTURA METALICA COM GUIAS SIMPLES, COM VAOS. AF_06/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 143,7700
Propostas do Item 693
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 143,7700 Proposta adjudicada
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 89,9000 Proposta
desclassificada
Valor proposta: R$ 202,0000 Valor negociado: Não informado Quantidade ofertada: 2347
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 159,9900  -
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 210,0000  -
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 143,0000  -
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
Item 693 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²2347
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 213,3300
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
69 de 12603/01/2024 11:25

## Página 70

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 102,0000 Proposta
desclassificada
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 149,3300  -
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 100,0000 Proposta
desclassificada
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 154,2300  -
Valor proposta: R$ 181,2600 Valor negociado: Não informado Quantidade ofertada: 2347
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 121,6700 Proposta
desclassificada
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 121,7100 Proposta
desclassificada
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 147,2000 Proposta
desclassificada
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 149,9900  -
Valor proposta: R$ 188,8800 Valor negociado: Não informado Quantidade ofertada: 2347
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 128,0000 Proposta
desclassificada
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 153,6000  -
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 133,1700 Proposta
desclassificada
Valor proposta: R$ 144,7300 Valor negociado: Não informado Quantidade ofertada: 2347
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 200,0000  -
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 156,2200  -
70 de 12603/01/2024 11:25

## Página 71

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 156,2200  -
Valor proposta: R$ 156,2200 Valor negociado: Não informado Quantidade ofertada: 2347
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 213,3300  -
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 213,3300  -
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 213,3300  -
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 213,3300  -
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 213,3300  -
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 213,3300  -
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 151,4600  -
Valor proposta: R$ 151,4600 Valor negociado: Não informado Quantidade ofertada: 2347
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 213,3300  -
Valor proposta: R$ 213,3300 Valor negociado: Não informado Quantidade ofertada: 2347
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 160,2100  -
Valor proposta: R$ 160,2100 Valor negociado: Não informado Quantidade ofertada: 2347
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 155,9900  -
Valor proposta: R$ 155,9900 Valor negociado: Não informado Quantidade ofertada: 2347
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 211,1900 Proposta
desclassificada
Valor proposta: R$ 211,1900 Valor negociado: Não informado Quantidade ofertada: 2347
Lances do Item  693
Data/hora Participante Lance
71 de 12603/01/2024 11:25

## Página 72

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:05:33 33.493.603/0001-21 R$ 144,7200
01/11/2023 14:07:06 33.890.430/0001-85 R$ 140,0000
01/11/2023 14:07:07 43.050.611/0001-57 R$ 147,2000
01/11/2023 14:07:49 32.227.070/0001-73 R$ 210,0000
01/11/2023 14:08:04 08.878.462/0001-18 R$ 149,3300
01/11/2023 14:08:18 11.862.800/0001-38 R$ 159,9900
01/11/2023 14:08:39 33.493.603/0001-21 R$ 139,9900
01/11/2023 14:08:58 16.843.624/0001-00 R$ 140,0000
01/11/2023 14:09:12 26.160.104/0001-57 R$ 143,7700
01/11/2023 14:09:20 29.652.879/0001-38 R$ 154,2300
01/11/2023 14:09:39 73.509.440/0001-42 R$ 143,0000
01/11/2023 14:09:39 73.315.905/0001-24 R$ 153,6000
01/11/2023 14:10:57 04.953.896/0001-84 R$ 133,1700
01/11/2023 14:11:31 33.493.603/0001-21 R$ 133,1600
01/11/2023 14:12:09 28.244.608/0001-80 R$ 121,6700
01/11/2023 14:13:01 26.601.871/0001-54 R$ 200,0000
01/11/2023 14:14:18 10.681.640/0001-68 R$ 149,9900
01/11/2023 14:14:38 16.843.624/0001-00 R$ 122,0000
01/11/2023 14:15:42 27.595.842/0001-90 R$ 121,7100
01/11/2023 14:20:07 06.222.208/0001-31 R$ 116,8900
01/11/2023 14:20:15 06.222.208/0001-31 R$ 112,3100
01/11/2023 14:20:21 06.222.208/0001-31 R$ 112,0800
01/11/2023 14:20:28 06.222.208/0001-31 R$ 112,0600
01/11/2023 14:20:50 06.222.208/0001-31 R$ 110,4800
01/11/2023 14:20:56 06.222.208/0001-31 R$ 110,4700
01/11/2023 14:22:25 33.493.603/0001-21 R$ 128,0000
01/11/2023 14:24:18 33.890.430/0001-85 R$ 100,0000
01/11/2023 14:28:20 16.843.624/0001-00 R$ 89,9000
01/11/2023 14:30:09 06.222.208/0001-31 R$ 102,0000
72 de 12603/01/2024 11:25

## Página 73

UASG 120645 PREGÃO 62/2023
PAREDE COM PLACAS DE GESSO ACARTONADO (DRYWALL), PARA USO INTERNO COM DUAS FACES DUPLAS E
ESTRUTURA METALICA COM GUIAS DUPLAS, SEM VAOS. AF_06/2017
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 159,6500
Propostas do Item 694
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 159,6500 Proposta adjudicada
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 142,8000 Proposta
desclassificada
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 230,0000  -
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 168,8800  -
Valor proposta: R$ 222,8800 Valor negociado: Não informado Quantidade ofertada: 800
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 147,5500 Proposta
desclassificada
Valor proposta: R$ 160,5600 Valor negociado: Não informado Quantidade ofertada: 800
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 171,3700  -
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 164,2300 Proposta
desclassificada
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 134,6100 Proposta
desclassificada
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 200,0000  -
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
Item 694 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²800
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 238,0100
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
73 de 12603/01/2024 11:25

## Página 74

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 178,5000  -
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 164,0000  -
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 171,4200  -
Valor proposta: R$ 201,7900 Valor negociado: Não informado Quantidade ofertada: 800
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 86,5500 Proposta
desclassificada
Valor proposta: R$ 212,0000 Valor negociado: Não informado Quantidade ofertada: 800
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 160,0000 Proposta
desclassificada
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 166,6100  -
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 110,0000 Proposta
desclassificada
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 238,0100  -
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 173,2900  -
Valor proposta: R$ 173,2900 Valor negociado: Não informado Quantidade ofertada: 800
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 238,0100  -
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 176,1200  -
Valor proposta: R$ 176,1200 Valor negociado: Não informado Quantidade ofertada: 800
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 178,7500  -
Valor proposta: R$ 178,7500 Valor negociado: Não informado Quantidade ofertada: 800
74 de 12603/01/2024 11:25

## Página 75

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 238,0100  -
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 173,5400  -
Valor proposta: R$ 173,5400 Valor negociado: Não informado Quantidade ofertada: 800
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 238,0100  -
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 238,0100  -
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 238,0100  -
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 238,0100  -
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 295,0200 Proposta
desclassificada
Valor proposta: R$ 295,0200 Valor negociado: Não informado Quantidade ofertada: 800
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 238,0100 Proposta
desclassificada
Valor proposta: R$ 238,0100 Valor negociado: Não informado Quantidade ofertada: 800
Lances do Item  694
Data/hora Participante Lance
01/11/2023 14:05:35 33.493.603/0001-21 R$ 160,5500
01/11/2023 14:06:04 33.890.430/0001-85 R$ 160,0000
01/11/2023 14:07:09 43.050.611/0001-57 R$ 164,2300
01/11/2023 14:07:53 32.227.070/0001-73 R$ 230,0000
01/11/2023 14:08:10 08.878.462/0001-18 R$ 166,6100
01/11/2023 14:08:31 11.862.800/0001-38 R$ 178,5000
01/11/2023 14:08:42 33.493.603/0001-21 R$ 159,9900
01/11/2023 14:08:53 16.843.624/0001-00 R$ 160,0000
01/11/2023 14:09:22 29.652.879/0001-38 R$ 171,4200
01/11/2023 14:09:35 26.160.104/0001-57 R$ 159,6500
01/11/2023 14:09:53 73.509.440/0001-42 R$ 164,0000
75 de 12603/01/2024 11:25

## Página 76

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:09:53 73.315.905/0001-24 R$ 171,3700
01/11/2023 14:11:05 04.953.896/0001-84 R$ 147,5500
01/11/2023 14:11:33 33.493.603/0001-21 R$ 147,5400
01/11/2023 14:12:12 28.244.608/0001-80 R$ 134,6100
01/11/2023 14:13:04 26.601.871/0001-54 R$ 200,0000
01/11/2023 14:14:25 10.681.640/0001-68 R$ 168,8800
01/11/2023 14:14:43 16.843.624/0001-00 R$ 135,0000
01/11/2023 14:20:06 06.222.208/0001-31 R$ 127,1300
01/11/2023 14:20:16 06.222.208/0001-31 R$ 121,8600
01/11/2023 14:20:22 06.222.208/0001-31 R$ 121,5900
01/11/2023 14:20:27 06.222.208/0001-31 R$ 121,5700
01/11/2023 14:20:50 06.222.208/0001-31 R$ 119,7600
01/11/2023 14:20:56 06.222.208/0001-31 R$ 119,7500
01/11/2023 14:22:31 33.493.603/0001-21 R$ 142,8100
01/11/2023 14:28:48 16.843.624/0001-00 R$ 86,5500
01/11/2023 14:30:11 06.222.208/0001-31 R$ 110,0000
16/11/2023 09:36:10 33.493.603/0001-21 R$ 142,8000
PAREDE COM PLACAS DE GESSO ACARTONADO (DRYWALL), PARA USO INTERNO, COM DUAS FACES DUPLAS E
ESTRUTURA METALICA COM GUIAS DUPLAS, COM VAOS. AF_06/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 182,8400
Propostas do Item 695
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 182,8400 Proposta adjudicada
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
Item 695 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²500
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 271,6800
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
76 de 12603/01/2024 11:25

## Página 77

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 270,0000  -
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 169,2400 Proposta
desclassificada
Valor proposta: R$ 183,9600 Valor negociado: Não informado Quantidade ofertada: 500
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 107,8400 Proposta
desclassificada
Valor proposta: R$ 262,0000 Valor negociado: Não informado Quantidade ofertada: 500
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 163,0000 Proposta
desclassificada
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 196,2000  -
Valor proposta: R$ 230,6400 Valor negociado: Não informado Quantidade ofertada: 500
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 154,5800 Proposta
desclassificada
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 195,6100  -
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 190,1800  -
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 203,7600  -
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 200,0000  -
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 187,4600 Proposta
desclassificada
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 135,0000 Proposta
desclassificada
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 183,8000 Proposta
desclassificada
77 de 12603/01/2024 11:25

## Página 78

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 183,8000 Proposta
desclassificada
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 154,5900 Proposta
desclassificada
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 199,9900  -
Valor proposta: R$ 248,8800 Valor negociado: Não informado Quantidade ofertada: 500
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 271,6800  -
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 271,6800  -
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 271,6800  -
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 271,6800  -
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 198,6500  -
Valor proposta: R$ 198,6500 Valor negociado: Não informado Quantidade ofertada: 500
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 271,6800  -
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 268,9600 Proposta
desclassificada
Valor proposta: R$ 268,9600 Valor negociado: Não informado Quantidade ofertada: 500
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 214,7600  -
Valor proposta: R$ 214,7600 Valor negociado: Não informado Quantidade ofertada: 500
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 271,6800  -
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 204,0300  -
Valor proposta: R$ 204,0300 Valor negociado: Não informado Quantidade ofertada: 500
78 de 12603/01/2024 11:25

## Página 79

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 271,6800  -
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 198,3600  -
Valor proposta: R$ 198,3600 Valor negociado: Não informado Quantidade ofertada: 500
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 271,6800  -
Valor proposta: R$ 271,6800 Valor negociado: Não informado Quantidade ofertada: 500
Lances do Item  695
Data/hora Participante Lance
01/11/2023 14:05:36 33.493.603/0001-21 R$ 183,9500
01/11/2023 14:06:09 33.890.430/0001-85 R$ 183,8000
01/11/2023 14:07:11 43.050.611/0001-57 R$ 187,4600
01/11/2023 14:07:55 32.227.070/0001-73 R$ 270,0000
01/11/2023 14:08:18 08.878.462/0001-18 R$ 190,1800
01/11/2023 14:08:42 11.862.800/0001-38 R$ 203,7600
01/11/2023 14:08:45 33.493.603/0001-21 R$ 183,7900
01/11/2023 14:08:49 16.843.624/0001-00 R$ 184,0000
01/11/2023 14:09:23 29.652.879/0001-38 R$ 196,2000
01/11/2023 14:09:53 26.160.104/0001-57 R$ 183,7800
01/11/2023 14:10:02 73.315.905/0001-24 R$ 195,6100
01/11/2023 14:11:12 04.953.896/0001-84 R$ 169,2400
01/11/2023 14:11:36 33.493.603/0001-21 R$ 169,2300
01/11/2023 14:12:14 28.244.608/0001-80 R$ 154,5800
01/11/2023 14:12:48 26.160.104/0001-57 R$ 182,8400
01/11/2023 14:13:07 26.601.871/0001-54 R$ 200,0000
01/11/2023 14:14:31 10.681.640/0001-68 R$ 199,9900
01/11/2023 14:14:49 16.843.624/0001-00 R$ 155,0000
01/11/2023 14:16:21 27.595.842/0001-90 R$ 154,5900
01/11/2023 14:20:07 06.222.208/0001-31 R$ 153,2900
01/11/2023 14:20:23 06.222.208/0001-31 R$ 152,8800
01/11/2023 14:20:28 06.222.208/0001-31 R$ 152,8500
01/11/2023 14:20:33 06.222.208/0001-31 R$ 152,8400
79 de 12603/01/2024 11:25

## Página 80

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:20:51 06.222.208/0001-31 R$ 150,0500
01/11/2023 14:20:55 06.222.208/0001-31 R$ 150,0300
01/11/2023 14:22:38 33.493.603/0001-21 R$ 163,0000
01/11/2023 14:29:05 16.843.624/0001-00 R$ 107,8400
01/11/2023 14:30:11 06.222.208/0001-31 R$ 135,0000
PAREDE COM PLACAS DE GESSO ACARTONADO (DRYWALL), PARA USO INTERNO, COM UMA FACE SIMPLES E
ESTRUTURA METALICA COM GUIAS SIMPLES, SEM VAOS. AF_06/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 57,5200
Propostas do Item 696
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 57,5200 Proposta adjudicada
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 50,9000 Proposta
desclassificada
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 48,9600 Proposta
desclassificada
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 48,9000 Proposta
desclassificada
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 27,7300 Proposta
desclassificada
Valor proposta: R$ 78,0000 Valor negociado: Não informado Quantidade ofertada: 900
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 61,0900  -
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
Item 696 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²900
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 84,8500
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
80 de 12603/01/2024 11:25

## Página 81

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 84,0000  -
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 40,0000 Proposta
desclassificada
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 80,0000  -
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 61,6000  -
Valor proposta: R$ 72,2400 Valor negociado: Não informado Quantidade ofertada: 900
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 58,5500 Proposta
desclassificada
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 63,6300  -
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 53,4000 Proposta
desclassificada
Valor proposta: R$ 57,9200 Valor negociado: Não informado Quantidade ofertada: 900
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 59,4000  -
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 84,8500  -
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 84,8500  -
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 63,7200  -
Valor proposta: R$ 63,7200 Valor negociado: Não informado Quantidade ofertada: 900
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 84,8500  -
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 84,8500  -
81 de 12603/01/2024 11:25

## Página 82

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 84,8500  -
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 82,8800  -
Valor proposta: R$ 82,8800 Valor negociado: Não informado Quantidade ofertada: 900
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 60,2400  -
Valor proposta: R$ 60,2400 Valor negociado: Não informado Quantidade ofertada: 900
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 84,8500  -
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 84,0000 Proposta
desclassificada
Valor proposta: R$ 84,0000 Valor negociado: Não informado Quantidade ofertada: 900
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 84,8500  -
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 84,8500 Proposta
desclassificada
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 84,8500  -
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 62,3300  -
Valor proposta: R$ 62,3300 Valor negociado: Não informado Quantidade ofertada: 900
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 62,4100  -
Valor proposta: R$ 62,4100 Valor negociado: Não informado Quantidade ofertada: 900
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 84,8500  -
Valor proposta: R$ 84,8500 Valor negociado: Não informado Quantidade ofertada: 900
Lances do Item  696
Data/hora Participante Lance
01/11/2023 14:05:37 33.493.603/0001-21 R$ 57,9100
82 de 12603/01/2024 11:25

## Página 83

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:07:13 43.050.611/0001-57 R$ 84,6600
01/11/2023 14:07:16 43.050.611/0001-57 R$ 58,5500
01/11/2023 14:07:59 32.227.070/0001-73 R$ 84,0000
01/11/2023 14:08:24 08.878.462/0001-18 R$ 59,4000
01/11/2023 14:08:44 16.843.624/0001-00 R$ 58,0000
01/11/2023 14:08:52 11.862.800/0001-38 R$ 63,6300
01/11/2023 14:09:24 29.652.879/0001-38 R$ 61,6000
01/11/2023 14:10:21 73.315.905/0001-24 R$ 61,0900
01/11/2023 14:10:22 26.160.104/0001-57 R$ 57,5200
01/11/2023 14:11:19 04.953.896/0001-84 R$ 53,4000
01/11/2023 14:11:39 33.493.603/0001-21 R$ 53,3900
01/11/2023 14:12:19 28.244.608/0001-80 R$ 48,9000
01/11/2023 14:13:17 26.601.871/0001-54 R$ 80,0000
01/11/2023 14:14:54 16.843.624/0001-00 R$ 49,0000
01/11/2023 14:16:33 27.595.842/0001-90 R$ 48,9600
01/11/2023 14:20:08 06.222.208/0001-31 R$ 46,0000
01/11/2023 14:20:17 06.222.208/0001-31 R$ 44,1500
01/11/2023 14:20:23 06.222.208/0001-31 R$ 44,0500
01/11/2023 14:20:49 06.222.208/0001-31 R$ 43,4100
01/11/2023 14:22:45 33.493.603/0001-21 R$ 50,9100
01/11/2023 14:29:07 16.843.624/0001-00 R$ 27,7300
01/11/2023 14:30:10 06.222.208/0001-31 R$ 40,0000
16/11/2023 09:36:15 33.493.603/0001-21 R$ 50,9000
83 de 12603/01/2024 11:25

## Página 84

UASG 120645 PREGÃO 62/2023
PAREDE COM PLACAS DE GESSO ACARTONADO (DRYWALL), PARA USO INTERNO, COM UMA FACE SIMPLES E
ESTRUTURA METALICA COM GUIAS SIMPLES, COM VAOS. AF_06/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 68,6600
Propostas do Item 697
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 68,6600 Proposta adjudicada
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 58,4200 Proposta
desclassificada
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 70,8100  -
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 58,4800 Proposta
desclassificada
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 100,0000  -
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 68,0000 Proposta
desclassificada
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 50,0000 Proposta
desclassificada
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 72,8300  -
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 100,0000  -
Item 697 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²900
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 101,1500
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
84 de 12603/01/2024 11:25

## Página 85

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 100,0000  -
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 60,6900 Proposta
desclassificada
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 69,7900 Proposta
desclassificada
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 73,5200  -
Valor proposta: R$ 86,1500 Valor negociado: Não informado Quantidade ofertada: 900
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 75,8600  -
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 33,1300 Proposta
desclassificada
Valor proposta: R$ 96,0000 Valor negociado: Não informado Quantidade ofertada: 900
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 63,7900 Proposta
desclassificada
Valor proposta: R$ 69,1500 Valor negociado: Não informado Quantidade ofertada: 900
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 101,1500  -
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 75,9600  -
Valor proposta: R$ 75,9600 Valor negociado: Não informado Quantidade ofertada: 900
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 101,1500  -
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 73,8300  -
Valor proposta: R$ 73,8300 Valor negociado: Não informado Quantidade ofertada: 900
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 74,4000  -
Valor proposta: R$ 74,4000 Valor negociado: Não informado Quantidade ofertada: 900
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 101,1500  -
85 de 12603/01/2024 11:25

## Página 86

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 101,1500  -
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 101,1500  -
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 101,1500  -
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 101,1500  -
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 101,1500  -
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 74,4900  -
Valor proposta: R$ 74,4900 Valor negociado: Não informado Quantidade ofertada: 900
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 88,8800  -
Valor proposta: R$ 88,8800 Valor negociado: Não informado Quantidade ofertada: 900
21.380.998/0001-77 - LHAP CLIMATIZACAO E ELETRICA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 100,1300 Proposta
desclassificada
Valor proposta: R$ 100,1300 Valor negociado: Não informado Quantidade ofertada: 900
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 101,1500  -
Valor proposta: R$ 101,1500 Valor negociado: Não informado Quantidade ofertada: 900
Lances do Item  697
Data/hora Participante Lance
01/11/2023 14:05:38 33.493.603/0001-21 R$ 69,1400
01/11/2023 14:06:43 43.050.611/0001-57 R$ 69,7900
01/11/2023 14:07:15 33.890.430/0001-85 R$ 68,0000
01/11/2023 14:08:02 32.227.070/0001-73 R$ 100,0000
01/11/2023 14:08:29 08.878.462/0001-18 R$ 70,8100
01/11/2023 14:08:40 16.843.624/0001-00 R$ 69,0000
01/11/2023 14:08:49 33.493.603/0001-21 R$ 67,9900
86 de 12603/01/2024 11:25

## Página 87

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:09:05 11.862.800/0001-38 R$ 75,8600
01/11/2023 14:09:25 29.652.879/0001-38 R$ 73,5200
01/11/2023 14:10:30 73.315.905/0001-24 R$ 72,8300
01/11/2023 14:10:38 26.160.104/0001-57 R$ 68,6600
01/11/2023 14:11:25 04.953.896/0001-84 R$ 63,7900
01/11/2023 14:11:43 33.493.603/0001-21 R$ 63,7800
01/11/2023 14:12:22 28.244.608/0001-80 R$ 58,4200
01/11/2023 14:13:20 26.601.871/0001-54 R$ 100,0000
01/11/2023 14:14:58 16.843.624/0001-00 R$ 59,0000
01/11/2023 14:16:42 27.595.842/0001-90 R$ 58,4800
01/11/2023 14:20:09 06.222.208/0001-31 R$ 56,8400
01/11/2023 14:20:18 06.222.208/0001-31 R$ 54,7300
01/11/2023 14:20:23 06.222.208/0001-31 R$ 54,6200
01/11/2023 14:22:53 33.493.603/0001-21 R$ 60,6900
01/11/2023 14:29:11 16.843.624/0001-00 R$ 33,1300
01/11/2023 14:30:09 06.222.208/0001-31 R$ 50,0000
FORRO EM PLACAS DE GESSO, PARA AMBIENTES COMERCIAIS. AF_05/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 42,3700
Propostas do Item 698
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 42,3700 Proposta adjudicada
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
Item 698 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²1600
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 53,7000
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
87 de 12603/01/2024 11:25

## Página 88

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 41,2200 Proposta
desclassificada
Valor proposta: R$ 42,9900 Valor negociado: Não informado Quantidade ofertada: 1600
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 37,5900  -
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 32,0000 Proposta
desclassificada
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 37,0500 Proposta
desclassificada
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 39,4500 Proposta
desclassificada
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 40,2700  -
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 43,6200  -
Valor proposta: R$ 48,7400 Valor negociado: Não informado Quantidade ofertada: 1600
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 38,6600  -
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 39,5100 Proposta
desclassificada
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 25,0000 Proposta
desclassificada
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 22,2500 Proposta
desclassificada
Valor proposta: R$ 51,0000 Valor negociado: Não informado Quantidade ofertada: 1600
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 32,2200 Proposta
desclassificada
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 53,0000  -
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
88 de 12603/01/2024 11:25

## Página 89

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 50,0000  -
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 53,7000  -
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 48,8800  -
Valor proposta: R$ 48,8800 Valor negociado: Não informado Quantidade ofertada: 1600
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 53,7000  -
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 38,1200  -
Valor proposta: R$ 38,1200 Valor negociado: Não informado Quantidade ofertada: 1600
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 53,7000  -
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 53,7000  -
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 53,7000  -
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 53,7000  -
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 44,7800  -
Valor proposta: R$ 44,7800 Valor negociado: Não informado Quantidade ofertada: 1600
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 40,3300  -
Valor proposta: R$ 40,3300 Valor negociado: Não informado Quantidade ofertada: 1600
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 53,7000  -
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 53,7000  -
89 de 12603/01/2024 11:25

## Página 90

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 53,7000  -
Valor proposta: R$ 53,7000 Valor negociado: Não informado Quantidade ofertada: 1600
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 44,7600  -
Valor proposta: R$ 44,7600 Valor negociado: Não informado Quantidade ofertada: 1600
Lances do Item  698
Data/hora Participante Lance
01/11/2023 14:05:41 33.493.603/0001-21 R$ 38,1100
01/11/2023 14:06:45 43.050.611/0001-57 R$ 37,0500
01/11/2023 14:08:06 32.227.070/0001-73 R$ 53,0000
01/11/2023 14:08:36 16.843.624/0001-00 R$ 38,0000
01/11/2023 14:08:38 08.878.462/0001-18 R$ 37,5900
01/11/2023 14:08:54 33.493.603/0001-21 R$ 37,0400
01/11/2023 14:09:15 11.862.800/0001-38 R$ 40,2700
01/11/2023 14:09:36 29.652.879/0001-38 R$ 43,6200
01/11/2023 14:10:36 73.315.905/0001-24 R$ 38,6600
01/11/2023 14:10:46 26.160.104/0001-57 R$ 42,3700
01/11/2023 14:11:41 04.953.896/0001-84 R$ 41,2200
01/11/2023 14:12:27 28.244.608/0001-80 R$ 39,4500
01/11/2023 14:13:22 26.601.871/0001-54 R$ 50,0000
01/11/2023 14:16:51 27.595.842/0001-90 R$ 39,5100
01/11/2023 14:18:41 33.890.430/0001-85 R$ 32,0000
01/11/2023 14:20:10 06.222.208/0001-31 R$ 28,8400
01/11/2023 14:20:19 06.222.208/0001-31 R$ 27,6500
01/11/2023 14:20:52 06.222.208/0001-31 R$ 27,2300
01/11/2023 14:23:03 33.493.603/0001-21 R$ 32,2200
01/11/2023 14:29:20 16.843.624/0001-00 R$ 22,2500
01/11/2023 14:30:12 06.222.208/0001-31 R$ 25,0000
90 de 12603/01/2024 11:25

## Página 91

UASG 120645 PREGÃO 62/2023
ACABAMENTOS PARA FORRO (MOLDURA DE GESSO). AF_05/2017
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 3,2000
Propostas do Item 699
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 3,2000 Proposta adjudicada
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 2,9900  -
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 2,9100  -
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 2,4900 Proposta
desclassificada
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 3,3000  -
Valor proposta: R$ 3,7300 Valor negociado: Não informado Quantidade ofertada: 2500
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 3,1100  -
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 4,0000  -
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 3,1000 Proposta
desclassificada
Valor proposta: R$ 3,2300 Valor negociado: Não informado Quantidade ofertada: 2500
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 2,9800 Proposta
desclassificada
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
Item 699 do Grupo G13 - SERVIÇO ENGENHARIA
Critério de julgamento:
Situação:
M2500
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 4,1500
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
91 de 12603/01/2024 11:25

## Página 92

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 4,0000  -
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 2,1000 Proposta
desclassificada
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 2,8600 Proposta
desclassificada
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 1,6100 Proposta
desclassificada
Valor proposta: R$ 4,1000 Valor negociado: Não informado Quantidade ofertada: 2500
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 2,9600 Proposta
desclassificada
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 4,1500  -
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 3,4000  -
Valor proposta: R$ 3,4000 Valor negociado: Não informado Quantidade ofertada: 2500
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 4,1500  -
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 4,1500 Proposta
desclassificada
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 2,9800  -
Valor proposta: R$ 2,9800 Valor negociado: Não informado Quantidade ofertada: 2500
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 4,1500  -
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 4,1500  -
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 4,1500  -
92 de 12603/01/2024 11:25

## Página 93

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 4,1500  -
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 4,1500  -
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 3,8800  -
Valor proposta: R$ 3,8800 Valor negociado: Não informado Quantidade ofertada: 2500
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 4,1500  -
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 3,1200  -
Valor proposta: R$ 3,1200 Valor negociado: Não informado Quantidade ofertada: 2500
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 3,4000  -
Valor proposta: R$ 3,4000 Valor negociado: Não informado Quantidade ofertada: 2500
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 4,1500  -
Valor proposta: R$ 4,1500 Valor negociado: Não informado Quantidade ofertada: 2500
Lances do Item  699
Data/hora Participante Lance
01/11/2023 14:05:42 33.493.603/0001-21 R$ 2,9700
01/11/2023 14:06:27 43.050.611/0001-57 R$ 2,8600
01/11/2023 14:08:09 32.227.070/0001-73 R$ 4,0000
01/11/2023 14:08:32 16.843.624/0001-00 R$ 3,0000
01/11/2023 14:08:44 08.878.462/0001-18 R$ 2,9100
01/11/2023 14:08:57 33.493.603/0001-21 R$ 2,8500
01/11/2023 14:09:31 11.862.800/0001-38 R$ 3,1100
01/11/2023 14:09:44 29.652.879/0001-38 R$ 3,3000
01/11/2023 14:10:47 73.315.905/0001-24 R$ 2,9900
01/11/2023 14:10:54 26.160.104/0001-57 R$ 3,2000
01/11/2023 14:11:49 04.953.896/0001-84 R$ 3,1000
01/11/2023 14:12:29 28.244.608/0001-80 R$ 2,9600
01/11/2023 14:13:25 26.601.871/0001-54 R$ 4,0000
93 de 12603/01/2024 11:25

## Página 94

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:17:02 27.595.842/0001-90 R$ 2,9800
01/11/2023 14:20:11 06.222.208/0001-31 R$ 2,3700
01/11/2023 14:23:17 33.493.603/0001-21 R$ 2,4900
01/11/2023 14:29:23 16.843.624/0001-00 R$ 1,6100
01/11/2023 14:30:12 06.222.208/0001-31 R$ 2,1000
ACABAMENTOS PARA FORRO (SANCA DE GESSO MONTADA NA OBRA). AF_05/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 64,0200
Propostas do Item 700
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 64,0200 Proposta adjudicada
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 46,9000 Proposta
desclassificada
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 53,9500 Proposta
desclassificada
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 50,0000  -
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 56,3000  -
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 35,0000 Proposta
desclassificada
Item 700 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²946
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 78,1900
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
94 de 12603/01/2024 11:25

## Página 95

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 35,0000 Proposta
desclassificada
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 58,5000 Proposta
desclassificada
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 54,7300  -
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 60,6500 Proposta
desclassificada
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 78,0000  -
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 58,6400  -
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 62,8100 Proposta
desclassificada
Valor proposta: R$ 64,9800 Valor negociado: Não informado Quantidade ofertada: 946
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 65,2200  -
Valor proposta: R$ 72,1200 Valor negociado: Não informado Quantidade ofertada: 946
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 33,7200 Proposta
desclassificada
Valor proposta: R$ 78,0000 Valor negociado: Não informado Quantidade ofertada: 946
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 60,6100 Proposta
desclassificada
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 78,1900  -
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 78,1900  -
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 78,1900  -
95 de 12603/01/2024 11:25

## Página 96

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 78,1900  -
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 78,1900  -
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 78,1900  -
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 78,1900  -
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 58,7200  -
Valor proposta: R$ 58,7200 Valor negociado: Não informado Quantidade ofertada: 946
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 67,2000  -
Valor proposta: R$ 67,2000 Valor negociado: Não informado Quantidade ofertada: 946
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 67,1600  -
Valor proposta: R$ 67,1600 Valor negociado: Não informado Quantidade ofertada: 946
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 78,1900  -
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 58,6400  -
Valor proposta: R$ 58,6400 Valor negociado: Não informado Quantidade ofertada: 946
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 68,8800  -
Valor proposta: R$ 68,8800 Valor negociado: Não informado Quantidade ofertada: 946
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 78,1900  -
Valor proposta: R$ 78,1900 Valor negociado: Não informado Quantidade ofertada: 946
Lances do Item  700
Data/hora Participante Lance
01/11/2023 14:05:44 33.493.603/0001-21 R$ 58,6300
01/11/2023 14:06:23 33.890.430/0001-85 R$ 58,5000
96 de 12603/01/2024 11:25

## Página 97

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:06:47 43.050.611/0001-57 R$ 53,9500
01/11/2023 14:08:14 32.227.070/0001-73 R$ 78,0000
01/11/2023 14:08:27 16.843.624/0001-00 R$ 54,0000
01/11/2023 14:08:51 08.878.462/0001-18 R$ 54,7300
01/11/2023 14:09:04 33.493.603/0001-21 R$ 53,9400
01/11/2023 14:09:44 11.862.800/0001-38 R$ 58,6400
01/11/2023 14:10:52 29.652.879/0001-38 R$ 65,2200
01/11/2023 14:10:56 73.315.905/0001-24 R$ 56,3000
01/11/2023 14:11:02 26.160.104/0001-57 R$ 64,0200
01/11/2023 14:11:56 04.953.896/0001-84 R$ 62,8100
01/11/2023 14:12:31 28.244.608/0001-80 R$ 60,6100
01/11/2023 14:13:30 26.601.871/0001-54 R$ 50,0000
01/11/2023 14:13:35 33.493.603/0001-21 R$ 49,9900
01/11/2023 14:15:10 16.843.624/0001-00 R$ 50,0000
01/11/2023 14:17:09 27.595.842/0001-90 R$ 60,6500
01/11/2023 14:20:09 06.222.208/0001-31 R$ 40,7800
01/11/2023 14:20:18 06.222.208/0001-31 R$ 39,0000
01/11/2023 14:20:25 06.222.208/0001-31 R$ 38,9100
01/11/2023 14:20:51 06.222.208/0001-31 R$ 38,2900
01/11/2023 14:23:25 33.493.603/0001-21 R$ 46,9100
01/11/2023 14:29:26 16.843.624/0001-00 R$ 33,7200
01/11/2023 14:30:12 06.222.208/0001-31 R$ 35,0000
16/11/2023 09:36:22 33.493.603/0001-21 R$ 46,9000
97 de 12603/01/2024 11:25

## Página 98

UASG 120645 PREGÃO 62/2023
REMOCAO DE FORRO DE GESSO, DE FORMA MANUAL, SEM REAPROVEITAMENTO. AF_12/2017
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 6,3500
Propostas do Item 701
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 6,3500 Proposta adjudicada
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 3,5100 Proposta
desclassificada
Valor proposta: R$ 7,1500 Valor negociado: Não informado Quantidade ofertada: 4768
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 6,2900 Proposta
desclassificada
Valor proposta: R$ 6,4200 Valor negociado: Não informado Quantidade ofertada: 4768
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 5,4000  -
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 3,5000 Proposta
desclassificada
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 5,0400  -
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 6,1700 Proposta
desclassificada
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 4,9700 Proposta
desclassificada
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 7,0000  -
Item 701 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²4768
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 7,2000
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
98 de 12603/01/2024 11:25

## Página 99

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 7,0000  -
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 7,0000  -
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 5,1800  -
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 6,3200  -
Valor proposta: R$ 6,8500 Valor negociado: Não informado Quantidade ofertada: 4768
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 4,3200 Proposta
desclassificada
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 6,1700 Proposta
desclassificada
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 6,5600  -
Valor proposta: R$ 6,5600 Valor negociado: Não informado Quantidade ofertada: 4768
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 7,2000  -
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 7,2000  -
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 7,2000  -
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 7,2000  -
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 7,2000  -
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 6,8800  -
Valor proposta: R$ 6,8800 Valor negociado: Não informado Quantidade ofertada: 4768
99 de 12603/01/2024 11:25

## Página 100

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 7,2000  -
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 7,2000  -
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 7,2000  -
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 5,1800  -
Valor proposta: R$ 5,1800 Valor negociado: Não informado Quantidade ofertada: 4768
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 7,2000 Proposta
desclassificada
Valor proposta: R$ 7,2000 Valor negociado: Não informado Quantidade ofertada: 4768
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 5,4100  -
Valor proposta: R$ 5,4100 Valor negociado: Não informado Quantidade ofertada: 4768
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 6,5600  -
Valor proposta: R$ 6,5600 Valor negociado: Não informado Quantidade ofertada: 4768
Lances do Item  701
Data/hora Participante Lance
01/11/2023 14:05:46 33.493.603/0001-21 R$ 5,1700
01/11/2023 14:07:27 43.050.611/0001-57 R$ 4,9700
01/11/2023 14:08:19 32.227.070/0001-73 R$ 7,0000
01/11/2023 14:08:21 16.843.624/0001-00 R$ 5,0000
01/11/2023 14:08:56 08.878.462/0001-18 R$ 5,0400
01/11/2023 14:09:09 33.493.603/0001-21 R$ 4,9600
01/11/2023 14:09:55 11.862.800/0001-38 R$ 5,4000
01/11/2023 14:10:53 29.652.879/0001-38 R$ 6,3200
01/11/2023 14:11:03 73.315.905/0001-24 R$ 5,1800
01/11/2023 14:11:06 26.160.104/0001-57 R$ 6,3500
01/11/2023 14:12:02 04.953.896/0001-84 R$ 6,2900
01/11/2023 14:12:34 28.244.608/0001-80 R$ 6,1700
01/11/2023 14:17:19 27.595.842/0001-90 R$ 6,1700
100 de 12603/01/2024 11:25

## Página 101

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:19:41 26.601.871/0001-54 R$ 7,0000
01/11/2023 14:20:11 06.222.208/0001-31 R$ 3,9900
01/11/2023 14:20:20 06.222.208/0001-31 R$ 3,8300
01/11/2023 14:20:53 06.222.208/0001-31 R$ 3,7700
01/11/2023 14:23:34 33.493.603/0001-21 R$ 4,3200
01/11/2023 14:29:30 16.843.624/0001-00 R$ 3,5100
01/11/2023 14:30:12 06.222.208/0001-31 R$ 3,5000
ACABAMENTOS PARA FORRO (MOLDURA EM DRYWALL, COM LARGURA DE 15 CM). AF_05/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 33,4300
Propostas do Item 702
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 33,4300 Proposta adjudicada
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 40,0000  -
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 34,0400  -
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 28,3700 Proposta
desclassificada
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 35,4600  -
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
Item 702 do Grupo G13 - SERVIÇO ENGENHARIA
Critério de julgamento:
Situação:
M2350
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 47,2800
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
101 de 12603/01/2024 11:25

## Página 102

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 35,4600  -
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 33,1000  -
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 32,6200 Proposta
desclassificada
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 35,4600  -
Valor proposta: R$ 40,9700 Valor negociado: Não informado Quantidade ofertada: 2350
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 29,3700 Proposta
desclassificada
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 15,9500 Proposta
desclassificada
Valor proposta: R$ 45,0000 Valor negociado: Não informado Quantidade ofertada: 2350
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 20,0000 Proposta
desclassificada
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 31,5500 Proposta
desclassificada
Valor proposta: R$ 33,8000 Valor negociado: Não informado Quantidade ofertada: 2350
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 29,2600 Proposta
desclassificada
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 47,0000  -
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 47,2800  -
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 47,2800  -
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 35,9900  -
Valor proposta: R$ 35,9900 Valor negociado: Não informado Quantidade ofertada: 2350
102 de 12603/01/2024 11:25

## Página 103

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 47,2800  -
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 36,0400  -
Valor proposta: R$ 36,0400 Valor negociado: Não informado Quantidade ofertada: 2350
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 34,0400  -
Valor proposta: R$ 34,0400 Valor negociado: Não informado Quantidade ofertada: 2350
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 47,2800 Proposta
desclassificada
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 47,2800  -
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 47,2800  -
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 47,2800  -
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 47,2800  -
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 44,8800  -
Valor proposta: R$ 44,8800 Valor negociado: Não informado Quantidade ofertada: 2350
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 47,2800  -
Valor proposta: R$ 47,2800 Valor negociado: Não informado Quantidade ofertada: 2350
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 35,5100  -
Valor proposta: R$ 35,5100 Valor negociado: Não informado Quantidade ofertada: 2350
Lances do Item  702
Data/hora Participante Lance
01/11/2023 14:05:48 33.493.603/0001-21 R$ 33,7900
01/11/2023 14:06:48 43.050.611/0001-57 R$ 32,6200
103 de 12603/01/2024 11:25

## Página 104

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:08:17 16.843.624/0001-00 R$ 33,0000
01/11/2023 14:08:23 32.227.070/0001-73 R$ 47,0000
01/11/2023 14:09:02 08.878.462/0001-18 R$ 33,1000
01/11/2023 14:09:12 33.493.603/0001-21 R$ 32,6100
01/11/2023 14:10:06 11.862.800/0001-38 R$ 35,4600
01/11/2023 14:10:54 29.652.879/0001-38 R$ 35,4600
01/11/2023 14:11:11 73.315.905/0001-24 R$ 34,0400
01/11/2023 14:11:15 26.160.104/0001-57 R$ 33,4300
01/11/2023 14:12:09 04.953.896/0001-84 R$ 31,5500
01/11/2023 14:12:14 33.493.603/0001-21 R$ 31,5400
01/11/2023 14:12:39 28.244.608/0001-80 R$ 29,2600
01/11/2023 14:12:53 33.493.603/0001-21 R$ 29,2500
01/11/2023 14:15:17 16.843.624/0001-00 R$ 28,0000
01/11/2023 14:17:31 27.595.842/0001-90 R$ 29,3700
01/11/2023 14:19:45 26.601.871/0001-54 R$ 40,0000
01/11/2023 14:20:10 06.222.208/0001-31 R$ 23,6500
01/11/2023 14:20:19 06.222.208/0001-31 R$ 22,5200
01/11/2023 14:20:52 06.222.208/0001-31 R$ 22,1200
01/11/2023 14:23:43 33.493.603/0001-21 R$ 28,3700
01/11/2023 14:29:40 16.843.624/0001-00 R$ 15,9500
01/11/2023 14:30:13 06.222.208/0001-31 R$ 20,0000
104 de 12603/01/2024 11:25

## Página 105

UASG 120645 PREGÃO 62/2023
ACABAMENTOS PARA FORRO (RODA-FORRO EM PERFIL METALICO E PLASTICO). AF_05/2017
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 12,7800
Propostas do Item 703
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 12,7800 Proposta adjudicada
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 10,7800 Proposta
desclassificada
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 10,0000 Proposta
desclassificada
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 12,5800  -
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 11,3100 Proposta
desclassificada
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 12,9400  -
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 13,4700  -
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 12,4000 Proposta
desclassificada
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 10,0000  -
Item 703 do Grupo G13 - SERVIÇO ENGENHARIA
Critério de julgamento:
Situação:
M3545
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 17,9700
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
105 de 12603/01/2024 11:25

## Página 106

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 10,0000  -
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 6,0500 Proposta
desclassificada
Valor proposta: R$ 17,5000 Valor negociado: Não informado Quantidade ofertada: 3545
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 13,5500  -
Valor proposta: R$ 15,6200 Valor negociado: Não informado Quantidade ofertada: 3545
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 6,0000 Proposta
desclassificada
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 12,0900 Proposta
desclassificada
Valor proposta: R$ 12,9500 Valor negociado: Não informado Quantidade ofertada: 3545
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 17,9000  -
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 11,2700 Proposta
desclassificada
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 13,2900  -
Valor proposta: R$ 13,2900 Valor negociado: Não informado Quantidade ofertada: 3545
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 17,9700  -
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 17,9700  -
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 17,9700  -
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 13,7900  -
Valor proposta: R$ 13,7900 Valor negociado: Não informado Quantidade ofertada: 3545
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 17,9700  -
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
106 de 12603/01/2024 11:25

## Página 107

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 16,8800  -
Valor proposta: R$ 16,8800 Valor negociado: Não informado Quantidade ofertada: 3545
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 17,9700  -
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 13,7600  -
Valor proposta: R$ 13,7600 Valor negociado: Não informado Quantidade ofertada: 3545
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 17,9700  -
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 17,9700  -
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 13,5000  -
Valor proposta: R$ 13,5000 Valor negociado: Não informado Quantidade ofertada: 3545
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 17,9700  -
Valor proposta: R$ 17,9700 Valor negociado: Não informado Quantidade ofertada: 3545
Lances do Item  703
Data/hora Participante Lance
01/11/2023 14:05:50 33.493.603/0001-21 R$ 12,9400
01/11/2023 14:07:19 43.050.611/0001-57 R$ 12,4000
01/11/2023 14:08:13 16.843.624/0001-00 R$ 13,0000
01/11/2023 14:08:30 32.227.070/0001-73 R$ 17,9000
01/11/2023 14:09:09 08.878.462/0001-18 R$ 12,5800
01/11/2023 14:09:15 33.493.603/0001-21 R$ 12,3900
01/11/2023 14:10:15 11.862.800/0001-38 R$ 13,4700
01/11/2023 14:10:35 33.890.430/0001-85 R$ 6,0000
01/11/2023 14:10:55 29.652.879/0001-38 R$ 13,5500
01/11/2023 14:11:19 73.315.905/0001-24 R$ 12,9400
01/11/2023 14:11:23 26.160.104/0001-57 R$ 12,7800
01/11/2023 14:12:17 04.953.896/0001-84 R$ 12,0900
107 de 12603/01/2024 11:25

## Página 108

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:12:48 28.244.608/0001-80 R$ 11,2700
01/11/2023 14:15:27 16.843.624/0001-00 R$ 6,0500
01/11/2023 14:18:00 27.595.842/0001-90 R$ 11,3100
01/11/2023 14:19:51 26.601.871/0001-54 R$ 10,0000
01/11/2023 14:20:11 06.222.208/0001-31 R$ 11,0600
01/11/2023 14:20:20 06.222.208/0001-31 R$ 10,7300
01/11/2023 14:20:53 06.222.208/0001-31 R$ 10,6100
01/11/2023 14:23:51 33.493.603/0001-21 R$ 10,7800
01/11/2023 14:30:13 06.222.208/0001-31 R$ 10,0000
FORRO EM REGUAS DE PVC, LISO, PARA AMBIENTES RESIDENCIAIS, INCLUSIVE ESTRUTURA DE FIXACAO. AF_05/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 69,8300
Propostas do Item 704
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 69,8300 Proposta adjudicada
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 59,8100 Proposta
desclassificada
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 71,4800  -
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 65,0900 Proposta
desclassificada
Valor proposta: R$ 70,4100 Valor negociado: Não informado Quantidade ofertada: 3650
Item 704 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²3650
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 102,1200
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
108 de 12603/01/2024 11:25

## Página 109

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 59,8400 Proposta
desclassificada
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 100,0000  -
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 100,0000  -
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 61,2700 Proposta
desclassificada
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 75,5700  -
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 76,5900  -
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 70,4600 Proposta
desclassificada
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 42,3000 Proposta
desclassificada
Valor proposta: R$ 98,0000 Valor negociado: Não informado Quantidade ofertada: 3650
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 50,0000 Proposta
desclassificada
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 74,7200  -
Valor proposta: R$ 87,2300 Valor negociado: Não informado Quantidade ofertada: 3650
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 98,8800  -
Valor proposta: R$ 98,8800 Valor negociado: Não informado Quantidade ofertada: 3650
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 73,5200  -
Valor proposta: R$ 73,5200 Valor negociado: Não informado Quantidade ofertada: 3650
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 102,1200  -
109 de 12603/01/2024 11:25

## Página 110

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 102,1200  -
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 102,1200  -
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 102,1200  -
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 76,6900  -
Valor proposta: R$ 76,6900 Valor negociado: Não informado Quantidade ofertada: 3650
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 75,5300  -
Valor proposta: R$ 75,5300 Valor negociado: Não informado Quantidade ofertada: 3650
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 102,1200  -
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 102,1200 Proposta
desclassificada
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 75,6800  -
Valor proposta: R$ 75,6800 Valor negociado: Não informado Quantidade ofertada: 3650
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 102,1200  -
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 102,1200  -
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 102,1200  -
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 102,1200  -
Valor proposta: R$ 102,1200 Valor negociado: Não informado Quantidade ofertada: 3650
Lances do Item  704
110 de 12603/01/2024 11:25

## Página 111

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:05:52 33.493.603/0001-21 R$ 70,4000
01/11/2023 14:06:50 43.050.611/0001-57 R$ 70,4600
01/11/2023 14:08:09 16.843.624/0001-00 R$ 71,0000
01/11/2023 14:08:34 32.227.070/0001-73 R$ 100,0000
01/11/2023 14:09:16 08.878.462/0001-18 R$ 71,4800
01/11/2023 14:10:27 11.862.800/0001-38 R$ 76,5900
01/11/2023 14:10:57 29.652.879/0001-38 R$ 74,7200
01/11/2023 14:11:29 73.315.905/0001-24 R$ 75,5700
01/11/2023 14:11:33 26.160.104/0001-57 R$ 69,8300
01/11/2023 14:12:11 33.493.603/0001-21 R$ 69,8200
01/11/2023 14:12:24 04.953.896/0001-84 R$ 65,0900
01/11/2023 14:12:29 33.493.603/0001-21 R$ 65,0800
01/11/2023 14:12:51 28.244.608/0001-80 R$ 59,8100
01/11/2023 14:15:32 16.843.624/0001-00 R$ 60,0000
01/11/2023 14:18:18 27.595.842/0001-90 R$ 59,8400
01/11/2023 14:19:54 26.601.871/0001-54 R$ 100,0000
01/11/2023 14:20:09 06.222.208/0001-31 R$ 56,9700
01/11/2023 14:20:24 06.222.208/0001-31 R$ 56,8100
01/11/2023 14:20:29 06.222.208/0001-31 R$ 56,8000
01/11/2023 14:20:49 06.222.208/0001-31 R$ 55,7300
01/11/2023 14:20:57 06.222.208/0001-31 R$ 55,7200
01/11/2023 14:24:22 33.493.603/0001-21 R$ 61,2700
01/11/2023 14:29:45 16.843.624/0001-00 R$ 42,3000
01/11/2023 14:30:13 06.222.208/0001-31 R$ 50,0000
111 de 12603/01/2024 11:25

## Página 112

UASG 120645 PREGÃO 62/2023
FORRO DE PVC, LISO, PARA AMBIENTES COMERCIAIS, INCLUSIVE ESTRUTURA DE FIXACAO. AF_05/2017_P
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 74,0500
Propostas do Item 705
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 74,0500 Proposta adjudicada
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 68,5600 Proposta
desclassificada
Valor proposta: R$ 74,5000 Valor negociado: Não informado Quantidade ofertada: 6039
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 62,6400 Proposta
desclassificada
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 75,9000 Proposta
desclassificada
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 79,5000  -
Valor proposta: R$ 93,3200 Valor negociado: Não informado Quantidade ofertada: 6039
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 66,0000 Proposta
desclassificada
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 41,6800 Proposta
desclassificada
Valor proposta: R$ 102,0000 Valor negociado: Não informado Quantidade ofertada: 6039
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 77,0000  -
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 109,0000  -
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
Item 705 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²6039
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 110,0000
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
112 de 12603/01/2024 11:25

## Página 113

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 82,5000  -
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 81,4000  -
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 46,9000 Proposta
desclassificada
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 50,0000 Proposta
desclassificada
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 62,6900 Proposta
desclassificada
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 110,0000  -
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 110,0000  -
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 110,0000  -
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 110,0000  -
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 110,0000  -
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 110,0000  -
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 88,8800  -
Valor proposta: R$ 88,8800 Valor negociado: Não informado Quantidade ofertada: 6039
113 de 12603/01/2024 11:25

## Página 114

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 110,0000  -
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 110,0000  -
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 80,4100  -
Valor proposta: R$ 80,4100 Valor negociado: Não informado Quantidade ofertada: 6039
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 80,2900  -
Valor proposta: R$ 80,2900 Valor negociado: Não informado Quantidade ofertada: 6039
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 110,0000  -
Valor proposta: R$ 110,0000 Valor negociado: Não informado Quantidade ofertada: 6039
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 79,2000  -
Valor proposta: R$ 79,2000 Valor negociado: Não informado Quantidade ofertada: 6039
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 82,6100  -
Valor proposta: R$ 82,6100 Valor negociado: Não informado Quantidade ofertada: 6039
Lances do Item  705
Data/hora Participante Lance
01/11/2023 14:05:53 33.493.603/0001-21 R$ 74,4900
01/11/2023 14:06:52 43.050.611/0001-57 R$ 75,9000
01/11/2023 14:08:04 16.843.624/0001-00 R$ 75,0000
01/11/2023 14:08:40 32.227.070/0001-73 R$ 109,0000
01/11/2023 14:09:24 08.878.462/0001-18 R$ 77,0000
01/11/2023 14:10:46 33.890.430/0001-85 R$ 50,0000
01/11/2023 14:10:58 29.652.879/0001-38 R$ 79,5000
01/11/2023 14:11:00 11.862.800/0001-38 R$ 82,5000
01/11/2023 14:11:36 73.315.905/0001-24 R$ 81,4000
01/11/2023 14:11:43 26.160.104/0001-57 R$ 74,0500
01/11/2023 14:12:31 04.953.896/0001-84 R$ 68,5600
01/11/2023 14:12:56 28.244.608/0001-80 R$ 62,6400
01/11/2023 14:15:39 16.843.624/0001-00 R$ 51,0000
114 de 12603/01/2024 11:25

## Página 115

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:18:34 27.595.842/0001-90 R$ 62,6900
01/11/2023 14:20:08 06.222.208/0001-31 R$ 55,3400
01/11/2023 14:20:18 06.222.208/0001-31 R$ 52,7400
01/11/2023 14:20:23 06.222.208/0001-31 R$ 52,6100
01/11/2023 14:20:29 06.222.208/0001-31 R$ 52,6000
01/11/2023 14:20:49 06.222.208/0001-31 R$ 51,7000
01/11/2023 14:24:28 33.493.603/0001-21 R$ 66,0000
01/11/2023 14:30:06 16.843.624/0001-00 R$ 41,6800
01/11/2023 14:30:13 06.222.208/0001-31 R$ 46,9000
RODAPE EM MADEIRA, ALTURA 7CM, FIXADO EM PECAS DE MADEIRA
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 25,3800
Propostas do Item 706
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 25,3800 Proposta adjudicada
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 25,1600 Proposta
desclassificada
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 13,5000 Proposta
desclassificada
Valor proposta: R$ 35,0000 Valor negociado: Não informado Quantidade ofertada: 2485
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 27,3400  -
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
Item 706 do Grupo G13 - SERVIÇO ENGENHARIA
Critério de julgamento:
Situação:
M2485
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 36,4600
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
115 de 12603/01/2024 11:25

## Página 116

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 21,8800 Proposta
desclassificada
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 35,0000  -
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 22,0600 Proposta
desclassificada
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 36,0000  -
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 26,6200  -
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 25,5200  -
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 15,3000 Proposta
desclassificada
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 23,8300 Proposta
desclassificada
Valor proposta: R$ 25,6300 Valor negociado: Não informado Quantidade ofertada: 2485
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 22,0300 Proposta
desclassificada
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 25,0000 Proposta
desclassificada
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 27,0500  -
Valor proposta: R$ 31,4100 Valor negociado: Não informado Quantidade ofertada: 2485
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 36,4600  -
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 36,4600  -
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
116 de 12603/01/2024 11:25

## Página 117

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 36,4600  -
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 36,4600  -
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 36,4600  -
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 26,6100  -
Valor proposta: R$ 26,6100 Valor negociado: Não informado Quantidade ofertada: 2485
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 27,4500  -
Valor proposta: R$ 27,4500 Valor negociado: Não informado Quantidade ofertada: 2485
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 36,4600  -
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 27,3800  -
Valor proposta: R$ 27,3800 Valor negociado: Não informado Quantidade ofertada: 2485
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 36,4600  -
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 27,3800  -
Valor proposta: R$ 27,3800 Valor negociado: Não informado Quantidade ofertada: 2485
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 36,4600  -
Valor proposta: R$ 36,4600 Valor negociado: Não informado Quantidade ofertada: 2485
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 35,8800  -
Valor proposta: R$ 35,8800 Valor negociado: Não informado Quantidade ofertada: 2485
Lances do Item  706
Data/hora Participante Lance
01/11/2023 14:05:25 33.890.430/0001-85 R$ 25,0000
01/11/2023 14:05:55 33.493.603/0001-21 R$ 25,6200
117 de 12603/01/2024 11:25

## Página 118

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:07:21 43.050.611/0001-57 R$ 25,1600
01/11/2023 14:07:59 16.843.624/0001-00 R$ 26,0000
01/11/2023 14:08:43 32.227.070/0001-73 R$ 36,0000
01/11/2023 14:09:22 33.493.603/0001-21 R$ 24,9900
01/11/2023 14:09:30 08.878.462/0001-18 R$ 25,5200
01/11/2023 14:11:00 29.652.879/0001-38 R$ 27,0500
01/11/2023 14:11:09 11.862.800/0001-38 R$ 27,3400
01/11/2023 14:11:41 73.315.905/0001-24 R$ 26,6200
01/11/2023 14:11:50 26.160.104/0001-57 R$ 25,3800
01/11/2023 14:12:39 04.953.896/0001-84 R$ 23,8300
01/11/2023 14:12:56 33.493.603/0001-21 R$ 23,8200
01/11/2023 14:12:58 28.244.608/0001-80 R$ 22,0300
01/11/2023 14:13:04 33.493.603/0001-21 R$ 22,0200
01/11/2023 14:15:44 16.843.624/0001-00 R$ 23,0000
01/11/2023 14:18:46 27.595.842/0001-90 R$ 22,0600
01/11/2023 14:20:03 26.601.871/0001-54 R$ 35,0000
01/11/2023 14:20:10 06.222.208/0001-31 R$ 18,1300
01/11/2023 14:20:19 06.222.208/0001-31 R$ 17,2600
01/11/2023 14:20:52 06.222.208/0001-31 R$ 16,9500
01/11/2023 14:24:37 33.493.603/0001-21 R$ 21,8800
01/11/2023 14:30:13 06.222.208/0001-31 R$ 15,3000
01/11/2023 14:30:17 16.843.624/0001-00 R$ 13,5000
118 de 12603/01/2024 11:25

## Página 119

UASG 120645 PREGÃO 62/2023
RODAPE EM MADEIRA, ALTURA 7CM, FIXADO COM COLA
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 25,8900
Propostas do Item 707
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 25,8900 Proposta adjudicada
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 22,1800 Proposta
desclassificada
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 29,8800  -
Valor proposta: R$ 34,8800 Valor negociado: Não informado Quantidade ofertada: 1460
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 27,7400  -
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 13,2600 Proposta
desclassificada
Valor proposta: R$ 35,0000 Valor negociado: Não informado Quantidade ofertada: 1460
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 22,5400 Proposta
desclassificada
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 22,5700 Proposta
desclassificada
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 16,5000 Proposta
desclassificada
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 36,0000  -
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
Item 707 do Grupo G13 - SERVIÇO ENGENHARIA
Critério de julgamento:
Situação:
M1460
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 36,9900
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
119 de 12603/01/2024 11:25

## Página 120

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 25,8900  -
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 25,5200 Proposta
desclassificada
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 27,0000  -
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 20,0000 Proposta
desclassificada
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 27,5400  -
Valor proposta: R$ 31,9300 Valor negociado: Não informado Quantidade ofertada: 1460
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 35,0000  -
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 24,3500 Proposta
desclassificada
Valor proposta: R$ 26,1400 Valor negociado: Não informado Quantidade ofertada: 1460
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 36,9900  -
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 36,9900  -
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 36,9900  -
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 36,9900  -
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 36,9900  -
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
120 de 12603/01/2024 11:25

## Página 121

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 36,9900  -
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 29,2200  -
Valor proposta: R$ 29,2200 Valor negociado: Não informado Quantidade ofertada: 1460
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 27,7800  -
Valor proposta: R$ 27,7800 Valor negociado: Não informado Quantidade ofertada: 1460
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 27,9500  -
Valor proposta: R$ 27,9500 Valor negociado: Não informado Quantidade ofertada: 1460
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 27,9200  -
Valor proposta: R$ 27,9200 Valor negociado: Não informado Quantidade ofertada: 1460
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 36,9900  -
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 36,9900  -
Valor proposta: R$ 36,9900 Valor negociado: Não informado Quantidade ofertada: 1460
Lances do Item  707
Data/hora Participante Lance
01/11/2023 14:05:38 33.890.430/0001-85 R$ 26,1000
01/11/2023 14:06:54 43.050.611/0001-57 R$ 25,5200
01/11/2023 14:07:55 16.843.624/0001-00 R$ 26,0000
01/11/2023 14:08:46 32.227.070/0001-73 R$ 36,0000
01/11/2023 14:09:26 33.493.603/0001-21 R$ 25,5100
01/11/2023 14:09:32 33.890.430/0001-85 R$ 25,0000
01/11/2023 14:09:38 08.878.462/0001-18 R$ 25,8900
01/11/2023 14:11:01 29.652.879/0001-38 R$ 27,5400
01/11/2023 14:11:20 11.862.800/0001-38 R$ 27,7400
01/11/2023 14:11:47 73.315.905/0001-24 R$ 27,0000
01/11/2023 14:11:49 33.493.603/0001-21 R$ 24,9900
01/11/2023 14:11:56 26.160.104/0001-57 R$ 25,8900
01/11/2023 14:12:46 04.953.896/0001-84 R$ 24,3500
121 de 12603/01/2024 11:25

## Página 122

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
01/11/2023 14:12:58 33.493.603/0001-21 R$ 24,3400
01/11/2023 14:13:01 28.244.608/0001-80 R$ 22,5400
01/11/2023 14:13:06 33.493.603/0001-21 R$ 22,5300
01/11/2023 14:15:49 16.843.624/0001-00 R$ 23,0000
01/11/2023 14:17:46 10.681.640/0001-68 R$ 29,8800
01/11/2023 14:18:54 27.595.842/0001-90 R$ 22,5700
01/11/2023 14:18:56 33.890.430/0001-85 R$ 20,0000
01/11/2023 14:20:05 26.601.871/0001-54 R$ 35,0000
01/11/2023 14:20:11 06.222.208/0001-31 R$ 19,2400
01/11/2023 14:20:19 06.222.208/0001-31 R$ 18,3900
01/11/2023 14:20:53 06.222.208/0001-31 R$ 18,0900
01/11/2023 14:24:47 33.493.603/0001-21 R$ 22,1900
01/11/2023 14:30:14 06.222.208/0001-31 R$ 16,5000
01/11/2023 14:30:19 16.843.624/0001-00 R$ 13,2600
16/11/2023 09:36:40 33.493.603/0001-21 R$ 22,1800
ENCERAMENTO MANUAL EM MADEIRA - 3 DEMAOS
Adjucado e Homologado por CPF ***.107.***-*0 - HUMBERTO RUBIN NETO para VERAS ENGENHARIA LTDA, CNPJ
26.160.104/0001-57, melhor lance: R$ 19,7400
Propostas do Item 708
(D) Declarante MeEpp/Equiparada (Art. 3º da Lei Complementar nº 123, de 14 de dezembro de 2006)
Fornecedor Valor ofertado Situação
26.160.104/0001-57 - VERAS ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 19,7400 Proposta adjudicada
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
33.493.603/0001-21 - DX2 ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 16,7200 Proposta
desclassificada
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
Item 708 do Grupo G13 - Serviço Engenharia
Critério de julgamento:
Situação:
M²1930
R$ 0,0100
Quantidade:
Adjudicado e Homologado
Tratamento Diferenciado
Unidade de fornecimento:
R$ 27,8900
Sem benefícios ME/EPP (Art. 4º, lei 14.133/2021)
Menor PreçoValor estimado:
Intervalo mínimo entre lances:
122 de 12603/01/2024 11:25

## Página 123

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
06.222.208/0001-31 - VAN EDIL COMERCIO DE ALIMENTOS E
SERVICOS DE MAQUINAS E DECORACOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 15,0000 Proposta
desclassificada
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
10.681.640/0001-68 - CAMBIARE PROJETOS E
EMPREENDIMENTOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 19,9900  -
Valor proposta: R$ 26,8800 Valor negociado: Não informado Quantidade ofertada: 1930
28.244.608/0001-80 - DSM SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 17,2800 Proposta
desclassificada
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
43.050.611/0001-57 - VERTICO ARQUITETURA E
CONSTRUCAO LTDA.
Porte MeEpp/Equiparada: Sim (D)
R$ 19,2400 Proposta
desclassificada
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim R$ 9,5700 Proposta
desclassificada
Valor proposta: R$ 26,0000 Valor negociado: Não informado Quantidade ofertada: 1930
32.227.070/0001-73 - CETUS CONSTRUTORA LTDA
Porte MeEpp/Equiparada: Não R$ 27,0000  -
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
08.878.462/0001-18 - SETOR MB CONSTRUCOES, SERVICOS E
COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 19,5200  -
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
29.652.879/0001-38 - CONCRETE HOUSE CONSTRUCOES,
COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 20,8900  -
Valor proposta: R$ 24,1800 Valor negociado: Não informado Quantidade ofertada: 1930
26.601.871/0001-54 - PILLAR SERVICOS ELETRICOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 25,0000  -
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
73.315.905/0001-24 - FEMAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 20,3600  -
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
27.595.842/0001-90 - ETEPAR CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 17,3300 Proposta
desclassificada
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
33.890.430/0001-85 - D A G G TAVARES PROJETOS
ESTRUTURAIS LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 10,0000 Proposta
desclassificada
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 18,6300 Proposta
desclassificada
123 de 12603/01/2024 11:25

## Página 124

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
04.953.896/0001-84 - METSOM CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não R$ 18,6300 Proposta
desclassificada
Valor proposta: R$ 19,9400 Valor negociado: Não informado Quantidade ofertada: 1930
11.862.800/0001-38 - STED EMPREENDIMENTOS E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Não
R$ 20,9100  -
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
04.542.982/0001-02 - CONSTRUBASA PLANEJAMENTO E
CONSTRUCOES LTDA
Porte MeEpp/Equiparada: Sim
R$ 21,2400  -
Valor proposta: R$ 21,2400 Valor negociado: Não informado Quantidade ofertada: 1930
17.226.128/0001-70 - VIPCORP CONSTRUCOES E REFORMAS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 27,8900  -
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
03.045.711/0001-70 - CONSTRUTORA EDIL LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 27,8900  -
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
11.239.915/0001-70 - SUPERAR SOLUCOES C. LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 27,8900  -
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
05.626.447/0001-94 - L GOMES DE CASTRO CONSTRUCOES
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 27,8900  -
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
73.509.440/0001-42 - GENERAL CONTRACTOR CONSTRUTORA
LTDA
Porte MeEpp/Equiparada: Não
R$ 27,8900  -
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
31.571.038/0001-48 - A E S PARCERIA COMERCIAL E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 27,8900  -
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
08.318.369/0001-59 - ROMARFEL COMERCIO E SERVICOS
LTDA
Porte MeEpp/Equiparada: Sim (D)
R$ 27,8900  -
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
47.028.904/0001-99 - NHC SERVICOS E COMERCIO LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 27,8900  -
Valor proposta: R$ 27,8900 Valor negociado: Não informado Quantidade ofertada: 1930
01.434.344/0001-71 - MARIS SERVICOS DE ENGENHARIA LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 21,2600  -
Valor proposta: R$ 21,2600 Valor negociado: Não informado Quantidade ofertada: 1930
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 20,9500  -
124 de 12603/01/2024 11:25

## Página 125

UASG 120645 PREGÃO 62/2023
Fornecedor Valor ofertado Situação
08.659.240/0001-04 - LAUSHER COMERCIO E SERVICOS LTDA
Porte MeEpp/Equiparada: Sim (D) R$ 20,9500  -
Valor proposta: R$ 20,9500 Valor negociado: Não informado Quantidade ofertada: 1930
39.109.806/0001-58 - MEGA ENGENHARIA LTDA
Porte MeEpp/Equiparada: Não R$ 19,8000  -
Valor proposta: R$ 19,8000 Valor negociado: Não informado Quantidade ofertada: 1930
Lances do Item  708
Data/hora Participante Lance
01/11/2023 14:05:47 33.890.430/0001-85 R$ 19,5000
01/11/2023 14:06:28 43.050.611/0001-57 R$ 19,2400
01/11/2023 14:07:51 16.843.624/0001-00 R$ 20,0000
01/11/2023 14:08:50 32.227.070/0001-73 R$ 27,0000
01/11/2023 14:09:31 33.493.603/0001-21 R$ 19,2300
01/11/2023 14:09:34 33.890.430/0001-85 R$ 19,0000
01/11/2023 14:09:45 08.878.462/0001-18 R$ 19,5200
01/11/2023 14:11:03 29.652.879/0001-38 R$ 20,8900
01/11/2023 14:11:29 11.862.800/0001-38 R$ 20,9100
01/11/2023 14:11:51 33.493.603/0001-21 R$ 18,9900
01/11/2023 14:11:52 73.315.905/0001-24 R$ 20,3600
01/11/2023 14:12:03 26.160.104/0001-57 R$ 19,7400
01/11/2023 14:12:51 04.953.896/0001-84 R$ 18,6300
01/11/2023 14:13:00 33.493.603/0001-21 R$ 18,6200
01/11/2023 14:13:04 28.244.608/0001-80 R$ 17,2800
01/11/2023 14:13:07 33.493.603/0001-21 R$ 17,2700
01/11/2023 14:15:54 16.843.624/0001-00 R$ 18,0000
01/11/2023 14:17:52 10.681.640/0001-68 R$ 19,9900
01/11/2023 14:17:59 33.890.430/0001-85 R$ 10,0000
01/11/2023 14:19:02 27.595.842/0001-90 R$ 17,3300
01/11/2023 14:20:09 26.601.871/0001-54 R$ 25,0000
01/11/2023 14:20:11 06.222.208/0001-31 R$ 16,7200
01/11/2023 14:20:20 06.222.208/0001-31 R$ 16,1900
01/11/2023 14:20:53 06.222.208/0001-31 R$ 16,0000
01/11/2023 14:24:58 33.493.603/0001-21 R$ 16,7300
01/11/2023 14:30:14 06.222.208/0001-31 R$ 15,0000
01/11/2023 14:30:22 16.843.624/0001-00 R$ 9,5700
125 de 12603/01/2024 11:25

## Página 126

UASG 120645 PREGÃO 62/2023
Data/hora Participante Lance
16/11/2023 09:36:35 33.493.603/0001-21 R$ 16,7200
Fase Recursal do Item/Grupo *
* Maiores detalhes sobre recursos, contrarrazões, decisões e revisões deverão ser consultados no sistema.
Sessão 1
Prazos:
Intenção de recurso no julgamento: 26/12/2023 10:42:42
Intenção de recurso na habilitação: 26/12/2023 13:15:30
Recurso: 29/12/2023 23:59:59
Contrarrazão: 04/01/2024 23:59:59
Recursos realizados:
16.843.624/0001-00 - ZWI ENGENHARIA LTDA
Intenção de recurso no julgamento: 26/12/2023 10:39:46
Recurso: (Desistiu Cadastro)
Contrarrazões: Não foi realizado cadastro
126 de 12603/01/2024 11:25
