# Ata de Registro de Preços nº 00006

Fonte: [PDF original](https://pncp.gov.br/pncp-api/v1/orgaos/02313673000127/compras/2023/000105/atas/000001/arquivos/1)

SHA-256 do PDF: `cedfd707be299af6f0500420ae8eb7948a1be9718c27fcc416beca7d9a9d48d1`

Texto extraído automaticamente, organizado por página.

## Página 1

AGÊNCIA NACIONAL DO PETRÓLEO, GÁS NATURAL E BIOCOMBUSTÍVEIS
Avenida Rio Branco, 65, 12º a 22º andares 
- Bairro Centro, Rio de Janeiro/RJ, CEP 20090-004
Telefone: (21) 2112-8100 e Fax: @fax_unidade@ 
- http://www.anp.gov.br
  
Processo nº 48610.215081/2023-93
  
ATA DE REGISTRO DE PREÇO 
Lei nº 14.133, de 1º de abril de 2021
ATA DE REGISTRO DE PREÇOS N.º 06/23-ANP-215.081
 
ATA DE REGISTRO DE PREÇO Nº 06/23-ANP-215.081, QUE FAZEM,
ENTRE SI, A 
AGÊNCIA NACIONAL DO PETRÓLEO, GÁS NATURAL E
BIOCOMBUSTÍVEIS – ANP  
E A EMPRESA 
LIMA COMERCIO DE
MATERIAIS E SERVIÇOS EIRELI.
 
 
 
A 
AGÊNCIA NACIONAL DO PETRÓLEO, GÁS NATURAL E BIOCOMBUSTÍVEIS – ANP
, Autarquia Federal
insDtuída pela Lei nº 9.478, de 06 de agosto  de 1997, alterada pela Lei nº 11.097, de 13 de janeiro de
2005, 
publicada no D.O.U. em 14/01/05
, implantada pelo Decreto nº 2.455, de 14 de janeiro de 1998,
com sede no Setor de Grandes Áreas Norte, SGAN, quadra 603, módulos “H” e “I”, Brasília/DF, 
CEP:
70830-902
, e Escritório Central na Avenida Rio Branco, nº 65, do 12º ao 22º andar, Centro, Rio de
Janeiro/RJ, CEP 20.090-004, inscrita no CNPJ sob o nº 02.313.673/0002-08, neste ato representada por
seu 
Diretor-Geral, Sr. 
RODOLFO HENRIQUE DE SABOIA
, matrícula funcional SIAPE nº 3214859,
 
designado
por meio do Decreto de 05 de novembro de 2020, publicado no Diário Oﬁcial da União em 06 de
novembro de 2020, seção 02, folha 01, no uso da competência que lhe foi atribuída no inciso IV, do Art.
9º, do Anexo I do Decreto nº 2.455, de 14/01/1998
, considerando o julgamento da licitação na
modalidade de pregão, na forma eletrônica, para REGISTRO DE PREÇOS nº 35/2023, publicada em
17/10/2023, processo administraDvo n.º 48610.215081/2023-93, RESOLVE registrar os preços
da empresa indicada e qualiﬁcada nesta ATA, de acordo com a classiﬁcação por ela alcançada e nas
quanDdades cotadas, atendendo as condições previstas no Edital de licitação, sujeitando-se as partes às
normas constantes na Lei nº 14.133, de 1º de abril de 2021, no Decreto n.º 11.462, de 31 de março de
2023, e em conformidade com as disposições a seguir: 
 
1. CLÁUSULA PRIMEIRA – OBJETO
1.1.    A presente Ata tem por objeto o registro de preços para a eventual aquisição de materiais de
consumo, com fornecimento de 
dispensers
 em regime de comodato, especiﬁcado no Termo de
Referência, anexo ao edital de Licitação nº 35/2023, que é parte integrante desta Ata, assim como
a proposta cujo preços tenham sido registrados, independentemente de transcrição.
 
2.    DOS PREÇOS, ESPECIFICAÇÕES E QUANTITATIVOS
Ata de Registro de Preços 3597103         SEI 48610.215081/2023-93 / pg. 1

## Página 2

2.1. Os preços registrados, as especiﬁcações do objeto, as quanDdades máximas de cada item,
fornecedor e as demais condições ofertadas na proposta são as que seguem:
Razão social: 
LIMA COMERCIO DE MATERIAIS E SERVIÇOS EIRELI
CNPJ: 
30.735.771/0001-98
Endereço: 
AV. DAS AMÉRICAS, N° 2000 BOX. 51, BARRA DA TIJUCA, RIO DE JANEIRO - RJ
Representante legal: 
SILVANA CONCEIÇÃO DE LIMA
Contatos: 
(21) 2222-0456 - limacomerciodemateriais@hotmail.com
Grupo
Item
Descrição
Unidade
Quantidade 
Valor
Unitário
Subtotal
 
 
 
 
 
 
1
 
 
 
 
 
 
 
1
Sabonete líquido
Frasco 800 ml
1.094
 
R$ 5,40
 
 
R$ 5.907,60
 
 
2
Papel toalha
Fardo 1.000 fl
13.870
R$ 10,59
R$
146.883,30
 
3
Papel higiênico
Rolo 300 mt
9.000
R$ 5,74
R$ 51.660,00
 
4
Protetor de assento sanitário
descartável
Cx 40 un
2.860
R$ 6,72
R$ 19.219,20
5
 
Saquinho descartável
coletor de absorvente
higiênico
 
  Cx 25 un
 
 
360
 
R$ 6,08
R$ 2.188,80
 
6
Álcool em gel
Bolsa 800 ml
212
R$ 8,12
R$ 1.721,44
TOTAL
 
R$
227.580,34
 
 
2.2. Os quantitativos mínimos constam na Tabela do item 11.1 do Termo de Referência.
 
3. ÓRGÃO(S) GERENCIADOR E PARTICIPANTE(S)
3.1. O órgão gerenciador será a Agência Nacional do Petróleo, Gás Natural e Biocombustíveis - ANP.
 
4. DA ADESÃO À ATA DE REGISTRO DE PREÇOS 
4.1. Não será admiDda a adesão à ata de registro de preços decorrente desta licitação ou desta
contratação direta, conforme justificativa apresentada nos estudos técnicos preliminares.
4.2. É vedado efetuar acréscimos nos quantitativos fixados na ata de registro de preços.
 
5. VALIDADE, FORMALIZAÇÃO DA ATA DE REGISTRO DE PREÇOS E CADASTRO RESERVA
5.1. A validade da Ata de Registro de Preços será de 1 (um) ano, contado a parDr do primeiro dia úDl
subsequente à data de divulgação no PNCP, podendo ser prorrogada por igual período, mediante a
anuência do fornecedor, desde que comprovado o preço vantajoso.
5.1.1. Na formalização do instrumento subsDtuto deverá haver a indicação da disponibilidade dos
créditos orçamentários respectivos
5.2. A contratação com os fornecedores registrados na ata será formalizada pelo órgão ou pela enDdade
interessada por intermédio de emissão de nota de empenho de despesa, conforme o art. 95 da Lei nº
14.133, de 2021
5.2.1. O instrumento contratual de que trata o item 5.2. deverá ser assinado no prazo de validade da ata
de registro de preços.
Ata de Registro de Preços 3597103         SEI 48610.215081/2023-93 / pg. 2

## Página 3

5.3. Após a homologação da licitação, deverão ser observadas as seguintes condições para formalização
da ata de registro de preços:
5.3.1. Serão registrados na ata os preços os quanDtaDvos do adjudicatário, devendo ser observada a
possibilidade de o licitante oferecer ou não proposta em quanDtaDvo inferior ao máximo previsto no
edital e se obrigar nos limites dela;
5.3.2. Será incluído na ata, na forma de anexo, o registro dos licitantes ou dos fornecedores que:
5.3.2.1. Aceitarem cotar os bens, as obras ou os serviços com preços iguais aos do adjudicatário,
observada a classificação da licitação; e
5.3.2.2. Mantiverem sua proposta original.
5.3.3. Será respeitada, nas contratações, a ordem de classiﬁcação dos licitantes ou dos fornecedores
registrados na ata.
5.4. O registro a que se refere o item 5.4.2 tem por objeDvo a formação de cadastro de reserva para o
caso de impossibilidade de atendimento pelo signatário da ata.
5.5. Para ﬁns da ordem de classiﬁcação, os licitantes ou fornecedores que aceitarem reduzir suas
propostas para o preço do adjudicatário antecederão aqueles que mantiverem sua proposta original.
5.6. A habilitação dos licitantes que comporão o cadastro de reserva a que se refere o item 5.4.2.2
somente será efetuada quando houver necessidade de contratação dos licitantes remanescentes, nas
seguintes hipóteses:
5.6.1. Quando o licitante vencedor não assinar a ata de registro de preços, no prazo e nas condições
estabelecidos no edital; e
5.6.2. Quando houver o cancelamento do registro do licitante ou do registro de preços nas hipóteses
previstas no item 9.
5.7. O preço registrado com indicação dos licitantes e fornecedores será divulgado no PNCP e ﬁcará
disponibilizado durante a vigência da ata de registro de preços.
5.8. Após a homologação da licitação, o licitante mais bem classiﬁcado, será convocado para assinar a ata
de registro de preços, no prazo e nas condições estabelecidos no edital de licitação, sob pena de decair o
direito, sem prejuízo das sanções previstas na Lei nº 14.133, de 2021.
5.8.1. O prazo de convocação poderá ser prorrogado 1 (uma) vez, por igual período, mediante solicitação
do licitante ou fornecedor convocado, desde que apresentada dentro do prazo, devidamente jusDﬁcada,
e que a justificativa seja aceita pela Administração.
5.9. A ata de registro de preços será assinada por meio de assinatura digital e disponibilizada no Sistema
de Registro de Preços.
5.10. Quando o convocado não assinar a ata de registro de preços no prazo e nas condições
estabelecidos no edital ou no aviso de contratação, e observado o disposto no item 5.7, observando o
item 5.7 e subitens, ﬁca facultado à Administração convocar os licitantes remanescentes do cadastro de
reserva, na ordem de classiﬁcação, para fazê-lo em igual prazo e nas condições propostas pelo primeiro
classificado.
5.11. Na hipótese de nenhum dos licitantes que trata o item 5.4.2.1, aceitar a contratação nos termos do
item anterior, a Administração, observados o valor esDmado e sua eventual atualização nos termos do
edital, poderá:
5.11.1. Convocar para negociação os demais licitantes ou fornecedores remanescentes cujos preços
foram registrados sem redução, observada a ordem de classiﬁcação, com vistas à obtenção de preço
melhor, mesmo que acima do preço do adjudicatário; ou
5.11.2. Adjudicar e ﬁrmar o contrato nas condições ofertadas pelos licitantes ou fornecedores
remanescentes, atendida a ordem classificatória, quando frustrada a negociação de melhor condição.
5.12. A existência de preços registrados implicará compromisso de fornecimento nas condições
Ata de Registro de Preços 3597103         SEI 48610.215081/2023-93 / pg. 3

## Página 4

estabelecidas, mas não obrigará a Administração a contratar, facultada a realização de licitação
específica para a aquisição pretendida, desde que devidamente justificada.
 
6. ALTERAÇÃO OU ATUALIZAÇÃO DOS PREÇOS REGISTRADOS
6.1. Os preços registrados poderão ser alterados ou atualizados em decorrência de eventual redução dos
preços praDcados no mercado ou de fato que eleve o custo dos bens, das obras ou dos serviços
registrados, nas seguintes situações:
6.1.1. Em caso de força maior, caso fortuito ou fato do príncipe ou em decorrência de fatos imprevisíveis
ou previsíveis de consequências incalculáveis, que inviabilizem a execução da ata tal como pactuada, nos
termos da alínea “d” do inciso II do caput do art. 124 da Lei nº 14.133, de 2021;
6.1.2. Em caso de criação, alteração ou exDnção de quaisquer tributos ou encargos legais ou a
superveniência de disposições legais, com comprovada repercussão sobre os preços registrados;
 
7. NEGOCIAÇÃO DE PREÇOS REGISTRADOS
7.1. Na hipótese de o preço registrado tornar-se superior ao preço praDcado no mercado por moDvo
superveniente, o órgão ou enDdade gerenciadora convocará o fornecedor para negociar a redução do
preço registrado.
7.1.1. Caso não aceite reduzir seu preço aos valores praDcados pelo mercado, o fornecedor será liberado
do compromisso assumido quanto ao item registrado, sem aplicação de penalidades administrativas.
7.1.2. Na hipótese prevista no item anterior, o gerenciador convocará os fornecedores do cadastro de
reserva, na ordem de classiﬁcação, para veriﬁcar se aceitam reduzir seus preços aos valores de mercado
e não convocará os licitantes ou fornecedores que tiveram seu registro cancelado.
7.1.3. Se não obDver êxito nas negociações, o órgão ou enDdade gerenciadora procederá ao
cancelamento da ata de registro de preços, adotando as medidas cabíveis para obtenção de contratação
mais vantajosa.
7.1.4. Na hipótese de redução do preço registrado, o gerenciador comunicará aos órgãos e às enDdades
que Dverem ﬁrmado contratos decorrentes da ata de registro de preços para que avaliem a conveniência
e a oportunidade de diligenciarem negociação com vistas à alteração contratual, observado o disposto
no art. 124 da Lei nº 14.133, de 2021.
7.2. Na hipótese de o preço de mercado tornar-se superior ao preço registrado e o fornecedor não poder
cumprir as obrigações estabelecidas na ata, será facultado ao fornecedor requerer ao gerenciador a
alteração do preço registrado, mediante comprovação de fato superveniente que supostamente o
impossibilite de cumprir o compromisso.
7.2.1. Neste caso, o fornecedor encaminhará, juntamente com o pedido de alteração, a documentação
comprobatória ou a planilha de custos que demonstre a inviabilidade do preço registrado em relação às
condições inicialmente pactuadas.
7.2.2. Não hipótese de não comprovação da existência de fato superveniente que inviabilize o preço
registrado, o pedido será indeferido pelo órgão ou enDdade gerenciadora e o fornecedor deverá cumprir
as obrigações estabelecidas na ata, sob pena de cancelamento do seu registro, nos termos do item 9.1,
sem prejuízo das sanções previstas na Lei nº 14.133, de 2021, e na legislação aplicável.
7.2.3. Na hipótese de cancelamento do registro do fornecedor, nos termos do item anterior, o
gerenciador convocará os fornecedores do cadastro de reserva, na ordem de classiﬁcação, para veriﬁcar
se aceitam manter seus preços registrados, observado o disposto no item 5.7.
7.2.4. Se não obDver êxito nas negociações, o órgão ou enDdade gerenciadora procederá ao
cancelamento da ata de registro de preços, nos termos do item 9.4, e adotará as medidas cabíveis para a
obtenção da contratação mais vantajosa.
7.2.5. Na hipótese de comprovação da majoração do preço de mercado que inviabilize o preço
Ata de Registro de Preços 3597103         SEI 48610.215081/2023-93 / pg. 4

## Página 5

registrado, conforme previsto no item 7.2 e no item 7.2.1, o órgão ou enDdade gerenciadora atualizará o
preço registrado, de acordo com a realidade dos valores praticados pelo mercado
7.2.6. O órgão ou enDdade gerenciadora comunicará aos órgãos e às enDdades que Dverem ﬁrmado
contratos decorrentes da ata de registro de preços sobre a efeDva alteração do preço registrado, para
que avaliem a necessidade de alteração contratual, observado o disposto no art. 124 da Lei nº 14.133, de
2021.
 
8. REMANEJAMENTO DAS QUANTIDADES REGISTRADAS NA ATA DE REGISTRO DE PREÇOS
8.1. As quantidades previstas para os itens com preços registrados nas atas de registro de preços poderão
ser remanejadas pelo órgão ou enDdade gerenciadora entre os órgãos ou as enDdades parDcipantes e
não participantes do registro de preços.
8.2. O remanejamento somente poderá ser feito:
8.2.1. De órgão ou entidade participante para órgão ou entidade participante; ou
8.2.2. De órgão ou entidade participante para órgão ou entidade não participante.
8.3. O órgão ou enDdade gerenciadora que Dver esDmado as quanDdades que pretende contratar será
considerado participante para efeito do remanejamento.
8.4. Na hipótese de remanejamento de órgão ou enDdade parDcipante para órgão ou enDdade não
participante, serão observados os limites previstos no art. 32 do Decreto nº 11.462, de 2023.
8.5. CompeDrá ao órgão ou à enDdade gerenciadora autorizar o remanejamento solicitado, com a
redução do quanDtaDvo inicialmente informado pelo órgão ou pela enDdade parDcipante, desde que
haja prévia anuência do órgão ou da entidade que sofrer redução dos quantitativos informados.
8.6. Caso o remanejamento seja feito entre órgãos ou enDdades dos Estados, do Distrito Federal ou de
Municípios disDntos, caberá ao fornecedor beneﬁciário da ata de registro de preços, observadas as
condições nela estabelecidas, optar pela aceitação ou não do fornecimento decorrente do
remanejamento dos itens.
8.7. Na hipótese da compra centralizada, não havendo indicação pelo órgão ou pela enDdade
gerenciadora, dos quanDtaDvos dos parDcipantes da compra centralizada, nos termos do item 8.3, a
distribuição das quantidades para a execução descentralizada será por meio do remanejamento.
 
9. CANCELAMENTO DO REGISTRO DO LICITANTE VENCEDOR E DOS PREÇOS REGISTRADOS
9.1. O registro do fornecedor será cancelado pelo gerenciador, quando o fornecedor:
9.1.1. Descumprir as condições da ata de registro de preços, sem motivo justificado;
9.1.2. Não reDrar a nota de empenho, ou instrumento equivalente, no prazo estabelecido pela
Administração sem justificativa razoável;
9.1.3. Não aceitar manter seu preço registrado, na hipótese prevista no arDgo 27, § 2º, do Decreto nº
11.462, de 2023; ou
9.1.4. Sofrer sanção prevista nos incisos III ou IV do caput do art. 156 da Lei nº 14.133, de 2021.
9.1.4.1. Na hipótese de aplicação de sanção prevista nos incisos III ou IV do caput do art. 156 da Lei nº
14.133, de 2021, caso a penalidade aplicada ao fornecedor não ultrapasse o prazo de vigência da ata de
registro de preços, poderá o órgão ou a enDdade gerenciadora poderá, mediante decisão fundamentada,
decidir pela manutenção do registro de preços, vedadas contratações derivadas da ata enquanto
perdurarem os efeitos da sanção.
9.2. O cancelamento de registros nas hipóteses previstas no item 9.1 será formalizado por despacho do
órgão ou da entidade gerenciadora, garantidos os princípios do contraditório e da ampla defesa.
9.3. Na hipótese de cancelamento do registro do fornecedor, o órgão ou a enDdade gerenciadora poderá
Ata de Registro de Preços 3597103         SEI 48610.215081/2023-93 / pg. 5

## Página 6

convocar os licitantes que compõem o cadastro de reserva, observada a ordem de classificação.
9.4. O cancelamento dos preços registrados poderá ser realizado pelo gerenciador, em determinada ata
de registro de preços, total ou parcialmente, nas seguintes hipóteses, desde que devidamente
comprovadas e justificadas:
9.4.1. Por razão de interesse público;
9.4.2. A pedido do fornecedor, decorrente de caso fortuito ou força maior; ou
9.4.3. Se não houver êxito nas negociações, nas hipóteses em que o preço de mercado tornar-se superior
ou inferior ao preço registrado, nos termos do artigos 26, § 3º e 27, § 4º, ambos do Decreto nº 11.462, de
2023.
 
10. DAS PENALIDADES
10.1. O descumprimento da Ata de Registro de Preços ensejará aplicação das penalidades estabelecidas
no edital.
10.1.1. As sanções também se aplicam aos integrantes do cadastro de reserva no registro de preços que,
convocados, não honrarem o compromisso assumido injustificadamente após terem assinado a ata.
10.2. É da competência do gerenciador a aplicação das penalidades decorrentes do descumprimento do
pactuado nesta ata de registro de preço (art. 7º, inc. XIV, do Decreto nº 11.462, de 2023), exceto nas
hipóteses em que o descumprimento disser respeito às contratações dos órgãos ou enDdade
parDcipante, caso no qual caberá ao respecDvo órgão parDcipante a aplicação da penalidade (art. 8º, inc.
IX, do Decreto nº 11.462, de 2023).
10.3. O órgão ou enDdade parDcipante deverá comunicar ao órgão gerenciador qualquer das ocorrências
previstas no item 9.1, dada a necessidade de instauração de procedimento para cancelamento do
registro do fornecedor.
 
11. CONDIÇÕES GERAIS
11.1. As condições gerais de execução do objeto, tais como os prazos para entrega e recebimento, as
obrigações da Administração e do fornecedor registrado, penalidades e demais condições do ajuste,
encontram-se definidos no Termo de Referência, ANEXO AO EDITAL.
11.2. No caso de adjudicação por preço global de grupo de itens, só será admiDda a contratação de parte
de itens do grupo se houver prévia pesquisa de mercado e demonstração de sua vantagem para o órgão
ou a entidade.
 
Para ﬁrmeza e validade do pactuado, a presente Ata foi lavrada, que, depois de lida e achada em ordem,
vai assinada pelas partes e testemunhas.
 
_________________________
Representante legal do CONTRATANTE
_________________________
Representante legal do CONTRATADO
 
TESTEMUNHAS:
1-
2-    
Ata de Registro de Preços 3597103         SEI 48610.215081/2023-93 / pg. 6

## Página 7

Documento assinado eletronicamente por 
GLLAUCO CHILELLI MERCADANTE
, 
Pregoeiro
, em
07/12/2023, às 08:00, conforme horário oficial de Brasília, com fundamento no art. 4º, § 3º, do
Decreto nº 10.543, de 13 de novembro de 2020
.
Documento assinado eletronicamente por 
silvana conceição de lima
, 
Usuário Externo
, em 07/12/2023,
às 08:42, conforme horário oficial de Brasília, com fundamento no art. 4º, § 3º, do 
Decreto nº 10.543,
de 13 de novembro de 2020
.
Documento assinado eletronicamente por 
RAFAEL DE CARVALHO LINS
, 
Coordenador Geral de
Aquisições
, em 07/12/2023, às 15:04, conforme horário oficial de Brasília, com fundamento no art. 4º,
§ 3º, do 
Decreto nº 10.543, de 13 de novembro de 2020
.
Documento assinado eletronicamente por 
RODOLFO HENRIQUE DE SABOIA
, 
Diretor-Geral
, em
08/12/2023, às 16:36, conforme horário oficial de Brasília, com fundamento no art. 4º, § 3º, do
Decreto nº 10.543, de 13 de novembro de 2020
.
A autenticidade deste documento pode ser conferida no site
http://sei.anp.gov.br/sei/controlador_externo.php?
acao=documento_conferir&id_orgao_acesso_externo=0
, informando o código verificador 
3597103
 e o
código CRC 
97C7234E
.
 
Referência:
 Processo nº 48610.215081/2023-93
SEI nº 3597103
Ata de Registro de Preços 3597103         SEI 48610.215081/2023-93 / pg. 7
