# Ata de Registro de PreÃ§os nÂº 00444

Fonte: [PDF original](https://pncp.gov.br/pncp-api/v1/orgaos/00394502002864/compras/2025/000072/atas/000001/arquivos/1)

SHA-256 do PDF: `efac820bd023a46f8d976f6210ac4f18d0bd32aed58be16e139831bd8bc70517`

Texto extraído automaticamente, organizado por página.

## Página 1

___________________________________________________________________ 
Câmara Nacional de Modelos de Licitações e Contratos da Consultoria-Geral da União 
Atualização: maio/2023 
Ata de Registro de Preços – Lei nº 14.133, de 2021. 
Aprovado pela Secretaria de Gestão e Inovação. 
 
MARINHA DO BRASIL 
CENTRO DE OBTENÇÃO DA MARINHA NO RIO DE JANEIRO 
ATA DE REGISTRO DE PREÇOS 
Pregão Eletrônico nº 90101/2025 
771300/2025-444/00 
 
O Centro de Obtenção da Marinha no Rio de Janeiro, com sede na Av. Brasil, nº 10.500, Olaria, Rio de 
Janeiro/RJ, inscrito no CNPJ/MF sob o nº 00.394.502/0342-00, neste ato representado pelo Capitão 
de Fragata (IM) CLAUDIO DE JESUS MONTEIRO DE BARROS, nomeado pela Ordem de Serviço nº 
183/2023 do COMRJ, de 8 de novembro de 2023, portador da Matrícula Funcional nº 97.0334.30, 
considerando o julgamento da licitação na modalidade de pregão, na forma eletrônica, para 
REGISTRO DE PREÇOS nº 90101/2025, publicada no Diário Oficial da União (DOU) de 17/06/2025, 
Processo Administrativo nº 63342.001625/2025-02, RESOLVE registrar os preços da empresa indicada 
e qualificada nesta ATA, de acordo com a classificação por ela alcançada e nas quantidades cotadas, 
atendendo as condições previstas no edital de licitação, sujeitando-se as partes às normas constantes 
na Lei nº 14.133, de 1º de abril de 2021, no Decreto nº 11.462, de 31 de março de 2023, e em 
conformidade com as disposições a seguir:  
 
EMPRESA REGISTRADA:  
Razão Social: AKZO NOBEL LTDA; e 
CNPJ: 60.561.719/0097-75. 
 
1. DO OBJETO 
1.1. A presente Ata tem por objeto o registro de preços para a eventual aquisição de Tintas 
Marítimas para o Período de Manutenção Geral do Submarino Tikuna, especificado no apêndice I do 
Termo de Referência, anexo I do edital do Pregão Eletrônico nº 90101/2025, que é parte integrante 
desta Ata, assim como as propostas cujos preços tenham sido registrados, independentemente de 
transcrição. 
 
2. DOS PREÇOS, ESPECIFICAÇÕES E QUANTITATIVOS 
2.1. O preço registrado, as especificações do objeto, as quantidades mínimas e máximas de cada 
item, fornecedor(es) e as demais condições ofertadas na(s) proposta(s) são as que seguem:  
 
GRUPO 1 
 
ITEM DESCRIÇÃO DETALHADA MARCA UF QTD PREÇO UNI-
TÁRIO 
PREÇO 
TOTAL 
1 
TINTA EPOXI VERMELHA CONJUNTO 
CONTENDO BALDE DE 20L DO COMPONENTE 
"A" E LATA COM 5L DO COMPONENTE "B". 
INTERNATIONAL CJ 40 R$ 760,00 R$ 30.400,00

## Página 2

Continuação da Ata de Registro de Preços nº 71300/2025-444/00, do COMRJ. 
 
________________________________________________________________________ 
Câmara Nacional de Modelos de Licitações e Contratos da Consultoria-Geral da União 
Atualização: maio/2023 
Ata de Registro de Preços –  Lei nº 14.133, de 2021. 
Aprovado pela Secretaria de Gestão e Inovação. 
ITEM DESCRIÇÃO DETALHADA MARCA UF QTD PREÇO UNI-
TÁRIO 
PREÇO 
TOTAL 
2 
CONJUNTO PARA REVESTIMENTO EPÓXI. 
TINTA EPÓXI PIGMENTADA COM ALUMÍNIO. 
CONJUNTO COM COMPONENTE A + B 
TOTALIZANDO 20 LITROS 
INTERNATIONAL CJ 79 R$ 699,00 R$ 55.221,00 
3 TINTA PRIME EPOXI POLIAMIDA PRETA FOSCA  
BALDE 20 LITROS.  INTERNATIONAL BU 41 R$ 739,00 R$ 30.299,00 
4 TINTA EPOXI VINILICA MARROM 
AVERMELHADO BALDE DE 20 LITROS INTERNATIONAL BU 54 R$ 889,00 R$ 48.006,00 
5 TINTA ANTIINCRUSTANTE PRETA BALDE DE 20 
LITROS. INTERNATIONAL BU 115 R$ 2.480,00 R$ 285.200,00 
6 PRIMER EPOXI POLIISOCIANATO NA COR 
VERMELHA 15 MICRONS. GALAO COM 3,6L. INTERNATIONAL GL 25 R$ 400,00 R$ 10.000,00 
7 
CONJUNTO PARA REVESTIMENTO DE BASE 
EPÓXI PRIMER COR ALUMÍNIO. CONJUNTO 
COM (COMPONENTE "A" 20L + COMPONENTE 
"B" 0,75 L + COMPONENTE "C" 1 L). 
INTERNATIONAL CJ 37 R$ 989,00 R$ 36.593,00 
8 SOLVENTE TINTA ALQUIDICA TIPO AGUARRAZ 
LATA COM 5 LITROS. INTERNATIONAL LA 66 R$ 130,00 R$ 8580,00 
9 SOLVENTE TINTA EPOXI LATA COM 5 LITROS INTERNATIONAL LA 203 R$ 119,00 R$ 24.157,00 
10 
TINTA EPOXI POLIAMIDA PRETA FOSCA 
MUNSELL N1 ANTIDERRAPANTE. GALÃO COM 
3,6 LITROS. 
INTERNATIONAL GL 23 R$ 749,00 R$ 17.227,00 
11 TINTA PRIMER EPOXI HOLDING NA COR 
VERMELHO BALDE DE 20 LITROS. INTERNATIONAL BU 6 R$ 800,00 R$ 4.800,00 
12 TINTA ALQUIDICA AZUL SEGURANÇA GALÃO 
COM 3,6L INTERNATIONAL GL 13 R$ 135,00 R$ 1.755,00 
13 TINTA ALQUIDICA BRANCA PARA ACABAMENTO 
MUNSELL N9.5 GALÃO COM 3,6L INTERNATIONAL GL 23 R$ 135,00 R$ 3.105,00 
14 TINTA ALQUIDICA CINZA BALDE COM 20L  INTERNATIONAL BU 17 R$ 800,00 R$ 13.600,00 
15 TINTA ACABAMENTO ALQUIDICA MUNSELL 
10Y7/1 COR CINZA SEMIBRILHANTE INTERNATIONAL GL 7 R$ 109,00 R$ 763,00 
16 TINTA ALQUIDICA CINZA ESCURA 
SEMIBRILHANTE GALÃO DE 3,6L  INTERNATIONAL GL 9 R$ 200,00 R$ 1.800,00 
17 TINTA ALQUIDICA PRETA LATA DE 3,6L INTERNATIONAL GL 7 R$ 97,00 R$ 679,00 
18 TINTA ACABAMENTO ALQUIDICA VERMELHA 
SEGURANÇA MUNSELL5R 4/14 GALAO COM 3,6L. INTERNATIONAL GL 12 R$ 139,00 R$ 1.668,00

## Página 3

Continuação da Ata de Registro de Preços nº 71300/2025-444/00, do COMRJ. 
 
________________________________________________________________________ 
Câmara Nacional de Modelos de Licitações e Contratos da Consultoria-Geral da União 
Atualização: maio/2023 
Ata de Registro de Preços –  Lei nº 14.133, de 2021. 
Aprovado pela Secretaria de Gestão e Inovação. 
ITEM DESCRIÇÃO DETALHADA MARCA UF QTD PREÇO UNI-
TÁRIO 
PREÇO 
TOTAL 
19 TINTA BETUMINOSA PRETA BALDE DE 20L. INTERNATIONAL BU 6 R$ 629,00 R$ 3.774,00 
20 TINTA POLIURETANO ACRILICA BALDE DE 20L. INTERNATIONAL BU 15 R$ 899,00 R$ 13.485,00 
Valor Total da Ata: R$591.112,00 
 
2.2. A listagem do cadastro de reserva referente ao presente registro de preços consta como anexo 
a esta Ata. 
 
3. ÓRGÃO(S) GERENCIADOR E PARTICIPANTE(S) 
3.1. O órgão gerenciador será o Centro de Obtenção da Marinha no Rio de Janeiro.  
3.2. Não há órgãos participantes. 
 
4. DA ADESÃO À ATA DE REGISTRO DE PREÇOS 
4.1. Não será admitida a adesão à ata de registro de preços decorrente desta licitação, conforme 
justificativa apresentada nos estudos técnicos preliminares. 
 
Vedação a acréscimo de quantitativos 
4.2. É vedado efetuar acréscimos nos quantitativos fixados na ata de registro de preços. 
 
5. VALIDADE, FORMALIZAÇÃO DA ATA DE REGISTRO DE PREÇOS E CADASTRO RESERVA 
5.1. A validade da Ata de Registro de Preços será de 1 (um) ano, contado a partir do primeiro dia 
útil subsequente à data de divulgação no PNCP, podendo ser prorrogada por igual período, mediante 
a anuência do fornecedor, desde que comprovado o preço vantajoso. 
5.1.1. O contrato decorrente da ata de registro de preços terá sua vigência estabelecida no próprio 
instrumento contratual e observará no momento da contratação e a cada exercício financeiro a 
disponibilidade de créditos orçamentários, bem como a previsão no plano plurianual, quando 
ultrapassar 1 (um) exercício financeiro. 
5.1.2. Na formalização do contrato ou do instrumento substituto deverá haver a indicação da 
disponibilidade dos créditos orçamentários respectivos. 
5.2. A contratação com os fornecedores registrados na ata será formalizada pelo órgão ou pela 
entidade interessada por intermédio de instrumento contratual, emissão de nota de empenho de 
despesa, autorização de compra ou outro instrumento hábil, conforme o art. 95 da Lei nº 14.133, de 
2021. 
5.2.1.  O instrumento contratual de que trata o item 5.2. deverá ser assinado no prazo de validade 
da ata de registro de preços. 
5.3. Os contratos decorrentes do sistema de registro de preços poderão ser alterados, observado 
o art. 124 da Lei nº 14.133, de 2021.

## Página 4

Continuação da Ata de Registro de Preços nº 71300/2025-444/00, do COMRJ. 
 
________________________________________________________________________ 
Câmara Nacional de Modelos de Licitações e Contratos da Consultoria-Geral da União 
Atualização: maio/2023 
Ata de Registro de Preços –  Lei nº 14.133, de 2021. 
Aprovado pela Secretaria de Gestão e Inovação. 
5.4. Após a homologação da licitação ou da contratação direta, deverão ser observadas as 
seguintes condições para formalização da ata de registro de preços: 
5.4.1. Serão registrados na ata os preços e os quantitativos do adjudicatário, devendo ser observada 
a possibilidade de o licitante oferecer ou não proposta em quantitativo inferior ao máximo previsto 
no edital e se obrigar nos limites dela; 
5.4.2. Será incluído na ata, na forma de anexo, o registro dos licitantes ou dos fornecedores que: 
5.4.2.1. Aceitarem cotar os bens, as obras ou os serviços com preços iguais aos do 
adjudicatário, observado a classificação da licitação; e  
5.4.2.2. Mantiverem sua proposta original.  
5.4.3. Será respeitada, nas contratações, a ordem de classificação dos licitantes ou dos fornecedores 
registrados na ata. 
5.5. O registro a que se refere o item 5.4.2 tem por objetivo a formação de cadastro de reserva 
para o caso de impossibilidade de atendimento pelo signatário da ata. 
5.6. Para fins da ordem de classificação, os licitantes ou fornecedores que aceitarem reduzir suas 
propostas para o preço do adjudicatário antecederão aqueles que mantiverem sua proposta original. 
5.7. A habilitação dos licitantes que comporão o cadastro de reserva a que se refere o item 5.4.2.2 
somente será efetuada quando houver necessidade de contratação dos licitantes remanescentes, nas 
seguintes hipóteses: 
5.7.1. Quando o licitante vencedor não assinar a ata de registro de preços, no prazo e nas condições 
estabelecidos no edital; e 
5.7.2. Quando houver o cancelamento do registro do licitante ou do registro de preços nas 
hipóteses previstas no item 9. 
5.8. O preço registrado com indicação dos licitantes e fornecedores será divulgado no PNCP e 
ficará disponibilizado durante a vigência da ata de registro de preços. 
5.9. Após a homologação da licitação ou da contratação direta, o licitante mais bem classificado ou 
o fornecedor, no caso da contratação direta, será convocado para assinar a ata de registro de preços, 
no prazo e nas condições estabelecidos no edital de licitação ou no aviso de contratação direta, sob 
pena de decair o direito, sem prejuízo das sanções previstas na Lei nº 14.133, de 2021. 
5.9.1. O prazo de convocação poderá ser prorrogado 1 (uma) vez, por igual período, mediante 
solicitação do licitante ou fornecedor convocado, desde que apresentada dentro do prazo, 
devidamente justificada, e que a justificativa seja aceita pela Administração. 
5.10. A ata de registro de preços será assinada por meio de assinatura digital e disponibilizada no 
Sistema de Registro de Preços. 
5.11. Quando o convocado não assinar a ata de registro de preços no prazo e nas condições 
estabelecidos no edital ou no aviso de contratação, e observado o disposto no item 5.7, observando 
o item 5.7 e subitens, fica facultado à Administração convocar os licitantes remanescentes do 
cadastro de reserva, na ordem de classificação, para fazê-lo em igual prazo e nas condições propostas 
pelo primeiro classificado. 
5.12. Na hipótese de nenhum dos licitantes que trata o item 5.4.2.1, aceitarem a contratação nos 
termos do item anterior, a Administração, observados o valor estimado e sua eventual atualização 
nos termos do edital, poderão:

## Página 5

Continuação da Ata de Registro de Preços nº 71300/2025-444/00, do COMRJ. 
 
________________________________________________________________________ 
Câmara Nacional de Modelos de Licitações e Contratos da Consultoria-Geral da União 
Atualização: maio/2023 
Ata de Registro de Preços –  Lei nº 14.133, de 2021. 
Aprovado pela Secretaria de Gestão e Inovação. 
5.12.1. Convocar para negociação os demais licitantes ou fornecedores remanescentes cujos preços 
foram registrados sem redução, observada a ordem de classificação, com vistas à obtenção de preço 
melhor, mesmo que acima do preço do adjudicatário; ou 
5.12.2. Adjudicar e firmar o contrato nas condições ofertadas pelos licitantes ou fornecedores 
remanescentes, atendida a ordem classificatória, quando frustrada a negociação de melhor condição. 
5.13. A existência de preços registrados implicará compromisso de fornecimento nas condições 
estabelecidas, mas não obrigará a Administração a contratar, facultada a realização de licitação 
específica para a aquisição pretendida, desde que devidamente justificada. 
 
6. ALTERAÇÃO OU ATUALIZAÇÃO DOS PREÇOS REGISTRADOS 
6.1. Os preços registrados poderão ser alterados ou atualizados em decorrência de eventual 
redução dos preços praticados no mercado ou de fato que eleve o custo dos bens, das obras ou dos 
serviços registrados, nas seguintes situações: 
6.1.1. Em caso de força maior, caso fortuito ou fato do príncipe ou em decorrência de fatos 
imprevisíveis ou previsíveis de consequências incalculáveis, que inviabilizem a execução da ata tal 
como pactuada, nos termos da alínea “d” do inciso II do caput do art. 124 da Lei nº 14.133, de 2021; 
6.1.2. Em caso de criação, alteração ou extinção de quaisquer tributos ou encargos legais ou a 
superveniência de disposições legais, com comprovada repercussão sobre os preços registrados;  
6.1.3. Na hipótese de previsão no edital ou no aviso de contratação direta de cláusula de 
reajustamento ou repactuação sobre os preços registrados, nos termos da Lei nº 14.133, de 2021. 
6.1.3.1. No caso do reajustamento, deverá ser respeitada a contagem da anualidade e o índice 
previsto para a contratação; e 
6.1.3.2. No caso da repactuação, poderá ser a pedido do interessado, conforme critérios definidos 
para a contratação. 
 
7. NEGOCIAÇÃO DE PREÇOS REGISTRADOS 
7.1. Na hipótese de o preço registrado tornar-se superior ao preço praticado no mercado por 
motivo superveniente, o órgão ou entidade gerenciadora convocará o fornecedor para negociar a 
redução do preço registrado. 
7.1.1. Caso não aceite reduzir seu preço aos valores praticados pelo mercado, o fornecedor será 
liberado do compromisso assumido quanto ao item registrado, sem aplicação de penalidades 
administrativas. 
7.1.2. Na hipótese prevista no item anterior, o gerenciador convocará os fornecedores do cadastro 
de reserva, na ordem de classificação, para verificar se aceitam reduzir seus preços aos valores de 
mercado e não convocará os licitantes ou fornecedores que tiveram seu registro cancelado.  
7.1.3. Se não obtiver êxito nas negociações, o órgão ou entidade gerenciadora procederá ao 
cancelamento da ata de registro de preços, adotando as medidas cabíveis para obtenção de 
contratação mais vantajosa. 
7.1.4. Na hipótese de redução do preço registrado, o gerenciador comunicará aos órgãos e às 
entidades que tiverem firmado contratos decorrentes da ata de registro de preços para que avaliem 
a conveniência e a oportunidade de diligenciarem negociação com vistas à alteração contratual, 
observado o disposto no art. 124 da Lei nº 14.133, de 2021.

## Página 6

Continuação da Ata de Registro de Preços nº 71300/2025-444/00, do COMRJ. 
 
________________________________________________________________________ 
Câmara Nacional de Modelos de Licitações e Contratos da Consultoria-Geral da União 
Atualização: maio/2023 
Ata de Registro de Preços –  Lei nº 14.133, de 2021. 
Aprovado pela Secretaria de Gestão e Inovação. 
7.2. Na hipótese de o preço de mercado tornar-se superior ao preço registrado e o fornecedor não 
poder cumprir as obrigações estabelecidas na ata, será facultado ao fornecedor requerer ao 
gerenciador a alteração do preço registrado, mediante comprovação de fato superveniente que 
supostamente o impossibilite de cumprir o compromisso. 
7.2.1. Neste caso, o fornecedor encaminhará, juntamente com o pedido de alteração, a 
documentação comprobatória ou a planilha de custos que demonstre a inviabilidade do preço 
registrado em relação às condições inicialmente pactuadas. 
7.2.2. Não hipótese de não comprovação da existência de fato superveniente que inviabilize o preço 
registrado, o pedido será indeferido pelo órgão ou entidade gerenciadora e o fornecedor deverá 
cumprir as obrigações estabelecidas na ata, sob pena de cancelamento do seu registro, nos termos 
do item 9.1, sem prejuízo das sanções previstas na Lei nº 14.133, de 2021, e na legislação aplicável. 
7.2.3. Na hipótese de cancelamento do registro do fornecedor, nos termos do item anterior, o 
gerenciador convocará os fornecedores do cadastro de reserva, na ordem de classificação, para verificar 
se aceita manter seus preços registrados, observado o disposto no item 5.7. 
7.2.4. Se não obtiver êxito nas negociações, o órgão ou entidade gerenciadora procederá ao 
cancelamento da ata de registro de preços, nos termos do item 9.4, e adotará as medidas cabíveis para a 
obtenção da contratação mais vantajosa. 
7.2.5. Na hipótese de comprovação da majoração do preço de mercado que inviabilize o preço 
registrado, conforme previsto no item 7.2 e no item 7.2.1, o órgão ou entidade gerenciadora atualizará o 
preço registrado, de acordo com a realidade dos valores praticados pelo mercado. 
7.2.6. O órgão ou entidade gerenciadora comunicará aos órgãos e às entidades que tiverem firmado 
contratos decorrentes da ata de registro de preços sobre a efetiva alteração do preço registrado, 
para que avalie a necessidade de alteração contratual, observado o disposto no art. 124 da Lei nº 
14.133, de 2021. 
 
8. REMANEJAMENTO DAS QUANTIDADES REGISTRADAS NA ATA DE REGISTRO DE PREÇOS 
8.1. As quantidades previstas para os itens com preços registrados nas atas de registro de preços 
poderão ser remanejadas pelo órgão ou entidade gerenciadora entre os órgãos ou as entidades 
participantes e não participantes do registro de preços. 
8.2. O remanejamento somente poderá ser feito: 
8.2.1. De órgão ou entidade participante para órgão ou entidade participante; ou 
8.2.2. De órgão ou entidade participante para órgão ou entidade não participante. 
8.3. O órgão ou entidade gerenciadora que tiver estimado as quantidades que pretende contratar 
será considerado participante para efeito do remanejamento. 
8.4. Na hipótese de remanejamento de órgão ou entidade participante para órgão ou entidade não 
participante, serão observados os limites previstos no art. 32 do Decreto nº 11.462, de 2023. 
8.5. Competirá ao órgão ou à entidade gerenciadora autorizar o remanejamento solicitado, com a 
redução do quantitativo inicialmente informado pelo órgão ou pela entidade participante, desde que 
haja prévia anuência do órgão ou da entidade que sofrer redução dos quantitativos informados. 
8.6. Caso o remanejamento seja feito entre órgãos ou entidades dos Estados, do Distrito Federal ou 
de Municípios distintos, caberá ao fornecedor beneficiário da ata de registro de preços, observadas 
as condições nela estabelecidas, optar pela aceitação ou não do fornecimento decorrente do 
remanejamento dos itens.

## Página 7

Continuação da Ata de Registro de Preços nº 71300/2025-444/00, do COMRJ. 
 
________________________________________________________________________ 
Câmara Nacional de Modelos de Licitações e Contratos da Consultoria-Geral da União 
Atualização: maio/2023 
Ata de Registro de Preços –  Lei nº 14.133, de 2021. 
Aprovado pela Secretaria de Gestão e Inovação. 
8.7. Na hipótese da compra centralizada, não havendo indicação pelo órgão ou pela entidade 
gerenciadora, dos quantitativos dos participantes da compra centralizada, nos termos do item 8.3, a 
distribuição das quantidades para a execução descentralizada será por meio do remanejamento. 
 
9. CANCELAMENTO DO REGISTRO DO LICITANTE VENCEDOR E DOS PREÇOS REGISTRADOS 
9.1. O registro do fornecedor será cancelado pelo gerenciador, quando o fornecedor: 
9.1.1. Descumprir as condições da ata de registro de preços, sem motivo justificado; 
9.1.2. Não retirar a nota de empenho, ou instrumento equivalente, no prazo estabelecido pela 
Administração sem justificativa razoável; 
9.1.3. Não aceitar manter seu preço registrado, na hipótese prevista no artigo 27, § 2º, do Decreto 
nº 11.462, de 2023; ou 
9.1.4.  Sofrer sanção prevista nos incisos III ou IV do caput do art. 156 da Lei nº 14.133, de 2021. 
9.1.4.1. Na hipótese de aplicação de sanção prevista nos incisos III ou IV do caput do art. 156 
da Lei nº 14.133, de 2021, caso a penalidade aplicada ao fornecedor não ultrapasse o prazo de 
vigência da ata de registro de preços, poderá o órgão ou a entidade gerenciadora poderá, mediante 
decisão fundamentada, decidir pela manutenção do registro de preços, vedadas contratações 
derivadas da ata enquanto perdurarem os efeitos da sanção. 
9.2. O cancelamento de registros nas hipóteses previstas no item 9.1 será formalizado por despacho 
do órgão ou da entidade gerenciadora, garantidos os princípios do contraditório e da ampla defesa. 
9.3. Na hipótese de cancelamento do registro do fornecedor, o órgão ou a entidade gerenciadora 
poderá convocar os licitantes que compõem o cadastro de reserva, observada a ordem de 
classificação. 
9.4. O cancelamento dos preços registrados poderá ser realizado pelo gerenciador, em determinada 
ata de registro de preços, total ou parcialmente, nas seguintes hipóteses, desde que devidamente 
comprovadas e justificadas: 
9.4.1.  Por razão de interesse público; 
9.4.2.  A pedido do fornecedor, decorrente de caso fortuito ou força maior; ou 
9.4.3. Se não houver êxito nas negociações, nas hipóteses em que o preço de mercado tornar-se 
superior ou inferior ao preço registrado, nos termos dos artigos 26, § 3º e  27, § 4º, ambos do 
Decreto nº 11.462, de 2023.  
 
10. DAS PENALIDADES 
10.1. O descumprimento da Ata de Registro de Preços ensejará aplicação das penalidades 
estabelecidas no edital. 
10.1.1. As sanções também se aplicam aos integrantes do cadastro de reserva no registro de preços que, 
convocados, não honrarem o compromisso assumido injustificadamente após terem assinado a ata.  
10.2. É da competência do gerenciador a aplicação das penalidades decorrentes do descumprimento 
do pactuado nesta ata de registro de preço (art. 7º, inc. XIV, do Decreto nº 11.462, de 2023), exceto 
nas hipóteses em que o descumprimento disser respeito às contratações dos órgãos ou entidade 
participante, caso no qual caberá ao respectivo órgão participante a aplicação da penalidade (art. 8º, 
inc. IX, do Decreto nº 11.462, de 2023).

## Página 8

Continuação da Ata de Registro de Preços nº 71300/2025-444/00, do COMRJ. 
 
________________________________________________________________________ 
Câmara Nacional de Modelos de Licitações e Contratos da Consultoria-Geral da União 
Atualização: maio/2023 
Ata de Registro de Preços –  Lei nº 14.133, de 2021. 
Aprovado pela Secretaria de Gestão e Inovação. 
10.3. O órgão ou entidade participante deverá comunicar ao órgão gerenciador qualquer das 
ocorrências previstas no item 9.1, dada a necessidade de instauração de procedimento para 
cancelamento do registro do fornecedor. 
 
11. CONDIÇÕES GERAIS 
11.1. As condições gerais de execução do objeto, tais como os prazos para entrega e recebimento, as 
obrigações da Administração e do fornecedor registrado, penalidades e demais condições do ajuste, 
encontram-se definidos no Termo de Referência, ANEXO AO EDITAL. 
11.2. No caso de adjudicação por preço global de grupo de itens, só será admitida a contratação de 
parte de itens do grupo se houver prévia pesquisa de mercado e demonstração de sua vantagem 
para o órgão ou a entidade. 
 
 
Para firmeza e validade do pactuado, a presente Ata depois de lida e achada em ordem, vai assinada 
eletronicamente pelas partes e encaminhada cópia aos demais órgãos participantes (se houver).  
 
Rio de Janeiro, na data da assinatura. 
 
 
 
 
 
 
CLAUDIO DE JESUS MONTEIRO DE BARROS ______________________________________ 
Capitão de Fragata (IM) Representante da Contratada 
Ordenador de Despesa  
ASSINADO DIGITALMENTE   
 
 
 
 
 
 
VIRGINIA DA SILVA MACHADO ALBRECHT DA MOTTA TAMIRYS PATROCA DOS SANTOS 
Primeiro-Tenente (RM2-T) Capitão-Tenente (IM) 
Encarregada da Seção de ARP e Contratos Encarregada da Seção de Material Comum 
ASSINADO DIGITALMENTE ASSINADO DIGITALMENTE
