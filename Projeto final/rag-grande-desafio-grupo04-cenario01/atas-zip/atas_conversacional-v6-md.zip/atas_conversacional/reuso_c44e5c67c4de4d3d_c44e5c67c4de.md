# Ata de Registro de Preços nº 00004

Fonte: [PDF original](https://pncp.gov.br/pncp-api/v1/orgaos/26989715000102/compras/2024/002235/atas/000001/arquivos/1)

SHA-256 do PDF: `c44e5c67c4de4d3de2542123ff5822c5e7d9db80627fd37e8c52410a97370156`

Texto extraído automaticamente, organizado por página.

## Página 1

MINISTÉRIO PÚBLICO FEDERAL
PROCURADORIA REGIONAL DA REPÚBLICA DA 2ª REGIÃO
COORDENADORIA DE ADMINISTRAÇÃO
DIVISÃO DE CONTRATAÇÕES E GESTÃO CONTRATUAL
ATA DE REGISTRO DE PREÇOS Nº 04/2024
PROCESSO Nº 1.02.000.000210/2024-53 
V ALIDADE: 12 (DOZE) MESES
Aos  vinte  e  oito  dias  de  novembro  de  2024,  na  PROCURADORIA  REGIONAL  DA  
REPÚBLICA  DA  2ª  REGIÃO ,  inscrita  no  CNPJ  sob  o  nº  26.989.715/0066-58,  Sala  da  
DICONG/PRR2ª, localizada na Av. Almirante Barroso, nº 54, 4º andar, Centro, Rio de Janeiro/RJ,  
telefones  (21)  3554-9100  (PABX/PRR/2ªRegião),  3554-9265  (TEL/DICONG)  e  3554-9295  
(TEL/FAX/DICONG), o Secretário Regional Substituto, nos termos das Leis nº 14.133/21, artigos  
6º, X, e 82 a 86, e Decreto 11.462/2023, e das demais normas legais aplicáveis, conforme a  
classificação das propostas apresentadas no Pregão para Registro de Preços nº 90008/2024 , Ata de 
Julgamento de Preços, homologada pelo Sr. Secretário Regional e publicada no Portal Nacional das  
Contratações  Públicas(PNCP),  RESOLVE  registrar  os  preços  para  aquisição  eventual  de  pisos 
vinílicos, conforme as necessidades desta Procuradoria  Regional da República – 2ª Região,  na 
forma do descrito no Termo de Referência (Anexo I do Edital do Pregão nº 90008/2024) , que passa 
a fazer parte desta, tendo sido referido preço oferecido pela empresa cuja proposta foi classificada  
em primeiro lugar e no certame acima numerado, como segue:
CLÁUSULA PRIMEIRA - DO OBJETO
1.1 Promover Registro de Preços, consignado em Ata, para a aquisição eventual  de pisos  
vinílicos, conforme tabela abaixo:
HOMEDECOR DISTRIBUIDORA EIRELI - EPP
CNPJ: 26.502.166/0001-08
Endereço: SHVP Rua 08, Chácara 219, Lote 5 Bairro Vicente Pires Brasília DF
CEP: 72.007-035
TELEFONE: (61) 3245.3888 – 99658.2530
E-MAIL: engenharia@bigpisos.com.br
Murilo Caetano Alves Lopes– Titular
CPF: 020.***.621-**
1 de 10
PROCURADORIA REGIONAL DA REPÚBLICA – 2ª REGIÃO
Rua Almirante Barroso, nº 54, 4º andar, sala 403, Centro, Rio de Janeiro – RJ Brasil
CEP 20.031-000 Tel. +55(21) 3554-9256
e-mail: prr2-dicong@mpf.mp.br
Assinado digitalmente em 27/11/2024 16:52. Para verificar a autenticidade acesse 
http://www.transparencia.mpf.mp.br/validacaodocumento. Chave AF67DDC8.9B6B8E22.47784CE5.E86AED8F

## Página 2

MINISTÉRIO PÚBLICO FEDERAL
PROCURADORIA REGIONAL DA REPÚBLICA DA 2ª REGIÃO
COORDENADORIA DE ADMINISTRAÇÃO
DIVISÃO DE CONTRATAÇÕES E GESTÃO CONTRATUAL
ITEM OBJETO UNIDADE QUANTIDADE V ALOR UNITÁRIO
 m2 
V ALOR GLOBAL
1
Piso  Vinílico,  Linha  Ambienta  
Coleção  Series,  Cor:  SAPUCAIA –  
Fabricante  TARKETT,
Dimensões da régua: 208x1.230mm -  
Cód. Fáb..: 24176658 - Cx.: 3,58m2 
m2 
2.327
(650 caixas)
R$ 133,85 R$ 311.468,95
V ALOR TOTAL R$ 311.468,95(trezentos e onze mil, quatrocentos e  
sessenta e oito reais e noventa e cinco centavos)
CLÁUSULA SEGUNDA – DA V ALIDADE E DO REAJUSTAMENTO DOS PREÇOS
2.1 A presente Ata de Registro de Preços terá a validade de 12 (doze) meses, a partir da sua  
assinatura, podendo ser prorrogada, nos termos do artigo 84, da Lei 14.133/2021
2.2 Durante a vigência da Ata, os preços registrados serão fixos e irreajustáveis, exceto nas  
hipóteses  decorrentes  e  devidamente  comprovadas  previstas  no  artigo  82,  da  Lei  
14.133/2021 ou de redução dos preços praticados no mercado.
2.3 Mesmo se comprovada a ocorrência da situação prevista na alínea “d” do inciso II do art.  
124 da Lei nº 14.133/21, a Administração, se julgar conveniente, poderá optar por cancelar  
a Ata e iniciar outro processo licitatório.
2.4 Comprovada  a  redução  dos  preços  praticados  no  mercado  nas  mesmas  condições  do 
registro, e, definido o novo preço máximo a ser pago pela Administração, o Proponente  
registrado  será  convocado  pela  CONTRATANTE para  a  devida  alteração  do  valor  
registrado em Ata.
2.5 Durante o prazo de validade desta Ata de Registro de Preços, a CONTRATANTE não será 
obrigada a firmar as contratações que dela poderá advir, facultando-se a realização de  
licitação  específica  para  a  aquisição  pretendida,  sendo  assegurado  ao  beneficiário  do 
registro preferência de fornecimento em igualdade de condições, nos termos do artigo 83  
da Lei 14.133/2021.
2 de 10
PROCURADORIA REGIONAL DA REPÚBLICA – 2ª REGIÃO
Rua Almirante Barroso, nº 54, 4º andar, sala 403, Centro, Rio de Janeiro – RJ Brasil
CEP 20.031-000 Tel. +55(21) 3554-9256
e-mail: prr2-dicong@mpf.mp.br
Assinado digitalmente em 27/11/2024 16:52. Para verificar a autenticidade acesse 
http://www.transparencia.mpf.mp.br/validacaodocumento. Chave AF67DDC8.9B6B8E22.47784CE5.E86AED8F

## Página 3

MINISTÉRIO PÚBLICO FEDERAL
PROCURADORIA REGIONAL DA REPÚBLICA DA 2ª REGIÃO
COORDENADORIA DE ADMINISTRAÇÃO
DIVISÃO DE CONTRATAÇÕES E GESTÃO CONTRATUAL
CLÁUSULA TERCEIRA – DAS PENALIDADES
3.1 O  descumprimento  da  Ata  de  Registro  de  Preços  ensejará  aplicação  das  sanções  
administrativas nos termos dos artigos 155 a 163 da Lei nº 14.133/2021, no que couber.
3.2. As sanções do item acima também se aplicam aos integrantes do cadastro de reserva  
que, quando convocados, não honrarem o compromisso assumido injustificadamente, nos  
termos da Lei 14.133 de 2021;
3.2 Compete ao órgão gerenciador aplicar, garantidos os princípios da ampla defesa e do
contraditório,  as  penalidades  decorrentes  de  infrações  no  procedimento  licitatório  e  
registrá-las no SICAF (Decreto 11.462/2023, Art. 7º, inciso XIII);
3.3 Compete ao órgão gerenciador aplicar, garantidos os princípios da ampla defesa e do
contraditório,  as  penalidades  decorrentes  do  descumprimento  do  pactuado  na  ata  de  
registro  de  preços,  em  relação  à  sua  demanda  registrada,  ou  do  descumprimento  das 
obrigações contratuais, em relação às suas próprias contratações, e registrá-las no SICAF  
(Decreto11.462/2023, Art.7º,inciso XIV);
3.4 Compete ao órgão participante aplicar, garantidos os princípios da ampla defesa e do
contraditório,  as  penalidades  decorrentes  do  descumprimento  do  pactuado  na  ata  de  
registro  de  preços,  em  relação  à  sua  demanda  registrada,  ou  do  descumprimento  das 
obrigações contratuais, em relação às suas próprias contratações, informar as ocorrências  
ao órgão gerenciador e registrá-las no SICAF (Decreto 11.462/2023, Art. 8º, inciso IX). 
3.5 As sanções previstas poderão ser aplicadas cumulativamente com a pena de multa, sem  
prejuízo das responsabilidades civil e criminal.
CLÁUSULA QUARTA – DA UTILIZAÇÃO DA ATA E DOS PREÇOS
4.1 A presente Ata de Registro de Preço poderá ser usada por órgãos usuários, desde que  
autorizados pela  CONTRATANTE, na  pessoa do Sr. Secretário Regional, gerente do  
presente  Registro  de  Preços,  após  consulta  prévia,  respeitadas  as  regras  e  condições 
estabelecidas no Art. 86 da Lei nº 14.133/2021 e Art. 31 do Decreto nº 11.462/2023.
4.2 Em  cada  aquisição  decorrente  desta  Ata,  serão  observadas  as  cláusulas  e  condições  
constantes do Edital do Pregão para Registro de Preços nº 90008/2024  que a precedeu e  
integra o presente instrumento de compromisso.
4.3 Caberá ao fornecedor beneficiário da ata de registro de preços, observadas as condições  
nela estabelecidas, optar pela aceitação ou não do fornecimento decorrente de adesão,  
desde que não prejudique as obrigações presentes e futuras decorrentes desta ata.
3 de 10
PROCURADORIA REGIONAL DA REPÚBLICA – 2ª REGIÃO
Rua Almirante Barroso, nº 54, 4º andar, sala 403, Centro, Rio de Janeiro – RJ Brasil
CEP 20.031-000 Tel. +55(21) 3554-9256
e-mail: prr2-dicong@mpf.mp.br
Assinado digitalmente em 27/11/2024 16:52. Para verificar a autenticidade acesse 
http://www.transparencia.mpf.mp.br/validacaodocumento. Chave AF67DDC8.9B6B8E22.47784CE5.E86AED8F

## Página 4

MINISTÉRIO PÚBLICO FEDERAL
PROCURADORIA REGIONAL DA REPÚBLICA DA 2ª REGIÃO
COORDENADORIA DE ADMINISTRAÇÃO
DIVISÃO DE CONTRATAÇÕES E GESTÃO CONTRATUAL
4.4 As aquisições ou contratações adicionais a que se refere esta cláusula não poderão exceder, 
por órgão ou entidade, a 50% (cinquenta por cento) dos quantitativos dos itens do Edital e  
registrados nesta ata de registro de preços para o órgão gerenciador e órgãos participantes.  
Limitado o quantitativo decorrente das adesões ao dobro previsto nesta ata, de acordo com  
o Art. 32, incisos I e II, do Decreto 11.462/2023
4.5 Após a autorização, o órgão não participante deverá efetivar a aquisição ou contratação  
solicitada em até 90 (noventa) dias, observado o prazo de vigência desta ata.
CLÁUSULA QUINTA – DO PRAZO E DO LOCAL PARA ENTREGA DOS BENS
5.1. O prazo máximo para entrega do material é de 10 (dez) dias úteis, a contar do recebimento  
da requisição formal do CONTRATANTE.
5.1.1 Os itens adjudicados devem ser entregues na Divisão de Infraestrutura e Logística  
-  DILOG  –  2ª  Região,  a  cargo  de  servidor  lotado  no  referido  Setor  da  
CONTRATANTE, situada na Almirante Barroso, nº 54º andar – Centro - Rio de  
Janeiro – RJ, CEP 20.031-000, em datas a serem combinadas em agendamento  
prévio através do telefone (21) 3554-9155, de segunda a sexta-feira, das 12:00 às  
18:00h.
5.1.2 As entregas de materiais deverão ser agendados com o setor responsável, podendo  
ser  adotado  horário  alternativo  que  não  prejudique  o  bom  desempenho  das  
atividades desta Procuradoria, sem que isso onere ou dificulte o serviço.
5.1.3 A entrega do material ocorrerá, independentemente de inspeção ou aprovação pela 
CONTRATANTE,  em  condições  adequadas  para  proteger  o  conteúdo  contra 
danos durante o transporte, sob condições que envolvam embarque, desembarque,  
transporte  por  rodovias  não  pavimentadas,  marítimo  ou  aéreo,  pelo  que  a  
CONTRATADA será  responsável,  sem  ônus  para  a  CONTRATANTE,  pelo 
transporte dos produtos até a sua entrega.
CLÁUSULA SEXTA - DA V ALIDADE DOS BENS FORNECIDOS
6.1 Os materiais fornecidos terão garantia de acordo com as especificações do fabricante e a  
legislação vigente.  No caso de bens com prazo de validade dado pelo fabricante, este  
deverá ter, no ato do recebimento, no mínimo, 90% de seu prazo de vigência,  cujo prazo  
começará  a  viger  a  partir  do  Recebimento  Definitivo,  procedimento  esse  anterior  ao 
pagamento pela CONTRATANTE.
4 de 10
PROCURADORIA REGIONAL DA REPÚBLICA – 2ª REGIÃO
Rua Almirante Barroso, nº 54, 4º andar, sala 403, Centro, Rio de Janeiro – RJ Brasil
CEP 20.031-000 Tel. +55(21) 3554-9256
e-mail: prr2-dicong@mpf.mp.br
Assinado digitalmente em 27/11/2024 16:52. Para verificar a autenticidade acesse 
http://www.transparencia.mpf.mp.br/validacaodocumento. Chave AF67DDC8.9B6B8E22.47784CE5.E86AED8F

## Página 5

MINISTÉRIO PÚBLICO FEDERAL
PROCURADORIA REGIONAL DA REPÚBLICA DA 2ª REGIÃO
COORDENADORIA DE ADMINISTRAÇÃO
DIVISÃO DE CONTRATAÇÕES E GESTÃO CONTRATUAL
CLÁUSULA SÉTIMA - DO PAGAMENTO
7.1 O pagamento será efetuado mediante depósito em conta- corrente da CONTRATADA, por 
meio de ordem bancária, até o 10º (décimo) dia útil, após a declaração formal (recebimento  
definitivo) da aceitação do item adjudicado por parte da CONTRATANTE e mediante a  
apresentação  da  fatura/nota  fiscal  respectiva  pela  CONTRATADA,  devidamente 
discriminada, com a informação dos dados bancários.
7.1.1 Nas  hipóteses  alcançadas  pelo  art.  141,  da  Lei  14.133/2021,  a  ordem  de  
pagamento será emitida em até 5 (cinco) dias úteis, a contar da data de emissão do  
Termo de Recebimento Definitivo, nos moldes dos artigos 40 e 92 do mesmo  
diploma legal.
7.1.2 Será considerada como data do pagamento a data da emissão da Ordem Bancária.
7.1.3 Nos preços ofertados pela CONTRATADA estão inclusos todos os custos diretos  
e indiretos incidentes sobre o objeto da licitação, isentando a CONTRATANTE 
de quaisquer ônus adicionais.
a) Os custos diretos e indiretos necessários ao fornecimento dos materiais  
correrão às custas da CONTRATADA.
7.2 A CONTRATADA deverá emitir a nota fiscal dos materiais fornecidos, conforme preço  
contratado na licitação.
7.2.1 A CONTRATADA deverá  emitir  nota  fiscal  no  valor  total  dos  materiais 
fornecidos, a qual deverá ser apresentada no mínimo 30 (trinta) dias antes do  
vencimento.
7.2.2 A liberação para pagamento da fatura ou nota fiscal ficará condicionada ao atesto  
da unidade gestora da Ata, conforme disposto no artigo 141, da Lei 14.133/2021. 
7.2.3 Caso seja necessária a retificação da nota fiscal por culpa da CONTRATADA, a 
fluência do prazo de 10 (dez) úteis dias será suspensa, reiniciando-se a contagem a 
partir da reapresentação da fatura retificada.
7.2.4 Qualquer  atraso  ocorrido  na  apresentação  da  fatura  ou  nota  fiscal,  ou  dos  
documentos  exigidos  como  condição  para  pagamento  por  parte  da  
CONTRATADA, importará em prorrogação automática do prazo de vencimento  
da obrigação da CONTRATANTE.
5 de 10
PROCURADORIA REGIONAL DA REPÚBLICA – 2ª REGIÃO
Rua Almirante Barroso, nº 54, 4º andar, sala 403, Centro, Rio de Janeiro – RJ Brasil
CEP 20.031-000 Tel. +55(21) 3554-9256
e-mail: prr2-dicong@mpf.mp.br
Assinado digitalmente em 27/11/2024 16:52. Para verificar a autenticidade acesse 
http://www.transparencia.mpf.mp.br/validacaodocumento. Chave AF67DDC8.9B6B8E22.47784CE5.E86AED8F

## Página 6

MINISTÉRIO PÚBLICO FEDERAL
PROCURADORIA REGIONAL DA REPÚBLICA DA 2ª REGIÃO
COORDENADORIA DE ADMINISTRAÇÃO
DIVISÃO DE CONTRATAÇÕES E GESTÃO CONTRATUAL
7.2.5 O atraso no pagamento decorrente das circunstâncias descritas nos itens “7.2.3” e  
“7.2.4” deste  parágrafo  não  autoriza  a  CONTRATADA  a  suspender  o  
fornecimento dos bens.
7.2.6 Na ocasião da entrega da nota fiscal, se for o caso, a  CONTRATADA deverá 
comprovar  a  condição  de  optante  pelo  SIMPLES  (Sistema  Integrado  de  
Pagamento  de  Impostos  e  Contribuições  das  Microempresas  e  Empresas  de  
Pequeno Porte), mediante a apresentação da cópia do Termo de Opção de que trata 
a IN da RFB (Receita Federal do Brasil) n.º 1.234, de 11 de janeiro de 2012, sob  
pena de serem efetuadas as referidas retenções.
7.2.7 As  pessoas  jurídicas  não-optantes  pelo  SIMPLES  e  aquelas  que  ainda  não  
formalizaram  a  opção  deverão  discriminar  os  tributos/contribuições  a  serem  
retidos, conforme Instrução Normativa  da RFB (Receita Federal do Brasil) n.º  
1.234,  de  11  de  janeiro  2012,  e  sofrerão  a  retenção  desses  tributos  por  esta 
Procuradoria Regional da República da 2ª Região, no momento do pagamento,  
conforme disposto no artigo 64, da Lei n.º 9.430, de 27 de dezembro de 1996. A  
retenção incidirá sobre o valor total a ser pago, conforme Tabela de Retenção da  
supracitada Instrução Normativa. Os demais casos que ensejam a não retenção  
deverão ser devidamente comprovados no ato da entrega da nota fiscal ou fatura.
7.2.8 A inexistência do destaque de que trata o  caput deste parágrafo não impede a  
retenção por parte da CONTRATANTE.
7.3 Os valores a serem pagos à CONTRATADA não ultrapassarão o limite previsto nesta Ata, 
sendo considerados, para efeito do pagamento, o fornecimento de bens comprovadamente  
entregues.
7.4 À  CONTRATANTE, reserva-se  o  direito  de  não  efetuar  o  pagamento  se,  no  ato  da 
atestação,  os  materiais  não  estiverem  em  perfeitas  condições  ou  de  acordo  com  as  
especificações apresentadas e aceitas pela CONTRATADA.
7.5 Nenhum pagamento será efetuado à  CONTRATADA enquanto pendente de liquidação  
qualquer obrigação financeira que lhe tenha sido imposta, em virtude de penalidade por  
inadimplemento, até que o total de seus créditos possa compensar seus débitos.
7.5.1 A  CONTRATANTE poderá  deduzir  da  importância  a  pagar  os  valores  
correspondentes  a  multas  ou  indenizações  devidas  pela  CONTRATADA nos  
termos do presente ajuste.
6 de 10
PROCURADORIA REGIONAL DA REPÚBLICA – 2ª REGIÃO
Rua Almirante Barroso, nº 54, 4º andar, sala 403, Centro, Rio de Janeiro – RJ Brasil
CEP 20.031-000 Tel. +55(21) 3554-9256
e-mail: prr2-dicong@mpf.mp.br
Assinado digitalmente em 27/11/2024 16:52. Para verificar a autenticidade acesse 
http://www.transparencia.mpf.mp.br/validacaodocumento. Chave AF67DDC8.9B6B8E22.47784CE5.E86AED8F

## Página 7

MINISTÉRIO PÚBLICO FEDERAL
PROCURADORIA REGIONAL DA REPÚBLICA DA 2ª REGIÃO
COORDENADORIA DE ADMINISTRAÇÃO
DIVISÃO DE CONTRATAÇÕES E GESTÃO CONTRATUAL
7.6 Nos casos em que ocorram eventuais atrasos de pagamento provocados exclusivamente  
pela CONTRATANTE, o valor devido deverá ser acrescido de atualização financeira, e  
sua apuração se fará desde a data de seu vencimento até a data do efetivo pagamento, em  
que os juros de mora serão calculados à taxa de 6% (seis por cento) ao ano, mediante  
aplicação da seguinte fórmula.
a) EM = I x N x VP,  onde:
I = 0,0001643;
TX = Percentual da taxa de juros de mora anual = 6% (seis por cento ao ano);
EM = Encargos moratórios;
N = Número de dias entre a data do vencimento e a do efetivo pagamento;
VP = Valor da parcela em atraso.
7.6.1 Deverá ser considerada como a data do vencimento da nota fiscal ou fatura o 10º  
(décimo) dia útil após a emissão do recebimento definitivo.
7.7 A  CONTRATADA enviará  a  nota  fiscal  exclusiva  e  obrigatoriamente  por  meio  
eletrônico para o e-mail  prr2-protocoloeletronico@mpf.mp.br identificando no topo da  
nota  “Nota Fiscal nº xxx / nome da empresa”  e, além disso, precisará encaminhar os  
anexos de acordo com o art. 23, § 5º da Portaria PGR nº 350/2017, ou seja, formato  
PDF/A, resolução mínima de 200 dpi, com reconhecimento óptico de caracteres (OCR),  
preferencialmente no modo tons de cinza, sob pena do não  reconhecimento do documento 
para fins da ignição do processo eletrônico de pagamento.
CLÁUSULA OITA V A – DAS CONDIÇÕES DE FORNECIMENTO DOS PRODUTOS
8.1 A CONTRATANTE será o órgão responsável pelos atos de controle e administração desta  
Ata  de  Registro  de  Preços  e  indicará,  sempre  que  solicitado  pelos  órgãos  usuários,  
respeitada a ordem de registro e os quantitativos a serem contratados, o fornecedor para o  
qual será emitido o pedido.
8.2 A contratação com o fornecedor registrado será formalizada pelo órgão interessado por  
intermédio de instrumento contratual, emissão de nota de empenho de despesa, autorização  
de serviço ou outro instrumento similar, conforme o disposto nos  artigos 84, parágrafo  
único, 89 a 91 e 95, todos da Lei 14.133/2021, devendo, o for necedor, comparecer ao  
órgão gerenciador sempre que convocado, respeitando o prazo máximo de 2 (dois) dias  
contados da convocação.
7 de 10
PROCURADORIA REGIONAL DA REPÚBLICA – 2ª REGIÃO
Rua Almirante Barroso, nº 54, 4º andar, sala 403, Centro, Rio de Janeiro – RJ Brasil
CEP 20.031-000 Tel. +55(21) 3554-9256
e-mail: prr2-dicong@mpf.mp.br
Assinado digitalmente em 27/11/2024 16:52. Para verificar a autenticidade acesse 
http://www.transparencia.mpf.mp.br/validacaodocumento. Chave AF67DDC8.9B6B8E22.47784CE5.E86AED8F

## Página 8

MINISTÉRIO PÚBLICO FEDERAL
PROCURADORIA REGIONAL DA REPÚBLICA DA 2ª REGIÃO
COORDENADORIA DE ADMINISTRAÇÃO
DIVISÃO DE CONTRATAÇÕES E GESTÃO CONTRATUAL
8.3 A CONTRATANTE poderá optar pelo envio do respectivo instrumento por meio de carta  
registrada, enviada ao endereço do fornecedor, constante em sua proposta.
8.4 A CONTRATADA que não cumprir as obrigações estabelecidas nesta Ata de Registro de  
Preços, estará sujeita às sanções previstas na Cláusula Terceira desta Ata, no Edital que lhe  
deu origem e em seus Anexos.
8.5 Quando comprovada a hipótese do subitem anterior, a CONTRATANTE poderá indicar o 
próximo fornecedor ao qual será destinado o pedido, sem prejuízo da abertura de processo  
administrativo para aplicação de penalidades.
8.6 A CONTRATADA deverá apresentar no momento da entrega do objeto  comprovação da 
origem dos materiais eventualmente importados oferecidos e da quitação dos tributos de  
importação a eles referentes, sob pena de rescisão contratual e multa.
CLÁUSULA NONA - DAS OBRIGAÇÕES DA CONTRATADA
9.1 A  CONTRATADA obriga-se, além de cumprir todos os encargos incidentes direta ou  
indiretamente sobre o objeto contratual e demais obrigações legais e regulamentares,  a  
executar o objeto desta Ata de Registro de Preços em estrita observância às especificações  
exigidas no Edital do Pregão para Registro de Preços nº 90008/2024, e, ainda, às condições 
apresentadas em sua proposta.
9.2 Em caso de divergências entre o estipulado nos documentos acima descritos, prevalecerá o  
disposto no Edital do Pregão para Registro de Preços nº 90008/2024.
9.3 Os  casos  omissos  serão  resolvidos  pela  Coordenadoria  de  Administração  da  
CONTRATANTE.
9.4 Por inexecução total ou parcial das obrigações da CONTRATADA, a CONTRATANTE 
poderá rescindir a Ata na forma dos artigos 137 e 138, da Lei nº 14.133/2021.
CLÁUSULA DÉCIMA - DAS DISPOSIÇÕES FINAIS
10.1 Integram esta Ata, o  Edital do  Pregão para Registro de Preços nº 90008/2024  e seus  
Anexos, e a proposta da sociedade empresária vencedora, classificada em prime iro lugar 
para os itens, no certame supra numerado.
8 de 10
PROCURADORIA REGIONAL DA REPÚBLICA – 2ª REGIÃO
Rua Almirante Barroso, nº 54, 4º andar, sala 403, Centro, Rio de Janeiro – RJ Brasil
CEP 20.031-000 Tel. +55(21) 3554-9256
e-mail: prr2-dicong@mpf.mp.br
Assinado digitalmente em 27/11/2024 16:52. Para verificar a autenticidade acesse 
http://www.transparencia.mpf.mp.br/validacaodocumento. Chave AF67DDC8.9B6B8E22.47784CE5.E86AED8F

## Página 9

MINISTÉRIO PÚBLICO FEDERAL
PROCURADORIA REGIONAL DA REPÚBLICA DA 2ª REGIÃO
COORDENADORIA DE ADMINISTRAÇÃO
DIVISÃO DE CONTRATAÇÕES E GESTÃO CONTRATUAL
10.2 Fica eleito o foro da Seção Judiciária da Justiça Federal da Capital do Estado do Rio de  
Janeiro para dirimir as questões derivadas da presente Ata.
10.3 Os casos omissos serão resolvidos de acordo com a Lei n. o 14.133/2021 e demais normas  
aplicáveis.
Rio de Janeiro, 28 de novembro de 2024.
LEANDRO DO ESPÍRITO SANTO SILV A
Secretário Regional Substituto da PRR/RJ - 2ª Região
Gerente do Registro de Preços
HOMEDECOR DISTRIBUIDORA EIRELI - EPP
CNPJ: 26.502.166/0001-08
MURILO CAETANO ALVES LOPES
CPF: 020.***.621-**
9 de 10
PROCURADORIA REGIONAL DA REPÚBLICA – 2ª REGIÃO
Rua Almirante Barroso, nº 54, 4º andar, sala 403, Centro, Rio de Janeiro – RJ Brasil
CEP 20.031-000 Tel. +55(21) 3554-9256
e-mail: prr2-dicong@mpf.mp.br
Assinado digitalmente em 27/11/2024 16:52. Para verificar a autenticidade acesse 
http://www.transparencia.mpf.mp.br/validacaodocumento. Chave AF67DDC8.9B6B8E22.47784CE5.E86AED8F

## Página 10

MINISTÉRIO PÚBLICO FEDERAL
PROCURADORIA REGIONAL DA REPÚBLICA DA 2ª REGIÃO
COORDENADORIA DE ADMINISTRAÇÃO
DIVISÃO DE CONTRATAÇÕES E GESTÃO CONTRATUAL
TERMO DE AUTORIZAÇÃO E APROV AÇÃO DA ATA DE REGISTRO DE PREÇOS
O PROCURADOR-CHEFE DA PROCURADORIA REGIONAL DA REPÚBLICA 
DA 2ª  REGIÃO ,  no  uso  de  suas  atribuições  legais,  AUTORIZA E  APROV A  esta ATA DE  
REGISTRO  DE  PREÇOS, em  cumprimento  às  disposições  do  Artigo  33,  Inciso  XVII,  do  
Regimento Interno do Ministério Público Federal.
Rio de Janeiro, 28 de novembro de 2024.
LEONARDO CARDOSO DE FREITAS
Procurador-Chefe Regional
10 de 10
PROCURADORIA REGIONAL DA REPÚBLICA – 2ª REGIÃO
Rua Almirante Barroso, nº 54, 4º andar, sala 403, Centro, Rio de Janeiro – RJ Brasil
CEP 20.031-000 Tel. +55(21) 3554-9256
e-mail: prr2-dicong@mpf.mp.br
Assinado digitalmente em 27/11/2024 16:52. Para verificar a autenticidade acesse 
http://www.transparencia.mpf.mp.br/validacaodocumento. Chave AF67DDC8.9B6B8E22.47784CE5.E86AED8F

## Página 11

MINISTÉRIO PÚBLICO FEDERAL
 
Assinatura/Certificação do documento  PRR2ª-00031058/2024 ATA DE REGISTRO DE PREÇO
Signatário(a): MURILO CAETANO ALVES LOPES
Data e Hora: 27/11/2024 16:52:31
Assinado com login e senha
Signatário(a): LEANDRO DO ESPIRITO SANTO SILVA
Data e Hora: 27/11/2024 19:24:22
Assinado com login e senha
Signatário(a): LEONARDO CARDOSO DE FREITAS
Data e Hora: 29/11/2024 15:02:06
Assinado em nuvem
Acesse http://www.transparencia.mpf.mp.br/validacaodocumento. Chave af67ddc8.9b6b8e22.47784ce5.e86aed8f
