# Ata de Registro de Preços nº 00003

Fonte: [PDF original](https://pncp.gov.br/pncp-api/v1/orgaos/32855236000104/compras/2025/000003/atas/000001/arquivos/1)

SHA-256 do PDF: `9ed3278f53fb6ba96c40ccc5d2d437f8407b4d6b002116e25ecf33ad5839f6ce`

Texto extraído automaticamente, organizado por página.

## Página 1

ATA DE REGISTRO DE PREÇOS Nº 003/2025 
ESTADO DO RIO DE JANEIRO, PELA SECRETARIA DE ESTADO DE 
POLÍCIA CIVIL  
 
 
O ESTADO DO RIO DE JANEIRO, pela SECRETARIA DE ESTADO DE 
POLÍCIA CIVIL, com sede na Rua da Relação, nº 42, Centro, na cidade do Rio de 
Janeiro, no Estado do Rio de Janeiro, inscrita no CNPJ sob o nº 32.855.236/0001-04, neste 
ato representada pela Exma. Diretora do Departamento Geral de Contratações e 
Convênios, Ordenadora de Despesas, Jacqueline de Nazareth Sá Diniz, Delegada de 
Polícia, Identidade Funcional nº 0.564.951-0, considerando o resultado da licitação nº 
90004/2025, publicada no DOERJ nº 154, pag. 42, de 26/08/2025 para REGISTRO DE 
PREÇOS, processo administrativo nº SEI-360018/000077/2024, RESOLVE registrar o 
preço da  empresa indicada e qualificada nesta ATA, de acordo com a classificação por 
ela alcançada e na quantidade  cotada, atendendo as condições previstas no edital de 
licitação 90004/2025, sujeitando-se as partes às normas constantes na Lei nº 14.133, de 
1º de abril de 2021, no Decreto n.º 48.843, de 13 de dezembro de 2023, e nos demais 
normativos estaduais aplicáveis, todos disponíveis no endereço eletrônico 
redelog.rj.gov.br/redelog/legislação-licitacoes/, e em conformidade com as disposições a 
seguir: 
 
 
CLÁUSULA PRIMEIRA: OBJETO  
1.1 A presente Ata tem por objeto o registro de preços para a eventual contratação de 
aquisição de espectrômetro digital no formato portátil, especificado no item 2.2 do Termo 
de Referência, que é parte integrante desta Ata, assim como a(s) proposta(s) com preço(s) 
ora registrado(s), independentemente de transcrição. 
 
 
CLÁUSULA SEGUNDA: DA ATA DE REGISTRO DE PREÇOS    
 
2.1 Esta Ata de Registro de Preços é documento vinculativo, de caráter obrigacional, com 
efeito de compromisso de aquisição de espectrômetro digital no formato portátil, para

## Página 2

eventual futura contratação, nos termos definidos no instrumento convocatório, quando 
houver, e no Termo de Referência. 
 
2.2 A contratação com o fornecedor registrado não é obrigatória e será realizada de acordo 
com a necessidade do gerenciador e dos participantes, quando houver, e de acordo com o 
quantitativo indicado na cláusula quinta. 
 
2.3 A Administração poderá realizar licitação ou contratação direta para a aquisição de 
mesmo objeto da presente Ata, desde que devidamente motivada, observado o disposto 
no art. 26, parágrafo único, do Decreto nº 48.843/2023.  
 
2.4 Esta Ata de Registro de Preços, com a indicação do preço registrado e dos 
fornecedores, será divulgada no Portal Nacional de Contratações Públicas – PNCP e no 
Portal de Compras do Estado. 
 
 
CLÁUSULA TERCEIRA: DO FORNECEDOR, DO GERENCIADOR, DOS 
PARTICIPANTES E DAS ATRIBUIÇÕES   
 
3.1 O fornecedor desta Ata de Registro de Preços é a empresa BERKANA DEFENSE 
& SECURITY, LLC. (17.386.569/0001-30), na forma do Anexo I – Consolidação das 
Informações da Ata de Registro de Preços. 
 
3.1.1 O fornecedor registrado deverá manter durante toda a vigência da Ata de Registro 
de Preços a compatibilidade com as obrigações assumidas, assim como todas as 
condições exigidas no instrumento convocatório, quando houver, e no Termo de 
Referência, inclusive as referentes à habilitação e às condições de participação.  
 
3.2 O gerenciador desta Ata de Registro de Preços é a Secretaria de Estado de Polícia 
Civil (SEPOL). 
 
3.2.1 São atribuições do gerenciador: 
 
a) aferir, semestralmente, a compatibilidade dos preços registrados com os efetivamente 
praticados; 
 
b) divulgar os preços registrados e suas atualizações no Portal de Compras do Estado do 
Rio de Janeiro;  
 
c) praticar todos os atos de controle e gerenciamento dos quantitativos das Atas de 
Registro de Preços e de seus saldos, das solicitações de adesão e do remanejamento das 
quantidades;

## Página 3

d) gerenciar a Ata de Registro de Preços, providenciando a indicação, sempre que 
solicitado, dos fornecedores registrados para atendimento às necessidades do órgão ou 
entidade, obedecendo à ordem de classificação do certame e os quantitativos de 
contratação definidos pelos participantes da respectiva ata;  
 
e) deliberar quanto à adesão posterior de órgãos e entidades que não manifestaram 
interesse em participar do registro de preços durante o período de divulgação da Intenção 
de Registro de Preços;  
 
f) convocar os proponentes remanescentes, nas hipóteses autorizadas por esta Ata e pelo 
Decreto nº 48.843/2023, observada a ordem de classificação;  
 
g) conduzir as alterações ou as atualizações dos preços registrados; e 
 
h) promover a correta gestão, fiscalização e execução contratual, nos termos do Capítulo 
VI do Título III da Lei nº 14.133, de 1º de abril de 2021, do disposto no Decreto nº 48.817, 
de 24 de novembro de 2023, no Termo de Referência e no contrato, com relação às suas 
próprias contratações. 
 
3.3 São participantes os órgãos ou entidades da Administração Pública direta, autárquica 
e fundacional do Estado do Rio de Janeiro, conforme relação constante do Anexo III. 
 
3.3.1 São atribuições dos participantes: 
 
 a) auxiliar tecnicamente, por solicitação do gerenciador, as atividades previstas nos 
incisos VIII, IX e XI do caput do art. 6º do Decreto nº 48.843/2023; 
 
b) tomar conhecimento da Ata de Registro de Preços, inclusive de eventuais alterações, 
para o correto cumprimento de suas disposições;  
 
c) prestar informações, quando solicitadas, ao gerenciador quanto à contratação e à 
execução da demanda destinada ao seu órgão ou entidade;  
 
d) informar ao gerenciador a eventual recusa do contratado em atender às condições 
estabelecidas no instrumento convocatório, quando houver, e no Termo de Referência, 
firmadas na Ata de Registro de Preços, bem como as divergências relativas à entrega, 
características e origem dos bens adjudicados; e  
 
e) promover a correta gestão, fiscalização e execução contratual, nos termos do Capítulo 
VI do Título III da Lei nº 14.133/2021, e o disposto no Decreto nº 48.817/2023, no Termo 
de Referência e no contrato, com relação às suas próprias contratações.

## Página 4

CLÁUSULA QUARTA: DOS NÃO-PARTICIPANTES 
 
4.1 A Ata de Registro de Preços poderá ser aderida por qualquer órgão ou entidade do 
Estado, que não tenha participado do certame, ora denominados não-participantes.   
 
4.2 Podem também ser considerados não-participantes os órgãos ou entidades municipais, 
distritais, de outros estados e federais, resguardadas as disposições de cada ente.  
 
4.3 Os não-participantes poderão aderir a esta Ata de Registro de Preços, desde que 
observados os seguintes requisitos, cumulativamente: 
 
4.3.1 apresentação de justificativa da vantagem da adesão, inclusive em situações de 
provável desabastecimento ou descontinuidade de serviço público;  
 
4.3.2 apresentação de estudo que demonstre eficiência, viabilidade e economicidade para 
a Administração contratante;  
 
4.3.3 demonstração de que os valores registrados estão compatíveis com os valores 
praticados pelo mercado, na forma do art. 23 da Lei nº 14.133/2021; e  
 
4.3.4 prévia consulta e aceitação do gerenciador e do fornecedor. 
 
4.4 O fornecedor poderá optar pela aceitação ou não do fornecimento decorrente da 
adesão, desde que não prejudique as obrigações presentes e futuras derivadas da Ata, 
assumidas com o gerenciador e os participantes, quando houver. 
 
4.5 Após a autorização do gerenciador, o não-participante deverá efetivar a contratação 
solicitada em até 90 (noventa) dias, observado o prazo de vigência da Ata.  
 
4.5.1 O prazo acima poderá ser prorrogado, excepcionalmente, mediante justificativa e 
autorização pelo gerenciador, e requerimento do não-participante, respeitado o prazo de 
vigência da Ata de Registro de Preços. 
 
4.6 São atribuições dos não-participantes: 
 
a) aceitar todas as condições fixadas na Ata de Registro de Preços; 
 
b) tomar conhecimento da Ata de Registro de Preços, inclusive de eventuais alterações, 
para o correto cumprimento de suas disposições;

## Página 5

c) prestar informações, quando solicitadas, ao gerenciador quanto à contratação e à 
execução da demanda destinada ao seu órgão ou entidade;  
 
d) informar ao gerenciador a eventual recusa do contratado em atender às condições 
estabelecidas no instrumento convocatório, quando houver, e no Termo de Referência, 
firmadas na Ata de Registro de Preços, bem como as divergências relativas à entrega, 
características e origem dos bens adjudicados; e  
 
e) promover a correta gestão, fiscalização e execução contratual, nos termos do Capítulo 
VI do Título III da Lei nº 14.133/2021, e o disposto no Decreto nº 48.817/2023, no Termo 
de Referência e no contrato, com relação às suas próprias contratações. 
 
 
CLÁUSULA QUINTA: DO QUANTITATIVO  
 
5.1 As quantidades estimadas para a contratação, conforme descrição no Termo de 
Referência e reunidas no Anexo I – Consolidação das Informações da Ata de Registro de 
Preços, são as seguintes:  
 
a) previsão de contratação pelo gerenciador e pelos participantes, quando houver: 
 
ITEM DESCRIÇÃO/ESPECIFICAÇÃO CÓD. DO 
ITEM 
UNIDADE 
DE 
MEDIDA 
QUANT. 
TOTAL 
ESTIMADA 
QUANT. 
ESTIMADA 
POR ÓRGÃO 
1 
ESPECTROMETRO 
PORTATIL,RESOLUCAO 
DETECTOR: 8 - 11 CM -1, 
TEMPERATURA AMBIENTE: 15 A 
30ºC, TEMPO EDICAO: 5MS A 30 
SEGUNDOS, POTENCIA: 30 - 490 
MW, ACOMPANHA: N/A, FORMA 
FORNECIMENTO: UNIDADE 
SIGA 176471 
CATMAT 
475.550 
UN 04 
SEPOL - 02 
Fundo Estadual de 
Segurança Pública 
de Roraima - 02 
 
 
b) previsão de contratação pelos não-participantes: 
 
ITEM DESCRIÇÃO/ESPECIFICAÇÃO CÓD. DO 
ITEM 
UNIDADE 
DE 
MEDIDA 
QUANT. 
TOTAL 
ESTIMADA 
QUANT. 
ESTIMADA 
POR 
ÓRGÃO 
QUANT. 
MÁXIMA 
ÓRGÃOS 
ADERENTES 
1 
ESPECTROMETRO 
PORTATIL,RESOLUCAO 
DETECTOR: 8 - 11 CM -1, 
TEMPERATURA AMBIENTE: 15 
A 30ºC, TEMPO EDICAO: 5MS A 
30 SEGUNDOS, POTENCIA: 30 - 
490 MW, ACOMPANHA: N/A, 
FORMA FORNECIMENTO: 
UNIDADE 
SIGA 
176471 
CATMAT 
475.550 
UN 04 
SEPOL - 02 
Fundo Estadual 
de Segurança 
Pública de 
Roraima - 02 
08

## Página 6

5.2 As quantidades dos itens indicadas nas alíneas a e b do item 5.1 são meramente 
estimativas e não implicam obrigatoriedade de contratação pelo gerenciador e pelos 
participantes, quando houver, durante a vigência da Ata de Registro de Preços. 
 
5.3 As contratações adicionais de que trata o item 4 não poderão exceder, por órgão ou 
entidade aderente, a 50% (cinquenta por cento) dos quantitativos dos itens registrados na 
Ata de Registro de Preços para o gerenciador e para os participantes, quando houver.  
 
5.3.1 O quantitativo decorrente das adesões à Ata de Registro de Preços não poderá 
exceder, na totalidade, ao dobro do quantitativo de cada item registrado nesta Ata para o 
gerenciador e pelos participantes, quando houver, independentemente do número de 
órgãos ou entidades não-participantes que aderirem. 
 
5.4 É vedado efetuar acréscimos nos quantitativos fixados na Ata de Registro de Preços, 
inclusive o acréscimo de que trata o art. 125 da Lei nº 14.133/2021. 
 
5.5 As quantidades previstas na Ata de Registro de Preços para os itens com preços 
registrados poderão ser remanejadas, pelo gerenciador, entre os participantes do 
procedimento para registro de preços, quando houver.  
 
5.5.1 Caberá ao gerenciador autorizar o remanejamento, com a transferência dos 
quantitativos entre os participantes, desde que haja anuência daquele que vier a sofrer a 
redução dos quantitativos informados.  
 
 
CLÁUSULA SEXTA: DO PREÇO REGISTRADO 
 
6.1 O preço unitário de cada item registrado é o constante da(s) proposta(s) final(is), cujos 
valores estão reunidos no Anexo I – Consolidação das Informações da Ata de Registro de 
Preços.  
 
6.2 Os preços registrados poderão ser revistos e alterados em decorrência de eventual 
redução dos preços praticados no mercado ou de fato que eleve o custo dos bens, obras 
ou serviços registrados, em caso de força maior, caso fortuito ou fato do príncipe ou em 
decorrência de fatos imprevisíveis ou previsíveis de consequências incalculáveis, que 
inviabilizem a execução da ata tal como pactuado, nos termos da alínea d do inciso II do 
caput do art. 124 da Lei nº 14.133/2021. 
 
6.3 Quando o preço registrado se tornar superior ao preço praticado no mercado por 
motivo superveniente, o gerenciador convocará o(s) fornecedor(es) para negociar a 
redução dos preços aos valores praticados pelo mercado, na ordem de classificação.

## Página 7

6.3.1 Caso o(s) fornecedor(es) cadastrado(s) para o item ou lote não aceite(m) reduzir seu 
preço ao valor praticado pelo mercado deverá(ão) ser liberado(s) do compromisso 
assumido, sem aplicação de penalidades administrativas.   
 
6.3.2 Havendo a liberação do(s) fornecedor(es), nos termos do item 6.3.1, o órgão 
gerenciador deverá convocar os proponentes do Cadastro de Reserva, na ordem de 
classificação, para verificar se aceitam reduzir seus preços aos valores de mercado, 
observado o disposto no art. 19, § 3º, do Decreto nº 48.843/2023.  
 
6.3.3 A ordem de classificação dos fornecedores que aceitarem reduzir seus preços aos 
valores de mercado observará a classificação original.  
 
6.3.4 Não havendo êxito nas negociações, o gerenciador deverá proceder ao cancelamento 
da Ata de Registro de Preços, nos termos do art. 32 do Decreto nº 48.843/2023 e da 
cláusula décima desta Ata, com a adoção das medidas cabíveis para obtenção da 
contratação mais vantajosa.  
 
6.3.5 Caso haja a redução do preço registrado, o gerenciador deverá comunicar aos órgãos 
e as entidades que tiverem formalizado contratos, para que avaliem a necessidade de 
efetuar a revisão dos preços contratados. 
 
6.4 Quando o preço de mercado se tornar superior aos preços registrados e o fornecedor, 
mediante requerimento devidamente fundamentado, não puder cumprir as obrigações 
contidas na Ata de Registro de Preços, ser-lhe-á facultado requerer ao gerenciador a  
alteração dos preços registrados, mediante comprovação de fato superveniente que 
supostamente o impossibilite de cumprir o compromisso.  
 
6.4.1 O fornecedor deverá encaminhar, juntamente com o pedido de alteração, 
documentação comprobatória ou planilha de custos que demonstre que o preço registrado 
se tornou inviável frente às condições inicialmente pactuadas, cabendo ao gerenciador a 
análise e deliberação a respeito do pedido. 
 
6.4.2 Na hipótese de deferimento do pedido, o gerenciador procederá à atualização do 
preço registrado, de acordo com a realidade dos valores praticados pelo mercado.  
 
6.4.3 O fornecedor do compromisso assumido poderá ser liberado pelo gerenciador, caso 
a comunicação ocorra antes do pedido de fornecimento, e sem aplicação de penalidades 
administrativas, se confirmada a veracidade dos motivos e comprovantes apresentados. 
 
6.4.4 Caso não demonstrada a existência de fato superveniente que torne insubsistente o 
preço registrado, o pedido será indeferido pelo gerenciador, ficando o fornecedor 
obrigado a cumprir as obrigações contidas na Ata de Registro de Preços, sob pena de

## Página 8

cancelamento do seu registro, nos termos do art. 31 do Decreto nº 48.843/2023, sem 
prejuízo das sanções previstas na Lei nº 14.133/2021, no instrumento convocatório, 
quando houver, e no Termo de Referência, e em outras legislações aplicáveis. 
 
6.4.4.1 Havendo cancelamento do registro do fornecedor, nos termos do item 6.4.4, o 
gerenciador deverá convocar os proponentes do Cadastro de Reserva, observada a ordem 
de classificação, para verificar se aceitam manter seus preços registrados, observado o 
disposto no art. 19, § 3º, do Decreto nº 48.843/2023.  
 
6.4.4.2 Não havendo êxito nas negociações, o gerenciador deverá proceder ao 
cancelamento da Ata de Registro de Preços, adotando as medidas cabíveis para obtenção 
da contratação mais vantajosa.  
 
6.5 Os novos valores a serem registrados, conforme itens 6.3.5 e 6.4.2, deverão ser 
formalizados mediante termo aditivo à Ata de Registro de Preços.  
 
6.6 Os preços registrados poderão, ainda, ser reajustados ou repactuados, conforme 
estabelecido no instrumento convocatório, quando houver, e no Termo de Referência, nos 
termos da Lei nº 14.133/ 2021. 
 
6.6.1 O reajustamento ou repactuação poderá ser efetuado mediante apostilamento. 
 
 
CLÁUSULA SÉTIMA: DOS LOCAIS DE PRESTAÇÃO DOS SERVIÇOS 
 
7.1 Os locais de entrega dos bens objeto do registro de preços estão listados no Termo de 
Referência. 
 
 
CLÁUSULA OITAVA: DO PRAZO DE VALIDADE DA ATA DE REGISTRO DE 
PREÇOS 
 
8.1 O prazo de validade da Ata de Registro de Preços é de 1 (um) ano, contado a partir 
do 1º (primeiro) dia útil subsequente à data de divulgação no PNCP.  
 
8.2 O prazo de vigência da Ata de Registro de Preços poderá ser prorrogado, por igual 
período, mediante termo aditivo, desde que as condições e os preços permaneçam 
vantajosos, observados os seguintes requisitos: 
 
8.2.1 somente o saldo remanescente será mantido;  
 
8.2.2 deverá ser indicado expressamente o prazo de prorrogação; e

## Página 9

8.2.3 deverá ser confirmado se os preços registrados permanecem atualizados, por meio 
de pesquisa de preços realizada na forma do Decreto nº 48.816, de 24 de novembro de 
2023. 
 
 
CLÁUSULA NONA: DO CADASTRO DE RESERVA 
 
9.1 Fazem parte do Cadastro de Reserva os proponentes que aceitaram cotar os bens ou 
serviços em preços iguais aos do proponente vencedor do certame, observada a ordem de 
classificação, e os proponentes que mantiveram sua proposta original, conforme 
informações reunidas no Anexo II – Cadastro de Reserva.  
 
9.2 A ordem de classificação dos registrados na ata deverá ser respeitada para as 
contratações, cabendo ao gerenciador realizar os devidos registros na Ata de Registro de 
Preços, para a sua atualização. 
 
9.3 A habilitação dos proponentes que irão compor o Cadastro de Reserva somente será 
efetuada quando houver necessidade de contratação dos proponentes remanescentes, na 
forma do parágrafo 3º do art. 19 do Decreto nº 48.843/2023. 
 
9.4 É facultado à Administração, quando o convocado não assinar a Ata de Registro de 
Preços no prazo e condições estabelecidos no instrumento convocatório, quando houver, 
e no Termo de Referência, convocar os proponentes do Cadastro de Reserva, na ordem 
de classificação, para fazê-lo em igual prazo e nas mesmas condições propostas pelo 
primeiro classificado.  
 
9.5 O Cadastro de Reserva poderá ser empregado no caso de exclusão do fornecedor da 
Ata de Registro de Preços, nas seguintes ocorrências:  
  
a) cancelamento do registro do fornecedor, nas hipóteses previstas na cláusula décima; 
ou  
 
b) cancelamento do registro de preços, nas hipóteses previstas nos arts. 28, § 4º, 29 e 31, 
do Decreto nº 48.843/2023, e itens 6.3.4 e 6.4 da cláusula sexta. 
 
 
CLÁUSULA DÉCIMA: DO CANCELAMENTO DO REGISTRO DO 
FORNECEDOR  
 
10.1 O registro do fornecedor será cancelado quando:

## Página 10

a) forem descumpridas as condições da ata de registro de preços, sem motivo justificado; 
 
b) não assinar o contrato ou não retirar a nota de empenho ou instrumento equivalente no 
prazo estabelecido pela Administração, sem justificativa aceitável; 
 
c) não aceitar reduzir o seu preço registrado, na hipótese deste se tornar superior àqueles 
praticados no mercado; ou 
 
d) sofrer sanção prevista nos incisos III ou IV do caput do art. 156 da Lei nº 14.133/2021, 
observado os parágrafos 4º e 5º do referido dispositivo.  
 
10.2 Na hipótese de que trata a alínea d do item 10.1, caso a penalidade aplicada ao 
fornecedor não ultrapasse o prazo de vigência da ata, poderá o gerenciador, desde que 
não seja o responsável pela aplicação da sanção, mediante decisão fundamentada, 
garantido o contraditório e a ampla defesa, decidir pela manutenção do registro de preços.  
 
10.3 O cancelamento do registro nas hipóteses previstas das alíneas a, b e d do item 10.1 
será formalizado por decisão do gerenciador, assegurado o contraditório e a ampla defesa 
ao fornecedor. 
 
 
CLÁUSULA DÉCIMA PRIMEIRA: DO CANCELAMENTO DO REGISTRO DE 
PREÇOS:  
 
11.1 O cancelamento do registro de preços poderá ocorrer, total ou parcialmente, pelo 
gerenciador, desde que devidamente comprovados e justificados:  
 
a)  por razão de interesse público;  
 
b) pelo cancelamento de todos os preços registrados; ou  
 
c) a pedido do fornecedor, decorrente de fato superveniente, de caso fortuito ou força 
maior, que prejudique o cumprimento da Ata. 
 
 
CLÁUSULA DÉCIMA SEGUNDA: DOS CONTRATOS DECORRENTES DA 
ATA DE REGISTRO DE PREÇOS  
 
12.1 As condições gerais de execução do objeto, tais como os prazos para entrega e 
recebimento, as obrigações da Administração e do fornecedor registrado, penalidades e 
demais condições do ajuste, inclusive, o prazo de vigência dos contratos a serem

## Página 11

celebrados, a garantia, o pagamento, o reajuste ou repactuação, encontram-se definidos 
no instrumento convocatório, quando houver, no Termo de Referência e no contrato. 
 
12.1.1 Os contratos decorrentes de registro de preços poderão ser alterados, observado o 
disposto no art. 124 da Lei nº 14.133/2021. 
 
12.2 A contratação realizada pelo gerenciador e pelos participantes será formalizada, 
dentro do prazo de validade da Ata de Registro de Preços, por intermédio de instrumento 
contratual (Anexo VIII do Edital – Minuta de Contrato). 
 
CLÁUSULA DÉCIMA TERCEIRA: DAS INFRAÇÕES ADMINISTRATIVAS E 
SANÇÕES 
 
13.1 O descumprimento da Ata de Registro de Preços ensejará a aplicação das 
penalidades estabelecidas no instrumento convocatório, quando houver, e no Termo de 
Referência. 
 
13.2 Compete ao gerenciador aplicar, garantida a ampla defesa e o contraditório, as 
penalidades decorrentes do descumprimento do pactuado na Ata de Registro de Preços 
ou do descumprimento das obrigações contratuais, em relação às suas próprias 
contratações, e promover as publicações, encaminhamentos e registros cabíveis. 
 
13.3 Compete aos participantes e aos não-participantes aplicar, garantida a ampla defesa 
e o contraditório, as penalidades decorrentes do descumprimento das obrigações 
contratuais, em relação às suas próprias contratações, e promover as publicações, 
encaminhamentos e registros cabíveis. 
 
13.5 A aplicação das penalidades deverá observar o procedimento estabelecido no 
instrumento convocatório e contrato, quando houver, e no Termo de Referência. 
 
 
CLÁUSULA DÉCIMA QUARTA: DOS RECURSOS ORÇAMENTÁRIOS 
 
14.1 Os recursos necessários para as contratações decorrentes desta Ata de Registro de 
Preços correrão por conta da Natureza da Despesa e do Programa de Trabalho próprios 
do gerenciador, dos participantes e dos não-participantes.

## Página 12

CLÁUSULA DÉCIMA QUINTA: DO FORO DE ELEIÇÃO 
 
15.1 Fica eleito o Foro Central da Comarca da Capital do Rio de Janeiro para dirimir 
qualquer litígio decorrente da presente Ata de Registro de Preços que não possa ser 
resolvido por meio amigável, com expressa renúncia a qualquer outro, por mais 
privilegiado que seja.  
 
Para firmeza e validade do pactuado, a presente Ata foi lavrada em 02 (duas) vias de igual 
teor, que, depois de lida e achada em ordem, vai assinada pelas partes e encaminhada 
cópia aos demais órgãos participantes.  
 
 
 
 
 
Rio de Janeiro, ____ de __________ de 2025. 
 
 
 
___________________________________________ 
SECETARIA DE ESTADO DE POLICIA CIVIL 
Jacqueline de Nazareth Sá Diniz 
 
 
___________________________________________ 
BERKANA DEFENSE & SECURITY, LLC. 
Milton Donizeti Heineke Teixeira 
 
 
 
TESTEMUNHAS: 
 
1 - ____________________________ 
 
2 - ____________________________  
 
 
Anexos:  
Anexo I – Consolidação das Informações da Ata de Registro de Preços 
Anexo II – Cadastro de Reserva (suprimido por falta de empresas interessadas). 
Anexo III – Relação de órgãos/entidades participantes.

## Página 13

Anexo I – Consolidação das Informações da Ata de Registro de Preços 
 
ATA DE REGISTRO DE PREÇOS nº 003/2025 
ÓRGÃO GERENCIADOR: SEPOL/RJ. 
OBJETO: ESPECTRÔMETRO DIGITAL PORTÁTIL 
FORNECEDOR: BERKANA DEFENSE & SECURITY, LLC. (17.386.569/0001-30) 
 
 
ITEM 
 
CÓD. 
ID SIGA 
DESCRIÇÃO/ 
ESPECIFICAÇÃO 
QUANTIDADE 
TOTAL 
REGISTRADA 
 
UNIDADE DE 
MEDIDA 
 
 
PREÇO 
UNITÁRIO 
 
  1 COD. SIGA 
176471 
 
CATMAT 
475.550 
ESPECTROMETRO 
PORTATIL RAMAN, 
Fabricante: 3DX-RAY 
Modelo: 3DX-ARX 
Origem: Inglaterra  
 
NCM: 9027.30.19 
              04                UN R$  361.650,91 
 
 
 
Anexo III – Relação de órgãos/entidades participantes 
 
 
ÓRGÃO LOCAL DE ENTREGA 
SECRETARIA DE ESTADO DE POLÍCIA 
CIVIL 
Avenida Dom Hélder Câmara, nº 2.066, 
Maria da Graça, Rio de Janeiro, RJ, CEP 
21.050-452 
Telefones (21) 2202-0531/ 2582-7519 / 
2582-7540 
FUNDO ESTADUAL DE SEGURANÇA 
PÚBLICA DO ESTADO DE RORAIMA 
Endereço: Av. Via das Flores, nº 1696 - 
Pricumã, Boa Vista - RR, 69309-366 
CNPJ: 35.634.306/0001-84 
Setor Responsável: FESP 
Telefone 095 98111-8226 
E-mail: executiva.fesp@sesp.rr.gov.br
