# Ata de Registro de Preços nº 00059

Fonte: [PDF original](https://pncp.gov.br/pncp-api/v1/orgaos/05424540000116/compras/2025/000005/atas/000001/arquivos/1)

SHA-256 do PDF: `ead34c1a28fe27cceb347e74614b4b48e0429411eb8d725b5564ba5738871d90`

Texto extraído automaticamente, organizado por página.

## Página 1

SEÇÃO JUDICIÁRIA DO RIO DE JANEIRO
ATA DE REGISTRO DE PREÇOS SJRJ 1112133  
PROCESSO 0017538-78.2025.4.02.8001
      
ATA DE REGISTRO DE PREÇOS Nº 059/2025
 
A 
JUSTIÇA FEDERAL DE 1º GRAU NO RIO DE JANEIRO
, com sede na Av. Almirante Barroso, 78 -
13° andar, Centro, Rio de Janeiro/RJ, inscrita no CNPJ nº 
05.424.540/0001-16
, neste ato representada pelo Juiz
Federal Diretor do Foro, na forma da legislação, doravante denominada 
JUSTIÇA FEDERAL
, 
resolve
, 
em face das
propostas apresentadas no 
Pregão nº 90028/2025
, registrar o preço da empresa abaixo identificada, classificada
em primeiro lugar para o objeto da licitação, doravante denominada 
FORNECEDOR
, 
em conformidade com o
disposto na Lei nº 14.133/2021 e suas alterações, 
Decreto nº 3.555/00, Decreto nº 10.024/19,
 
Lei Complementar nº
123/06
, alterada pela Lei Complementar nº 147/14, Lei nº 12.846/13 e 
Decreto nº 11.462/23
 mediante as cláusulas
e condições a seguir:
 
 
FORNECEDOR: 
MBS SOLUÇOES INTEGRADAS LTDA, 
estabelecida na 
Av. Perimetral Doutor Juscelino
Kubitschek de Oliveira, s/n – 1.119 – casa 3 - Doutor Laureano – Duque de Caxias/RJ
, 
CEP: 25060-200, TEL: (21)
3437-0865 / (21) 96824-6722 / (21) 96949-1634 / (21) 96949-1925, E-mail: 
mbssolucoesintegradas@gmail.com
,
CNPJ nº 
43.619.143/0001-99
, representada neste ato pelo Sr
. 
BRUNO SILVA DOS PASSOS.
 
 
CLÁUSULA PRIMEIRA - DO OBJETO:
 
1.1 – Registro de Preço para eventual fornecimento e instalação de 
cerca concertina
, 
conforme especificado no
Termo de Referência do Edital do Pregão
 
acima referenciado
, 
que integra a presente Ata.
 
CLÁUSULA SEGUNDA - DA VIGÊNCIA:
 
2.1 - O prazo de vigência da ata de registro de preços será de um ano, contado do primeiro dia útil subsequente
à data de divulgação no PNCP e poderá ser prorrogado por igual período no quantitativo inicialmente registrado,
desde que comprovado que o preço é vantajoso, de acordo com o art. 22 do Decreto nº 11.462/23.
 
CLÁUSULA TERCEIRA - DO PREÇO E DO QUANTITATIVO:
 
ITEM
SERVIÇO A SER EXECUTADO CONFORME
ESPECIFICAÇÃO
QUANT.
PREÇO UNITÁRIO (R$)
1
Concertina dupla clipada em aço galvanizado - metro
600
29,58
 
CLÁUSULA QUARTA – DO FORNECIMENTO E DA EXECUÇÃO:
 
4.1 -
 
A solicitação dos serviços
 
será feita 
de acordo com as necessidades e conveniências da Justiça Federal,
mediante a emissão da Nota de Empenho.
 
4.2 - O prazo de entrega do material e do início da execução do serviço será de 
até 
20
 (
vinte
)
 dias, 
contados a
partir do 1º dia útil seguinte do recebimento da Ordem de Serviço,
 que será encaminhada em até 
10 (dez
) dias
 a
contar do recebimento da Nota de Empenho.
 
Ata de Registro de Preço (ARP) - SJRJ 59 MBS SOLUÇÕES (1112133)         SEI 0017538-78.2025.4.02.8001 / pg. 1

## Página 2

4.3 - 
O prazo de entrega do material e do início da execução do serviço 
poderá ser prorrogado, mediante
justificativa fundamentada, a critério e análise da 
JUSTIÇA FEDERAL
.
 
4.4 - 
Os serviços poderão ser 
efetuado
 nas localidades relacionadas no item 
5.2
 do Termo de Referência
, sendo
especificado na Nota de Empeno e na 
Ordem de Serviço
 a Unidade em que serão 
prestados
.
 
4.5 - 
O prazo de garantia dos serviços será de 
1
 (um) 
ano
, contado do recebimento definitivo, observado o
disposto no item
 
5.3
 do Termo de Referência.
 
CLÁUSULA 
QUINTA
 – DO RECEBIMENTO:
 
5.1 - Provisoriamente, no prazo de 
5 (cinco)
 dias 
úteis
 a contar da apresentação da Nota Fiscal correspondente
aos serviços prestados, conforme itens 
7.4
 e 
7.5
 do Termo de Referência.
 
5.2 - Definitivamente, por servidor ou comissão, após verificada a conformidade das exigências conforme as
especificações constantes no Termo de Referência, no prazo de até 
05 (cinco
) dias 
úteis
 a contar do recebimento
provisório, observadas as condições estabelecidas no item 
7.6
 do Termo de Referência.
 
CLÁUSULA
 SEXTA
 
– DO PAGAMENTO:
 
6.1 - 
O pagamento ao Fornecedor será efetivado por crédito em conta corrente, mediante ordem bancária, cuja
data de emissão será considerada como data do pagamento, em até 30 (trinta) dias após o recebimento definitivo,
sendo efetuada a retenção na fonte dos tributos e contribuições elencados nas disposições dos órgãos fiscais e
fazendários, em conformidade com a legislação e instruções normativas vigentes;
 
6.2 – Ficam determinadas as demais condições dispostas no item 
14
 do Edital do Pregão mencionado no
preâmbulo.
 
CLÁUSULA SÉTIMA - 
DA ADESÃO:
 
7.1 - Durante a vigência da ata, 
incluída a prorrogação, os ÓRGÃOS DO PODER JUDICIÁRIO FEDERAL 
que
não participaram do procedimento de registro de preços, poderão aderir à ata de registro de preços na condição de
não participantes, observadas as condições estabelecidas 
no item 
12
 do Edital do Pregão, mencionado no
preâmbulo.
 
CLÁUSULA OITAVA - DA ATUALIZAÇÃO DE PREÇOS:
 
8.1 - Em caso de pedido de material, cujo preço registrado tiver ultrapassado o prazo de 
6 (seis) meses da
última pesquisa ou atualização de preços, será efetuada pesquisa, visando à atualização dos valores registrados,
nos termos dos incisos IV e V, do § 5º, do artigo 82, 
da Lei nº 14.133/2021;
 
8.2 - Havendo
 redução dos preços praticados no mercado, 
comprovada por meio de pesquisa de preços a ser
realizada pela JUSTIÇA FEDERAL, 
o preço registrado poderá ser revisto mediante negociação entre o fornecedor e
a JUSTIÇA FEDERAL, podendo o fornecedor ser liberado do compromisso assumido se a negociação for frustrada,
sem aplicação de penalidades administrativas
;
 
8.3 – Na hipótese do 
Fornecedor não aceitar reduzir seu preço aos valores praticados pelo mercado, a JUSTIÇA
FEDERAL convocará os fornecedores do cadastro de reserva, na ordem de classificação, para verificar se aceitam
reduzir seus preços aos valores de mercado;
 
8.4 - No caso de prorrogação da Ata de Registro de Preços, os valores dos itens poderão ser alterados,
observada a 
variação do índice IPCA do IBGE dos últimos 12 (doze) meses, contados da apresentação da
proposta, ou da concessão da última alteração
 
e após realização de pesquisa de preços pela JUSTIÇA FEDERAL.
 
CLÁUSULA N
ONA
 – DO CANCELAMENTO:
 
9.1 – A presente Ata poderá ser cancelada nos termos
 dos arts. 28 e 29 d
o Decreto nº 11.462/23.
 
Ata de Registro de Preço (ARP) - SJRJ 59 MBS SOLUÇÕES (1112133)         SEI 0017538-78.2025.4.02.8001 / pg. 2

## Página 3

CLÁUSULA 
DÉCIMA 
– DAS PENALIDADES:
 
10.1 - O não cumprimento pelo Fornecedor de qualquer uma das obrigações do Termo de Referência ou das
condições predeterminadas nesta Ata de Registro de Preços, sujeitá-lo-á às penalidades dispostas no item 
13
 do
Edital do Pregão, mencionado no preâmbulo e às sanções administrativas determinadas no item 
11
 do Termo
acima citado.
 
CLÁUSULA DÉCIMA 
PRIMEIRA
 - DAS CONSIDERAÇÕES FINAIS:
 
11.1 - Serão incluídos na Ata de Fornecimento do Cadastro de Reserva, os licitantes que aceitaram a
convocação do COMPRASNET para fornecimento dos bens ou serviços, nos mesmos preços do vencedor do
certame, assegurada a preferência de contratação de acordo com a ordem de classificação, bem como, o licitante
que mantiver sua proposta original;
 
11.2 - O Fornecedor deverá manter durante toda a validade da Ata de Registro de Preços, em compatibilidade
com as obrigações por ele assumidas, todas as condições de habilitação e qualificação exigidas na licitação.
 
11.3 - 
O Fornecedor deverá agir de forma 
que não tenham conflitos de interesse, competindo de forma justa,
sempre visando o combate à corrupção e ao suborno e aos crimes econômicos.
 
11.4 - 
O Fornecedor fica obrigado a 
não aceitar e tão pouco oferecer qualquer coisa que possa corroborar
vantagem pessoal indevida
.
 
11.5 - 
Os Fornecedores habilitados no Cadastro de Reserva, que se recusarem a fornecer bens ou serviços
para os quais se registraram, estarão sujeitos às penalidades do Edital do Pregão
 
mencionado no preâmbulo
.
 
11.6 - O Fornecedor deverá indicar a 
sistemática de logística reversa comprovando a destinação final
ambientalmente adequada, nos termos da Lei nº 12.305/2010, estando sujeito às
 penalidades e 
sanções da
Cláusula Sétima por possíveis descumprimentos.
 
CLÁUSULA DÉCIMA 
SEGUNDA 
- DA PUBLICAÇÃO:
 
12.1 – A Ata de Registro de Preços será publicada no 
Portal Nacional de Contratações Públicas, de 
acordo com
o inciso IV, do §2º, do artigo 174 da Lei nº 14.133/2021, e no Diário Eletrônico da Justiça Federal da 2ª Região, em
conformidade com a Portaria nº RJ-PGD-2010/028 de 10/03/2010.
 
CLÁUSULA DÉCIMA 
TERCEIRA
 - DO FORO:
 
13.1 - Para dirimir as questões oriundas da presente Ata de Registro de Preços, fica eleito o Foro da Justiça
Federal - Seção Judiciária do Rio de Janeiro.
 
             E por estarem assim ajustados, assinam as partes a presente Ata.
 
____________________________________________________
Manoel Rolim Campbell Penna
Juiz Federal - Diretor do Foro em exercício
JUSTIÇA FEDERAL DE 1º GRAU NO RIO JANEIRO
 
 
____________________________________________________
Bruno Silva dos Passos
MBS SOLUÇOES INTEGRADAS LTDA
Documento assinado eletronicamente por 
BRUNO SILVA DOS PASSOS
, 
Usuário Externo
, em
10/07/2025, às 13:40, conforme art. 1º, III, "b", da Lei 11.419/2006.
Ata de Registro de Preço (ARP) - SJRJ 59 MBS SOLUÇÕES (1112133)         SEI 0017538-78.2025.4.02.8001 / pg. 3

## Página 4

Documento assinado eletronicamente por 
MANOEL ROLIM CAMPBELL PENNA
, 
Vice-Diretor do
Foro
, em 11/07/2025, às 18:25, conforme art. 1º, III, "b", da Lei 11.419/2006.
A autenticidade do documento pode ser conferida no site
https://sei.trf2.jus.br/sei/controlador_externo.php?
acao=documento_conferir&id_orgao_acesso_externo=1 informando o código verificador 
1112133
 e o
código CRC 
F0EC3D28
.
0017538-78.2025.4.02.8001
SEI 1112133v
2
Ata de Registro de Preço (ARP) - SJRJ 59 MBS SOLUÇÕES (1112133)         SEI 0017538-78.2025.4.02.8001 / pg. 4
