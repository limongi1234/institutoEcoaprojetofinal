# reuso_9d07dbfa806d0cef_9d07dbfa806d

Fonte: [PDF original](https://pncp.gov.br/pncp-api/v1/orgaos/33663683000116/compras/2024/000354/atas/2/arquivos/1)

SHA-256 do PDF: `9d07dbfa806d0ceff00d3287851e47083f479423270d1898e3bdd95b86b4bdcb`

Texto extraído automaticamente, organizado por página.

## Página 1

____________________________________________________________________ 
Câmara Nacional de Modelos de Licitações e Contratos da Consultoria-Geral da União 
Atualização: maio/2023 
Ata de Registro de Preços –  Lei nº 14.133, de 2021. 
Aprovado pela Secretaria de Gestão e Inovação. 
Identidade visual pela Secretaria de Gestão e Inovação 
 
 
ATA DE REGISTRO DE PREÇOS 
 
INSTITUTO DE PSIQUIATRIA 
UNIVERSIDADE FEDERAL DO RIO DE JANEIRO 
(Processo Administrativo n° 23079.245065/2023-79) 
ATA DE REGISTRO DE PREÇOS  
N.º 30/2024 
 
A Universidade Federal do Rio de Janeiro por intermédio do Instituto de Psiquiatria, 
com sede na Avenida Venceslau Brás, 71, fundos, Campus Praia Vermelha, Botafogo/RJ, inscrito no 
CNPJ sob o nº 33.663.683/0025-93, neste ato representado pelo Diretor Geral Pedro Gabriel Godinho 
Delgado, nomeado pela Portaria nº 3086 de 05 de abril de 2023, publicada no  DOU de 11 de abril de 
2023, portador da Matrícula Funcional nº 0365901 , considerando o julgamento da licitação na 
modalidade de pregão, na forma eletrônica, para REGISTRO DE PREÇOS nº  90002/2024, publicada 
no D.O.U. de 14/05/2024, processo administrativo n.º  23079.245065/2023-79, RESOLVE registrar 
os preços da   empresa indicada e qualificada nesta ATA, de acord o com a classificação por ela 
alcançada e na  quantidade  cotada, atendendo as condições previstas no Edital de licitação, sujeitando-
se as partes às normas constantes na Lei nº 14.133, de 1º de abril de 2021, no Decreto n.º 11.462, de 
31 de março de 2023, e em conformidade com as disposições a seguir: 
 
1. DO OBJETO 
1.1. A presente Ata tem por objeto o registro de preços para a eventual contratação de serviços de 
lavanderia, especificado no item  único do Termo de Referência, anexo  I do edital de Licitação nº 
07/2023, que é parte integrante desta Ata, assim como a s propostas cujos preços tenh am sido 
registrados, independentemente de transcrição. 
 
2. DOS PREÇOS, ESPECIFICAÇÕES E QUANTITATIVOS 
2.1. O preço registrado, as especificações do objeto, a s quantidades mínimas e máximas de cada 
item, fornecedor(es) e as demais condições ofertadas na(s) proposta(s) são as que seguem:  
 
Item 
do 
TR 
 
 LAVANDERIA MILÊNIO LTDA 
CNPJ/MF 50.148.454/0001-82 
 Rua Carlos Seidi, 571 – Caju – Rio de Janeiro/RJ – CEP 20.931-002 
Representante Legal: Humberto Bastos Simôes 
 CPF 599.130.967-15 
 
Especificação Quant. 
Mensal (kg) 
Valor Un 
R$

## Página 2

____________________________________________________________________ 
Câmara Nacional de Modelos de Licitações e Contratos da Consultoria-Geral da União 
Atualização: maio/2023 
Ata de Registro de Preços –  Lei nº 14.133, de 2021. 
Aprovado pela Secretaria de Gestão e Inovação. 
Identidade visual pela Secretaria de Gestão e Inovação 
 
1 Serviço de lavanderia industrial, higienização e desinfecção para o 
IPUB/UFRJ, envolvendo o processamento de roupas e tecidos em 
geral, em todas as suas etapas, desde a sua utilização até o seu 
retorno em condições ideais de reuso, sob situações higiênico -
sanitárias 
2.700 4,70 
 
2.2. A listagem do cadastro de reserva referente ao presente registro de preços consta como anexo 
a esta Ata. 
3. ÓRGÃO(S) GERENCIADOR E PARTICIPANTE(S) 
3.1. O órgão gerenciador será o Instituto de Psiquiatria da UFRJ 
3.2. Além do gerenciador, são órgãos e entidades públicas participantes do registro de preços: 
Item nº  Órgãos Participantes UASG Quantidade mensal 
(KG) 
 
1 
Instituto de 
Ginecologia 
153147 1.300 
Escola Naval 762400 14.400 
 
4. DA ADESÃO À ATA DE REGISTRO DE PREÇOS 
4.1. Durante a vigência da ata, os órgãos e as entidades da Administração Pública federal, estadual, 
distrital e municipal que não participaram do procedimento de IRP poderão aderir à ata de registro de 
preços na condição de não participantes, observados os seguintes requisitos : 
4.1.1. apresentação de justificativa da vantagem da adesão, inclusive em situações de 
provável desabastecimento ou descontinuidade de serviço público; 
4.1.2.  demonstração de que os valores registrados estão compa tíveis com os valores 
praticados pelo mercado na forma do art. 23 da Lei nº 14.133, de 2021; e 
4.1.3.  consulta e aceitação prévias do órgão ou da entidade gerenciadora e do fornecedor. 
4.2. A autorização do órgão ou entidade gerenciadora apenas será realizada após a aceitação da 
adesão pelo fornecedor. 
4.2.1. O órgão ou entidade gerenciadora poderá rejeitar adesões caso elas possam acarretar 
prejuízo à execução de seus próprios contratos ou à sua capacidade de gerenciamento. 
4.3.  Após a autorização do órgão ou  da entidade gerenciadora, o órgão ou entidade não 
participante deverá efetivar a aquisição ou a contratação solicitada em até noventa dias, observado o 
prazo de vigência da ata. 
4.4.  O prazo de que trata o subitem anterior , relativo à efetivação da contratação,  poderá ser 
prorrogado excepcionalmente, mediante solicitação do órgão ou da entidade não participante aceita 
pelo órgão ou pela entidade gerenciadora, desde que respeitado o limite temporal de vigência da ata 
de registro de preços.

## Página 3

____________________________________________________________________ 
Câmara Nacional de Modelos de Licitações e Contratos da Consultoria-Geral da União 
Atualização: maio/2023 
Ata de Registro de Preços –  Lei nº 14.133, de 2021. 
Aprovado pela Secretaria de Gestão e Inovação. 
Identidade visual pela Secretaria de Gestão e Inovação 
 
4.5. O órgão ou a entidade poderá aderir a item da ata de registro de preços da qual seja integrante, 
na qualidade de não par ticipante, para aqueles itens p ara os quais não tenha quan titativo registrado, 
observados os requisitos do item 4.1. 
Dos limites para as adesões 
4.6. As aquisições ou contratações adicionais não poderão exceder, por órgão ou entidade, a 
cinquenta por cento dos quantitativos dos itens do instrumento convocatório registrados na ata de 
registro de preços para o gerenciador e para os participantes. 
4.7. O quantitativo decorrente das adesões não poderá ex ceder, na totalidade, ao dobro do 
quantitativo de cada item registrado na ata de registro de preços para o gerenciador e os participantes, 
independentemente do número de órgãos ou entidades não participantes que aderirem à ata de registro 
de preços. 
4.8. Para aquisição emergencial de medicamentos e material de consumo médico -hospitalar por 
órgãos e entidades da Administração Pública federal, estadual, distrital e municipal, a adesão à ata de 
registro de preços gerenciada pelo Ministério da Saúde não estará sujeita ao limite previsto no item 4.7. 
4.9. A adesão à ata de registro de preços por órgãos e entidades da Administração Pública estadual, 
distrital e municipal poderá ser exigida para fins de transferências voluntárias, não ficando sujeita ao 
limite de que trata o item 4. 7, desde que seja  destinada à execução descentralizada de programa ou 
projeto federal e comprovada a compatibilidade dos preços registrados com os valores praticados no 
mercado na forma do art. 23 da Lei nº 14.133, de 2021. 
Vedação a acréscimo de quantitativos 
4.10. É vedado efetuar acréscimos nos quantitativos fixados na ata de registro de preços . 
5. VALIDADE, FORMALIZAÇÃO DA ATA DE REGISTRO DE PREÇOS E CADASTRO RESERVA 
5.1. A validade da Ata de Registro de Preços será de  1 (um) ano, contado a  partir do primeiro dia 
útil subsequente à data de divulgação no PNCP , podendo ser prorrogada por igual período, mediante 
a anuência do fornecedor, desde que comprovado o preço vantajoso. 
5.1.1. O contrato decorrente da ata de registro de preços terá sua vigência estabelecida n o 
próprio instrumento contratual e observará no momento da contratação e a cada exercício financeiro 
a disponibilidade de créditos orçamentários, bem como a previsão no plano plurianual, quando 
ultrapassar 1 (um) exercício financeiro. 
5.1.2. Na formalização do contrato ou do instrumento substituto deverá haver a indicação da 
disponibilidade dos créditos orçamentários respectivos. 
5.2. A contratação com os fornecedores registrados na ata será formalizada pelo órgão ou pela 
entidade interessad a por intermédio de instrumento contratual, emissão de nota de empenho de 
despesa, autorização de compra ou outro instrumento hábil, conforme o art. 95 da Lei nº 14.133, de 
2021. 
5.2.1.  O instrumento contratual de que trata o item 5.2. deverá ser assinado no prazo de 
validade da ata de registro de preços. 
5.3. Os contratos decorrentes do sistema de registro de preços poderão ser alterados, observado o 
art. 124 da Lei nº 14.133, de 2021. 
5.4. Após a homologação da licitação ou da contratação direta, deverão ser observadas as 
seguintes condições para formalização da ata de registro de preços:

## Página 4

____________________________________________________________________ 
Câmara Nacional de Modelos de Licitações e Contratos da Consultoria-Geral da União 
Atualização: maio/2023 
Ata de Registro de Preços –  Lei nº 14.133, de 2021. 
Aprovado pela Secretaria de Gestão e Inovação. 
Identidade visual pela Secretaria de Gestão e Inovação 
 
5.4.1. Serão registrados na ata os preços e os quan titativos do adjudicatário , devendo ser 
observada a possibilidade de o licitante oferecer ou não proposta em quantitativo inferior ao máximo 
previsto no edital e se obrigar nos limites dela; 
5.4.2. Será incluído na ata, na forma de anexo, o registro dos  licitantes ou dos fornecedores 
que: 
5.4.2.1. Aceitarem cotar os bens, as obras ou os serviços com preços iguais aos do 
adjudicatário, observada a classificação da licitação; e  
5.4.2.2. Mantiverem sua proposta original.  
5.4.3. Será respeitada, nas contratações, a ordem de classificação dos licitantes ou dos 
fornecedores registrados na ata. 
5.5. O registro a que se refere o item 5.4.2 tem por objetivo a formação de cadastro de reserva para 
o caso de impossibilidade de atendimento pelo signatário da ata. 
5.6. Para fins da ordem de classificação, os licitantes ou fornecedores que aceitarem reduzir suas 
propostas para o preço do adjudicatário antecederão aqueles que mantiverem sua proposta original. 
5.7. A habilitação dos licitantes que comporão o cadastro de reserva a que se refere o item 5.4.2.2 
somente será efetuada quando houver necessidade de contratação dos licitantes  remanescentes, nas 
seguintes hipóteses: 
5.7.1. Quando o licitante vencedor não assinar a ata de registro de preços, no prazo e nas  
condições estabelecidos no edital; e 
5.7.2. Quando houver o cancelamento do registro do licitante ou do registro de preços nas  
hipóteses previstas no item 9. 
5.8. O preço registrado com indicação dos licitantes e fornecedores será divulgado no PNCP e ficará 
disponibilizado durante a vigência da ata de registro de preços. 
5.9. Após a homologação da licitação ou da contratação direta, o licitante mais bem classificado ou 
o fornecedor, no caso da contratação direta, será convocado para assinar a ata de registro de preços, 
no prazo e nas condições estabelecidos no edital de licitaç ão ou no aviso de contratação direta, sob 
pena de decair o direito, sem prejuízo das sanções previstas na Lei nº 14.133, de 2021.  
5.9.1. O prazo de convocação poderá ser prorrogado 1 (uma) vez, por igual período, mediante 
solicitação d o licitante ou fornecedor convocado , desde que  apresentada dentro do prazo , 
devidamente justificada, e que a justificativa seja aceita pela Administração. 
5.10. A ata de registro de preços  será assinada por meio de assinatura digital e  disponibilizada no 
Sistema de Registro de Preços. 
5.11. Quando o convocado não assinar a ata de registro de preços no prazo e nas condições 
estabelecidos no edital ou no aviso de contratação, e observado o disposto no item 5.7, observando o 
item 5.7 e subitens, fica facultado à Administração convocar  os licitantes remanescentes do cadastro 
de reserva, na ordem de classificação, para fazê -lo em igual prazo e  nas condições propostas pelo 
primeiro classificado. 
5.12. Na hipótese de nenhum dos licitantes que trata o item 5.4.2.1, aceitar a contratação nos termos 
do item anterior, a Administração, observados o valor estimado e sua eventual atualização nos termos 
do edital, poderá: 
5.12.1. Convocar para negociação os demais licitantes ou fornecedores remanescentes cujos 
preços foram registrados sem redução, observada a ordem de classificação, com vistas à obtenção 
de preço melhor, mesmo que acima do preço do adjudicatário; ou

## Página 5

____________________________________________________________________ 
Câmara Nacional de Modelos de Licitações e Contratos da Consultoria-Geral da União 
Atualização: maio/2023 
Ata de Registro de Preços –  Lei nº 14.133, de 2021. 
Aprovado pela Secretaria de Gestão e Inovação. 
Identidade visual pela Secretaria de Gestão e Inovação 
 
5.12.2. Adjudicar e firmar o contrato nas condições ofertadas pelos licitantes ou fornecedores 
remanescentes, atendida a ordem classificatória, quando frustrada a negociação de melhor 
condição. 
5.13. A existência de preços registrados implicará compromisso de fornecimento nas condições 
estabelecidas, mas não obrigará a Administração a contratar, facultada a realização de licitação 
específica para a aquisição pretendida, desde que devidamente justificada. 
6. ALTERAÇÃO OU ATUALIZAÇÃO DOS PREÇOS REGISTRADOS 
6.1. Os preços registrados poderão ser alterados ou atualizados em decorrência de eventual 
redução dos preços pra ticados no mercado ou de fato que eleve o custo dos bens, das obras ou dos 
serviços registrados, nas seguintes situações: 
6.1.1. Em caso de força maior, caso fortuito ou fato do príncipe ou em decorrência de fatos 
imprevisíveis ou previsíveis de consequências incalculáveis, que inviabilizem a execução da ata tal 
como pactuada, nos termos da alínea “d” do inciso II do caput do art. 124 da Lei nº 14.133, de 2021; 
6.1.2. Em caso de criação, alteração ou extinção de quaisquer tributos ou encargos legais ou 
a superveniência de disposições legais, com comprovada repercussão sobre os preços registrados;  
6.1.3. Na hipótese de previsão  no edital ou no aviso de contratação direta de cláusula de 
reajustamento ou repactuação sobre os preços registrados, nos termos da Lei nº 14.133, de 2021. 
6.1.3.1. No caso do reajustamento, deverá ser respeitada a contagem da anualidade e o índice 
previstos para a contratação;   
6.1.3.2. No caso da repactuação,  poderá ser a pedido do interessado, conforme critérios 
definidos para a contratação. 
7. NEGOCIAÇÃO DE PREÇOS REGISTRADOS 
7.1. Na hipótese de o preço registrado tornar-se superior ao preço praticado no mercado por motivo 
superveniente, o órgão ou entidade gerenciadora convocará o fornecedor para negociar a redução do 
preço registrado. 
7.1.1. Caso não aceite reduzir seu preço aos valores pra ticados pelo mercado, o fornecedor 
será liberado do compromisso assumido quanto ao item registrado, sem aplicação de penalidades 
administrativas. 
7.1.2. Na hipótese prevista no item anterior, o gerenciador convocar á os fornecedores do 
cadastro de reserva, na ordem de classificação, para verificar se aceitam reduzir seus preços aos 
valores de mercado  e não convocará o s licitantes ou fornecedores que tiveram seu registro 
cancelado.  
7.1.3. Se não obtiver êxito nas negociações, o órgão ou entidade gerenciadora procederá ao 
cancelamento da ata de registro de preços, adotando as medidas cabíveis para obtenção d e 
contratação mais vantajosa. 
7.1.4. Na hipótese de redução do preço registrado, o gerenciador comunicará aos órgãos e às 
entidades que tiverem firmado contratos decorrentes da ata de registro de preços para que avaliem 
a conveniência e a oportunidade de  diligenciarem negociação com vistas à alteração contratual, 
observado o disposto no art. 124 da Lei nº 14.133, de 2021. 
7.2. Na hipótese de o preço de mercado tornar-se superior ao preço registrado e o fornecedor não 
poder cumprir as obrigações estabelecidas na ata, será facultado ao fornecedor requerer ao  
gerenciador a alteração do preço registrado, mediante comprovação de fato superveniente que  
supostamente o impossibilite de cumprir o compromisso.

## Página 6

____________________________________________________________________ 
Câmara Nacional de Modelos de Licitações e Contratos da Consultoria-Geral da União 
Atualização: maio/2023 
Ata de Registro de Preços –  Lei nº 14.133, de 2021. 
Aprovado pela Secretaria de Gestão e Inovação. 
Identidade visual pela Secretaria de Gestão e Inovação 
 
7.2.1. Neste caso , o fornecedor encaminhar á, juntamente com o  pedido de alteração, a 
documentação comprobatória ou a planilha de custos que demonstre a inviabilidade  do preço  
registrado em relação às condições inicialmente pactuadas. 
7.2.2. Não hipótese de não comprovação da existência de fato superveniente que inviabilize 
o preço registrado, o pedido será indeferido pelo órgão ou en tidade gerenciadora e o fornecedor 
deverá cumprir as obrigações estabelecidas na ata, sob pena de cancelamento do seu registro, nos 
termos do item 9.1, sem prejuízo das sanções previstas na Lei nº 14.133, de 2021, e na legislação 
aplicável. 
7.2.3. Na hipótese de cancelamento do registro do fornecedor, nos termos do item anterior, o 
gerenciador convocará os fornecedores do cadastro de reserva, na ordem de classificação, para 
verificar se aceitam manter seus preços registrados, observado o disposto no item 5.7. 
7.2.4. Se não obtiver êxito nas negociações, o órgão ou entidade gerenciadora procederá ao 
cancelamento da ata de registro de preços, nos termos do item 9.4, e adotará as medidas cabíveis 
para a obtenção da contratação mais vantajosa. 
7.2.5. Na hipótese de comprovação da majoração do preço de mercado  que inviabilize o 
preço registrado, conforme previsto no item 7.2 e no item 7.2.1, o órgão ou en tidade gerenciadora 
atualizará o preço registrado, de acordo com a realidade dos valores praticados pelo mercado. 
7.2.6.  O órgão ou entidade gerenciadora comunicará aos órgãos e às entidades que tiverem 
firmado contratos decorrentes da ata de registro de preços sobre a efe tiva alteração do preço 
registrado, para que avaliem a  necessidade de alteração contratual, observado o disposto no art. 
124 da Lei nº 14.133, de 2021. 
8. REMANEJAMENTO DAS QUANTIDADES REGISTRADAS NA ATA DE REGISTRO DE 
PREÇOS 
8.1.  As quantidades previstas para os itens com preços registrados nas atas de registro de preços 
poderão ser remanejadas pelo órgão ou en tidade gerenciadora entre os órgãos ou as entidades 
participantes e não participantes do registro de preços. 
8.2.  O remanejamento somente poderá ser feito: 
8.2.1. De órgão ou entidade participante para órgão ou entidade participante; ou 
8.2.2. De órgão ou entidade participante para órgão ou entidade não participante. 
8.3. O órgão ou en tidade gerenciadora que tiver estimado as quantidades que pretende contratar 
será considerado participante para efeito do remanejamento. 
8.4. Na hipótese de remanejamento de órgão ou entidade participante para órgão ou entidade não 
participante, serão observados os limites previstos no art. 32 do Decreto nº 11.462, de 2023. 
8.5. Competirá ao órgão ou à entidade gerenciadora autorizar o  remanejamento solicitado, com a 
redução do quan titativo inicialmente informado pelo órgão ou pela entidade participante, desde que 
haja prévia anuência do órgão ou da entidade que sofrer redução dos quantitativos informados. 
8.6. Caso o remanejamento seja feito entre órgãos ou en tidades dos Estados, do Distrito Federal 
ou de Municípios distintos, caberá ao fornecedor beneficiário da ata de registro de preços, observadas 
as condições nela estabelecidas, optar pela aceitação ou não do fornecimento decorrente do  
remanejamento dos itens. 
8.7. Na hipótese da compra centralizada, não havendo indicação pelo órgão ou pela entidade 
gerenciadora, dos quantitativos dos par ticipantes da compra centralizada, nos termos do item 8.3, a 
distribuição das quantidades para a execução descentralizada será por meio do remanejamento.

## Página 7

____________________________________________________________________ 
Câmara Nacional de Modelos de Licitações e Contratos da Consultoria-Geral da União 
Atualização: maio/2023 
Ata de Registro de Preços –  Lei nº 14.133, de 2021. 
Aprovado pela Secretaria de Gestão e Inovação. 
Identidade visual pela Secretaria de Gestão e Inovação 
 
9. CANCELAMENTO DO REGISTRO DO LICITANTE VENCEDOR E DOS PREÇOS 
REGISTRADOS 
9.1. O registro do fornecedor será cancelado pelo gerenciador, quando o fornecedor: 
9.1.1. Descumprir as condições da ata de registro de preços, sem motivo justificado;  
9.1.2. Não retirar a nota de empenho, ou instrumento equivalente, no prazo estabelecido pela 
Administração sem justificativa razoável; 
9.1.3. Não aceitar manter seu preço registrado, na hipótese prevista no artigo 27, § 2º, do 
Decreto nº 11.462, de 2023; ou 
9.1.4.  Sofrer sanção prevista nos incisos III ou IV do caput do art. 156 da Lei nº 14.133, de 
2021. 
9.1.4.1. Na hipótese de aplicação de sanção prevista nos incisos III ou IV do caput do art. 156 
da Lei nº 14.133, de 2021, caso a penalidade aplicada ao fornecedor não ultrapasse o prazo de 
vigência da ata de registro de preços, poderá o órgão ou a entidade gerenciadora  poderá, 
mediante decisão fundamentada, decidir pela manutenção do registro de preços, vedadas 
contratações derivadas da ata enquanto perdurarem os efeitos da sanção.  
9.2.  O cancelamento de registros nas hipóteses previstas no item 9.1 será formalizado por 
despacho do órgão ou da entidade gerenciadora, garantidos os princípios do contraditório e da ampla 
defesa. 
9.3. Na hipótese de cancelamento do registro do fornecedor, o órgão ou a entidade gerenciadora 
poderá convocar os licitantes que compõem o cadastro de reserva, observada a ordem de classificação. 
9.4. O cancelamento dos preços registrados poderá ser realizado pelo gerenciador , em 
determinada ata de registro de preços, total ou parcialmente,  nas seguintes hipóteses , desde que 
devidamente comprovadas e justificadas:  
9.4.1. Por razão de interesse público; 
9.4.2. A pedido do fornecedor, decorrente de caso fortuito ou força maior; ou 
9.4.3. Se não houver êxito nas negociações, nas hipóteses em que o preço de mercado 
tornar-se superior ou inferior ao preço registrado, nos termos do artigos 26, § 3º e  27, § 4º, ambos 
do Decreto nº 11.462, de 2023.  
10. DAS PENALIDADES 
10.1. O descumprimento da Ata de Registro de Preços ensejará aplicação das penalidades 
estabelecidas no edital. 
10.1.1. As sanções também se aplicam aos integrantes do cadastro de reserva no registro de 
preços que, convocados, não honrarem o compromisso assumido injustificadamente  após terem 
assinado a ata.  
10.2. É da competência do gerenciador a aplicação das penalidades decorrentes do descumprimento 
do pactuado nesta ata de registro de preço  (art. 7º, inc. XIV, do Decreto nº 11.462, de 2023), exceto 
nas hipóteses em que o descumprimento disser respeito às contratações dos órgãos  ou entidade  
participante, caso no qual caberá ao respectivo órgão participante a aplicação da penalidade (art. 8º, 
inc. IX, do Decreto nº 11.462, de 2023). 
10.3. O órgão  ou entidade  participante deverá comunicar ao órgão gerenciador qualquer das 
ocorrências previstas no item 9.1, dada a necessidade de instauração de procedimento para 
cancelamento do registro do fornecedor.

## Página 8

____________________________________________________________________ 
Câmara Nacional de Modelos de Licitações e Contratos da Consultoria-Geral da União 
Atualização: maio/2023 
Ata de Registro de Preços –  Lei nº 14.133, de 2021. 
Aprovado pela Secretaria de Gestão e Inovação. 
Identidade visual pela Secretaria de Gestão e Inovação 
 
11. CONDIÇÕES GERAIS 
11.1. As condições gerais de execução do objeto, tais como os prazos para entrega e recebimento, 
as obrigações da Administração e do fornecedor registrado, penalidades e demais condições do ajuste, 
encontram-se definidos no Termo de Referência, ANEXO AO EDITAL. 
11.2. No caso de adjudicação por preço global de grupo de itens, só será admitida a contratação d e 
parte de itens do grupo se houver prévia pesquisa de mercado e demonstração de sua vantagem para 
o órgão ou a entidade. 
Para firmeza e validade do pactuado, a presente Ata foi lavrada em 2 (duas) vias de igual teor, que, 
depois de lida e achada em ordem, vai assinada pelas partes e encaminhada cópia aos demais órgãos 
participantes.  
Rio de Janeiro, 10 de junho de 2024 
 
 
______________________________  
Pedro Gabriel Godinho Delgado 
Diretor Geral 
SIAPE 03.065901 
 
 
___________________________________ 
 LAVANDERIA MILÊNIO LTDA 
CNPJ/MF 50.148.454/0001-82 
Representante Legal: Humberto Bastos Simôes 
 CPF 599.130.967-15
